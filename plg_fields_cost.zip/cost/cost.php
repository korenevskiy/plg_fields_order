<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Fields.Sql
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */



$toFun = JPATH_ROOT.'/functions.php';
//echo "<b> $toFun</b>";
if(file_exists($toFun))
	require_once  $toFun;
//return;


use Joomla\Event\SubscriberInterface;
use Joomla\Component\Fields\Administrator\Plugin;
//use Joomla\Component\Fields\Administrator\Plugin\FieldsPlugin;
use Joomla\Component\Fields\Administrator\Plugin\FieldsListPlugin;



use Joomla\CMS\Form\Form as JForm;

use Joomla\CMS\Language\Text as JText;

use Joomla\CMS\Factory as JFactory;
use Joomla\CMS\Plugin\CMSPlugin;  
use Joomla\CMS\Plugin\CMSPlugin as JPlugin;
use Joomla\CMS\Event\GenericEvent as JEvent;
//use Joomla\CMS\Event\AbstractEvent;
//use Joomla\Event\Event;
//use Joomla\Component\Fields\Administrator\Helper\FieldsHelper as JFieldsHelper;
//use Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use Joomla\CMS\Language\Multilanguage;
use Joomla\Component\Finder\Administrator\Indexer\Indexer;
use Joomla\Registry\Registry as JRegistry;

use \Joomla\CMS\Helper\LibraryHelper as JLibraryHelper;
use \Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use \Joomla\CMS\Helper\ContentHelper as JHelperContent;
use \Joomla\CMS\Helper\CMSHelper as JHelper;
use \Joomla\CMS\Plugin\PluginHelper as JPluginHelper;

 
use \Joomla\CMS\Form\FormField as JFormField;
use \Joomla\CMS\Form\FormHelper as JFormHelper;
//use Joomla\Application


defined('_JEXEC') or die;

JLoader::import('fields.sql.sql', JPATH_PLUGINS);
JLoader::import('components.com_fields.libraries.fieldsplugin', JPATH_ADMINISTRATOR);

//JLoader::import('components.com_fields.libraries.fieldslistplugin', JPATH_ADMINISTRATOR);
//JLoader::import('components.com_fields.libraries.fieldslistplugin', JPATH_ADMINISTRATOR);


if(explode('.', PHP_VERSION)[0] < 8){
	require_once __DIR__ . '/lib/helper.php';
}

if(file_exists(JPATH_ROOT . '/administrator/components/com_fields/libraries/fieldsplugin.php')){
	require_once JPATH_ROOT . '/administrator/components/com_fields/libraries/fieldsplugin.php';
}

JLoader::register('FieldsHelper', JPATH_ADMINISTRATOR . '/components/com_fields/helpers/fields.php');

if(explode('.', PHP_VERSION)[0] < 8 && JVersion::MAJOR_VERSION == 3){
//	class_alias( 'Joomla\\Component\\Fields\\Administrator\\Helper\\FieldsHelper','JFieldsHelper');
//	class_alias( 'JFieldsHelper','Joomla\\Component\\Fields\\Administrator\\Helper\\FieldsHelper');
}
if(JVersion::MAJOR_VERSION == 3){
	JLoader::register('ContentHelperRoute', JPATH_ROOT . '/components/com_content/helpers/route.php');
	class_alias( 'ContentHelperRoute','Joomla\Component\Content\Site\Helper\RouteHelper');
}
// toPrint(JFactory::getApplication()->getInput()->get('jform')['com_fields']['tsena'][1]['title'],'',0,'message');

//$jform = JFactory::getApplication()->input->post->get('jform', array(), 'array');
//$jform = JFactory::getApplication()->input->getArray();
//$jform = JFactory::getApplication()->input->post;
//toPrint($jform, '$jform',0);

//toPrint($_SERVER,'$_SERVER',0);
//toPrint($_ENV,'$_ENV',0);
//toPrint($_POST,'$_POST',0);
//toPrint($_GET,'$_GET',0);
//toPrint($_SERVER,'$_SERVER',0);//jform[params][list_currencies][default_cur][]	JFactory::getApplication()->getInput()->getRaw('jform')
//toPrint(JFactory::getApplication()->getInput());//jform[params][list_currencies][default_cur][]	JFactory::getApplication()->getInput()->getRaw('jform')
//toPrint(JFactory::getApplication()->getInput()->files);//jform[params][list_currencies][default_cur][]	JFactory::getApplication()->getInput()->getRaw('jform')		com_fields

//\Joomla\Component\Fields\Administrator\Plugin\FieldsPlugin
//FieldsListPlugin FieldsPlugin 
/**
 * Fields Sql Plugin
 *
 * @since  3.7.0
 */
class PlgFieldsCost extends FieldsPlugin  //implements SubscriberInterface //FieldsListPlugin//FieldsPlugin  // PlgFieldsSql Plgfieldscost
{
	public static $X = 0;
			
	/**
	 * Constructor
	 *
	 * @param   DispatcherInterface  &$subject  The object to observe
	 * @param   array                $config    An optional associative array of configuration settings.
	 *                                          Recognized key values include 'name', 'group', 'params', 'language'
	 *                                         (this list is not meant to be comprehensive).
	 * 
	 *											Необязательный ассоциативный массив настроек конфигурации. 
	 *											Распознанные ключевые значения включают 'name', 'group', 'params', 'language'
	 *											(этот список не является исчерпывающим).
	 *											
	 *											$config['type'] = fields
	 *											$config['params'] = cost
	 *											$config['params'] = JSON данные плагина
	 *											$config['id']  = ID плагина
	 *
	 * @since   1.5
	 */
	public function __construct(&$subject, $config = array())
	{
//        $field->paramsPlugin = $this->params;
//		static::$DataKostyl[$field->name] = $field; //$field->name, $field->id
//toPrint($config,'onBeforeRender',0);
//toPrint(static::$DataKostyl,'Cost->__construct() static::$DataKostyl ',0);
//toPrint(array_keys(get_object_vars($subject)),'Cost->__construct()$subject type:'. get_class($subject).' ',0,'message'); 
		
		$this->loadLanguage('',__DIR__.'/language/');
		parent::__construct($subject, $config);
//echo "<pre>".print_r($this->params,true)."</pre>";
//echo toPrint($this->params,'$this->params',0,'message');
//		return;
		
		
		$itemActive = JFactory::getApplication()->getMenu()->getActive();
		

//		if(is_null($itemActive))
//			return;


//		$itemActive->type		== 'component';
//		$itemActive->component	== 'com_content';
//		$itemActive->query		== [];
//		$itemActive->query['id']== 8;
//		$itemActive->query['view']== 'category';
//		$itemActive->query['option']== 'com_content';
//		$itemActive->query['layout']== 'blog';
		
//toPrint(($itemActive->query), '  '.static::$X,0);//array_keys
//com_content.article, com_content.categories, 
		if(isset($itemActive) &&  $itemActive->type == 'component' && $itemActive->component	== 'com_content'
				&& isset($itemActive->query) && is_array($itemActive->query)
				&& isset( $itemActive->query['view'])
				&& $itemActive->query['view'] == 'category' && isset( $itemActive->query['id']) )
		{
			$fieldsCategory = FieldsHelper::getFields('com_content.categories', ['id' => (int)$itemActive->query['id']]);
		
			foreach ($fieldsCategory as $fld){
				$f = array_intersect_key((array)$fld, array_flip(['id','context']));
				$f['itemId'] = (int)$itemActive->query['id'];
				$f['field_id'] = (int)$f['id'];
				unset($f['id']);
	//			$f['field'] = $fld;
				$this->categoryFieldsOrderIds[] = $f;
			}
		}
		
//		\Joomla\Data\
		
		// Валюта по умолчанию из Плагина // ->name_unit, ->short_unit, ->type_unit, ->enable_unit
		$list_currencies = $this->params['list_currencies'] ?? FALSE;
		static::$currency = new stdClass; //$list_currencies->{};//[name_cur, short_cur, code_cur, ratio_cur, display_cur]
		if($list_currencies){
			static::$currencies = [];
			if(is_scalar($list_currencies->default_cur)){
				$default_cur = $list_currencies->default_cur;
				$list_currencies->default_cur = array_fill (0, count($list_currencies->ratio_cur), '');
				$list_currencies->default_cur[$default_cur] = 1;
			}
			foreach($list_currencies->display_cur as $i => $enabled ){ //get_object_vars($list_currencies) as $prop_name => $property_cur
				if(empty($enabled))
					continue;
				
				static::$currencies[$i] = new stdClass;
				static::$currencies[$i]->name_cur	= $list_currencies->name_cur[$i]  ?? '';	//Имя длинное
				static::$currencies[$i]->short_cur	= $list_currencies->short_cur[$i]  ?? '';	//Имя короткое
				static::$currencies[$i]->code_cur	= $list_currencies->code_cur[$i]  ?? '';	//Код
				static::$currencies[$i]->ratio_cur	= $list_currencies->ratio_cur[$i]  ?? '';	//Курс обмена
				static::$currencies[$i]->default_cur= $list_currencies->default_cur[$i]  ?? '';	//Выбор по умолчанию
				static::$currencies[$i]->display_cur= $list_currencies->display_cur[$i]  ?? '';	//Включено
				
				
				if($list_currencies->default_cur[$i])
					static::$currency =  static::$currencies[$i] ?? null;
				
//				$this->loadLanguage();
//				JFactory::getLanguage()->getLocale()['XXX']= '55555';
			}
		}else{
			foreach (static::$currencies as $i => $cur){
				static::$currencies[$i] = (object)$cur;
				if($cur['default_cur'])
					static::$currency =  static::$currencies[$i] ?? null;
			}
		}
		
//	 $config['type'] = fields
//	 $config['params'] = cost
//	 $config['params'] = JSON данные плагина
//	 $config['id']  = ID плагина

//toPrint($subject, '$subject',0);
//toPrint($config, '$config',0);
//toPrint($list_currencies, '$list_currencies',0);
//toPrint($currency, '$currency',0);
//toPrint($list_currencies->default_cur, '$list_currencies->default_cur',0);
		
		
		// Еденицы учета из Плагина // ->name_unit, ->short_unit, ->type_unit, ->enable_unit
		$list_units = $this->params['list_units'] ?? FALSE; //new class{public $name_unit = [];}
		if($list_units){
			static::$units = [];
			foreach ($list_units->name_unit as $i => $name){
				if(empty($list_units->enable_unit[$i]))
					continue;
				static::$units[$i] = new stdClass;
				static::$units[$i]->name_unit	= $list_units->name_unit[$i]  ?? '';	//Имя длинное
				static::$units[$i]->short_unit	= $list_units->short_unit[$i] ?? '';	//Имя короткое
				static::$units[$i]->type_unit	= $list_units->type_unit[$i]  ?? '';	//Тип измерения
				static::$units[$i]->enable_unit	= $list_units->enable_unit[$i]?? '';	//Включён
			}
		}else{
			foreach (static::$units as $i => $unit){
				static::$units[$i] = (object)$unit;
			}
		}
		foreach (static::$units as $i => $unit){
			static::$units[$i] = (object)$unit;
			static::$units[$i]->name_unit = JText::_(static::$units[$i]->name_unit);
			static::$units[$i]->short_unit = JText::_(static::$units[$i]->short_unit); 
		}
//toPrint(static::$units, 'static::$units',0);
	}
	 
	
	/**
	 * 
	 * @var    array
	 * @since  3.2
	 */
	protected $categoryFieldsOrderIds = []; 
	
	/**
	 * @var array
	 */
	public   $fieldAliases = [];
	
	/**
	 * Массив имен/aliases всех полей этого типа для этой страницы
	 * @var array Массив имен/aliases всех полей этого типа для этой страницы
	 */
	public   $names = [];
	
	/**
	 * Массив Полей этого типа для этой страницы.
	 * @var array Массив Полей этого типа для этой страницы.
	 */
	public   $fields = [];
	
	/**
	 * Default currency
	 * @var stdObject
	 */
	public static $currency = null;
	
	/**
	 * list currencies
	 * @var array
	 */
	public static $currencies = [
		['name_cur'=>'Рублей','short_cur'=>'₽','code_cur'=>'RUB','ratio_cur'=>1,'default_cur'=>1,'display_cur'=>1,],
		['name_cur'=>'Dollar','short_cur'=>'$','code_cur'=>'USD','ratio_cur'=>1,'default_cur'=>0,'display_cur'=>1,],
		['name_cur'=>'Euro','short_cur'=>'€','code_cur'=>'EUR','ratio_cur'=>1,'default_cur'=>0,'display_cur'=>1,],
		['name_cur'=>'Pound','short_cur'=>'£','code_cur'=>'GBP','ratio_cur'=>1,'default_cur'=>0,'display_cur'=>1,],
		['name_cur'=>'円','short_cur'=>'¥','code_cur'=>'JPY','ratio_cur'=>1,'default_cur'=>0,'display_cur'=>1,],
		['name_cur'=>'元','short_cur'=>'Ұ','code_cur'=>'CNY','ratio_cur'=>1,'default_cur'=>0,'display_cur'=>1,],
	];

	/**
	 * List accounting units.
	 * @var array
	 */	
	public static $units =  [
		['name_unit'=>'PLG_COST_UNIT_PCS_L','short_unit'=>'PLG_COST_UNIT_PCS','type_unit'=>'integer','enable_unit'=>1,],
		['name_unit'=>'PLG_COST_UNIT_PKG_L','short_unit'=>'PLG_COST_UNIT_PKG','type_unit'=>'integer','enable_unit'=>1,],
		['name_unit'=>'PLG_COST_UNIT_CTN_L','short_unit'=>'PLG_COST_UNIT_CTN','type_unit'=>'integer','enable_unit'=>1,],
		['name_unit'=>'PLG_COST_UNIT_KGS_L','short_unit'=>'PLG_COST_UNIT_KGS','type_unit'=>'float','enable_unit'=>1,],
		['name_unit'=>'PLG_COST_UNIT_GRS_L','short_unit'=>'PLG_COST_UNIT_GRS','type_unit'=>'float','enable_unit'=>1,],
	];
	
	
	/**
	 * Name of the layout being used to render the field
	 *
	 * @var    string
	 * @since  3.5
	 */
	protected $layout = '';
    
	/**
	 *  
	 *
	 * @var    bool
	 * @since  3.2
	 */
	protected $formating = false; 
     
	/**
	 * Layout to render the form field
	 *
	 * @var  string
	 */
//	protected $renderLayout = 'joomla.form.costX';
//	protected $renderLayout = 'joomla.form.renderfield';  
	/**
	 * Layout to render the label
	 *
	 * @var  string
	 */
//	protected $renderLabelLayout = 'joomla.form.renderlabel';
	
	
	public function onFieldCostGetCurrencies(){
		static $fisrt;
		
		if($fisrt)
			return static::$currencies;
		
		$fisrt = true;
		foreach (static::$currencies as $i => $currency){
			static::$currencies[$i] = (object)$currency;
			
			if($currency->default_cur ?? '')
				static::$currency = $currency;
		}
		if(empty(static::$currency))
			static::$currency = reset(static::$currencies);
		
		return static::$currencies;
	}
	
	public function onFieldCostGetUnits(){
		static $fisrt;
		
		if($fisrt)
			return static::$units;
		
		$fisrt = true;
		
//toPrint(static::$units,static::$units,0,'message');
		
		foreach (static::$units as $i => $unit){
			static::$units[$i] = (object)$unit;
			static::$units[$i]->name_unit = JText::_(static::$units[$i]->name_unit);
			static::$units[$i]->short_unit = JText::_(static::$units[$i]->short_unit); 
		}
		return static::$units;
	}
	
	/**
	 * Возвращает массив событий, которые будет прослушивать этот подписчик.
	 *
	 * @return  array
	 */
	public static function getSubscribedEvents(): array
	{
		return [ 
//			'<EventName>' => 'myFunctionName',
		];
	}
 	
	/**
	 * If in the article view and the parameter is enabled shows the page navigation
	 *
	 * @param   string   $context  The context of the content being passed to the plugin
	 * @param   object   &$item     The article/category object
	 * @param   mixed    &$params  The article params ItemMenu||Component
	 * @param   integer  $page     The 'page' number
	 *
	 * @return  mixed  void or true
	 *
	 * @since   1.6
	 */
	public function onContentBeforeDisplay($context, &$item, &$params, $page = 0) 
	{
//		return ;
		if(in_array($context, ['_com_content.categories','com_content.article','','',]) == false) //com_content.categories , com_content.article ,com_content.category 
			return;
			
	}
	
	/**
	 * Определение ID отображаемой категории статей для использования имени формы в полях
	 * @return type
	 */
	public function onBeforeRender()
	{
		

//toPrint(array_keys(get_object_vars($item)), $context.'  '.static::$X);
//		$layoutFile = __DIR__.DS.'layouts';
//		JLayoutHelper::render('cost.php','',$layoutFile);
//		JPluginHelper::getLayoutPath('fields', 'cost', 'default');
//toPrint('onBeforeRender');
//toPrint(123,'Context',0);
	
	}
	
	
	/**
	 * 
	 * @var array
	 */
	public static $DataKostyl = [];
	 
	
	/**
	 * Вызов из класса поля в редакторе Article <b>FieldCost->setup();</b>
	 * Вызывается Event`ом
	 * @param type $field		- object <b>class FieldCost;</b>
	 * @param type $name		- jform[com_fields][tsena]
	 * @param type $fieldname	- tsena
	 * @param type $type		- cost
	 */
//	public function onFieldCostSendData($FieldCost,$name,$fieldname,$type) {
//			$this->fields[$fieldname] = $FieldCost;
//			$this->fieldAliases[]	  = $FieldCost->fieldname;
//			$this->names[]			  = $FieldCost->name;
////toPrint('PluginField->onFieldCostSendData() FieldCost-> $name:<b>'.$name.'</b> $fieldname:<b>'.$fieldname.'</b>');//tsena		имя
//	}
	
	/**
	 * Пересылка полей формы поля заказы
	 * 
	 * Вызывается Event`ом
	 * @param type $field		- object <b>class FieldCost;</b>
	 * @param type $name		- jform[com_fields][tsena]
	 * @param type $fieldname	- tsena
	 * @param type $type		- cost
	 */
	public function onFieldOrderSendData() {//$FieldCost,$name,$fieldname,$type
//			$this->fields[$fieldname] = $FieldCost;
//			$this->fieldAliases[]	  = $FieldCost->fieldname;
//			$this->names[]			  = $FieldCost->name;
//toPrint('PluginField->onFieldCostSendData() FieldCost-> $name:<b>'.$name.'</b> $fieldname:<b>'.$fieldname.'</b>');//tsena		имя
	}

	/**
	 * 
	 * @param string $context
	 * @param int $itemId
	 * @param int $fieldId
	 * @param int $cost_summ
	 * @param array $dataFormCost
	 * @return array
	 */
	public function onFieldCostComputeData($context = '', $itemId = 0, $fieldId = 0, &$cost_summ = 0, $dataFormCost = []) {
		
//toPrint("PluginField->onFieldCostSendData() FieldCost-> \$name:<b>$name</b> $fieldname:<b>$fieldname</b> $context");//tsena		имя
		
		if(empty($dataFormCost))
			return false;
		
		$fieldValues = [];	//Массив параметров цен материала
		//Подкгрузка параметров цен чтобы взять имена цен, типы, операторы, 
		
		
		// Все значения для этого материала этого типа всех полей
		$query = "SELECT f.title, f.fieldparams, v.field_id, v.value
				  FROM #__fields f, #__fields_values v
				  WHERE v.item_id = $itemId AND v.field_id = f.id AND f.type = 'cost' AND f.state
				  ORDER BY field_id; ";
		$fieldValues = JFactory::getDbo()->setQuery($query)->loadObjectList('field_id'); 
		foreach ($fieldValues as &$fValue){
			$fValue->value		= (array)json_decode($fValue->value);
			$fValue->fieldparams = json_decode($fValue->fieldparams);
				
//toPrint($fValue,'$fValue',0,'message');
			foreach($fValue->value as $k => $list){
				foreach (get_object_vars($list) as $p => $col){
					if(is_object($col))
						$fValue->value[$k]->{$p} = (array)$col;
				}
			}
			foreach(get_object_vars($fValue->fieldparams->list_fields) as $p => $rowList){
					
				if(is_object($rowList))
					$fValue->fieldparams->list_fields->{$p} = (array)$rowList;
			}
		}
		
		$field_keys = array_keys($fieldValues);
		$field_keys_string = implode(',', $field_keys);
		
		if(empty($field_keys_string))
			return [];
		
		$query = "SELECT `list_id`,`content_id`,`field_id`,`user_id`,`type`,`params`,quantity,`cost`,`display`,`compute`,`sort`, '' message
				  FROM `#__cost` WHERE `content_id` = $itemId AND display = 1 AND field_id IN ($field_keys_string) AND `type` IN ('cost','!cost') -- ORDER BY  field_id, list_id, sort
				  ; ";
		$costs = JFactory::getDbo()->setQuery($query)->loadObjectList();
		
//toPrint($costs,'$costs',0);

		if(empty($costs))
			return [];
//		return $costs;
		
		
		$new_costs = [];
		$title_costs = [];
		
		
		$VerifyAndUpdateSql = [];
		
//toPrint($dataFormCost,'$_COST',0);
//toPrint($fieldValues,'$fieldValues',0);
		foreach ($costs as $i => &$cost){
			if(isset($dataFormCost[$cost->field_id]) == false || is_array($dataFormCost[$cost->field_id]) == false)
				continue;
			
//toPrint("\$cost->field_id $cost->field_id");
			
			if(isset($title_costs[$cost->field_id]) == false){
				
//toPrint($cost , "\$cost $cost->field_id" , 0);

				$title_costs[$cost->field_id]	= true;
				
//				if(JVersion::MAJOR_VERSION == 3){
//				}
				
				$link	= Joomla\Component\Content\Site\Helper\RouteHelper::getArticleRoute($cost->content_id);
				$url	= Joomla\CMS\Router\Route::_($link, false);
				$title	= JFilterInput::getInstance([], [], 1, 1)->clean($dataFormCost [$cost->field_id] ['item_title'], 'STRING');
//				$item->title = "<a href='$url' target='_blank'>{$item->title}</a>";
				
				$item = (object)[
//						'item_title'		=> true,
//						'item_id'			=> true,
						'title'				=> "<a href='$url' target='_blank'>{$title}</a> (#$cost->content_id)",
						'selectValue'		=> JFilterInput::getInstance([], [], 1, 1)->clean($dataFormCost [$cost->field_id] ['item_id'], 'INT'),
						'list_id'		=> -1,
						'sort'			=> -1,
						'field_id'		=> $cost->field_id,
						'content_id'	=> $cost->content_id,
						'user_id'		=> 0,
						'type'			=> 'cost',
						'params'		=> '{}',
//						'value'			=> 0,
						'quantity'		=> 0,
						'cost'			=> 0,
						'display'		=> true,
						'compute'		=> '☺',
						'message'		=> '',
						'select_param'	=> 'title',
						'option'		=> '',
						'unit_param'	=> 0,
						'account'		=> 0,
			//			'selectValue'] => 22,
			//			'title'] => 'Красный',
				];
				
							
				
				$new_costs[] = $item;
				
//				$item = clone $item;
//				$item->title		= JText::_('PLG_COST_PARAM_NUMBER');
//				$item->selectValue	= $cost->content_id;
//				$item->select_param	= '';
//				
//				$new_costs[] = $item;
					
//						$itemId = Factory::getApplication()->getMenu()->getActive()->id;
//						$link   = new Uri(Route::_('index.php?option=com_users&view=login&Itemid=' . $itemId, false));
//						$link->setVar('return', base64_encode(RouteHelper::getArticleRoute($article->slug, $article->catid, $article->language)));
					
//$url = JUri::root() . "?option=com_ajax&module=multi_form&format=raw&method=getForm$key&id=$this->id&" . JSession::getFormToken() . '=1&show=1' . $itemids;
//$newUrl = ContentHelperRoute::getArticleRoute($cost->content_id.':'.$import->alias, $import->catid);

//\Joomla\CMS\Helper\RouteHelper::

// better will be check if SEF option is enable!
//$router = new JRouterSite(array('mode'=>JROUTER_MODE_SEF));
//$newUrl = $router->build($newUrl)->toString(array('path', 'query', 'fragment'));
				
				
//				$_costs[$cost->content_id][$cost->field_id][-1][$cost->sort] = (object)
//				$_costs[$cost->content_id][$cost->field_id][-1]['title']		= JFilterInput::getInstance([], [], 1, 1)->clean($dataFormCost [$cost->field_id] ['item_title'], 'STRING');
//				$_costs[$cost->content_id][$cost->field_id][-1]['selectValue']	= JFilterInput::getInstance([], [], 1, 1)->clean($dataFormCost [$cost->field_id] ['item_id'], 'INT');
				
			}
			
			
			
			//Вычисление типа выбора продукта radio, checkbox, number
			$select_param_field = $fieldValues[$cost->field_id]->fieldparams->list_fields->select_param[$cost->list_id];
			$select_param_value = $fieldValues[$cost->field_id]->value[$cost->list_id]->select_param;
			$cost->select_param = str_ends_with($select_param_field, '?') ? $select_param_value : trim($select_param_field, "!");
				
			//Вычисление выбора продукта и его количества продукта
			$selectValue = [];
			$cost->selectValue = null;
			
				
			if(isset($dataFormCost [$cost->field_id] [$cost->list_id])){
//					$selectValue = $input->getArray(['array'], $dataForm ['cost'][$cost->content_id] [$cost->field_id] [$cost->list_id]);
					$selectValue = JFilterInput::getInstance([], [], 1, 1)->clean($dataFormCost [$cost->field_id] [$cost->list_id], 'ARRAY');
					
			}

			switch($cost->select_param){
				case 'radio':
					$cost->selectValue =  in_array($cost->sort, $selectValue);
					break;
				case 'checkbox':
					$cost->selectValue =  isset($selectValue[$cost->sort]) && $selectValue[$cost->sort] ? 1 : false;
					break;
				case 'number':
					$cost->selectValue =  isset($selectValue[$cost->sort]) && $selectValue[$cost->sort] ? $selectValue[$cost->sort] : false;
					break;
				default:
					$cost->selectValue =  false;
					break;
			}
			//Фильтр выбора продукта и его количества продукта 
			if($cost->selectValue)
				$cost->selectValue = JFilterInput::getInstance([], [], 1, 1)->clean($cost->selectValue, 'UINT');// Uint, Int, Alnum (БуквоЦиферный), Uint (без знака), string, array
			else{
				unset($costs[$i]);
				unset($cost);
				continue;
			}
				
				
			//Название продукта
			$cost->title		= $fieldValues[$cost->field_id]->value[$cost->list_id]->title[$cost->sort];
				
			//Название опции
			$option_param		= $fieldValues[$cost->field_id]->fieldparams->list_fields->option_param[$cost->list_id] ?? '';
			$options			= explode('|', $option_param);
			$option				= $fieldValues[$cost->field_id]->value[$cost->list_id]->option[$cost->sort];
			$cost->option		= $options && $options != [''] && isset($options[$option]) ? $options[$option] : $option;
				
			//Еденица измерения Штук, Кг. Грам. значение является индекс данных из плагина
			$cost->unit_param	= $fieldValues[$cost->field_id]->fieldparams->list_fields->unit_param[$cost->list_id] ?? false;
				
			//Способ вычисления суммы //переопределяет исходное значение в ценах массива
			$compute_param_field= $fieldValues[$cost->field_id]->fieldparams->list_fields->compute_param[$cost->list_id];
			$compute_param_value= $fieldValues[$cost->field_id]->value[$cost->list_id]->compute_param;
			$cost->compute		= str_ends_with($compute_param_field, '?') || empty($compute_param_field) ? $compute_param_value : trim($compute_param_field, "!");
			
			//Учет количества/Безлимит
			$account_param_field= $fieldValues[$cost->field_id]->fieldparams->list_fields->account_param[$cost->list_id] ?? '';
			$account_value		= $fieldValues[$cost->field_id]->value[$cost->list_id]->account[$cost->sort] ?? false;
			$cost->account		= str_ends_with($account_param_field, '!') ? trim($account_param_field,'!') : $account_value;
			
//toPrint('Cost:'.$cost->cost.' /accountParam:'.$account_param_field.' /accountValue:'.$account_value.' /Accaunt:'.$cost->account);	
			
				//Вычисление итоговой суммы покупки.
			if(in_array($cost->compute, ['+','-','*','/',]))// _-Скрыть, 0-Не выбрано, ☺-Показать, +, -, *, /
				$cost_summ;
			switch($cost->compute){
				case '+':
					$cost_summ += ($cost->cost * $cost->selectValue);
					break;
				case '-': 
					$cost_summ -= ($cost->cost * $cost->selectValue);
					break;
				case '*': 
					$cost_summ *= ($cost->cost * $cost->selectValue);
					break;
				case '/': 
					$cost_summ /= ($cost->cost * $cost->selectValue);
					break;
				default :
					break;
			}
				
			if($cost->account){
				if($cost->selectValue <= $cost->quantity){					
					$cost->quantity -= $cost->selectValue;
					
					if(is_array($VerifyAndUpdateSql)){
						$VerifyAndUpdateSql[] = "
UPDATE `#__cost` 
SET quantity = quantity - $cost->selectValue
WHERE type = 'cost' AND content_id = $cost->content_id AND field_id = $cost->field_id AND list_id = $cost->list_id AND sort = $cost->sort; ";
					}
				}else{

toPrint( "\$selectValue:$cost->selectValue \$quantity:$cost->quantity");
					$cost->message .= JText::_('PLG_COST_PARAM_NOTLIMIT');
//toPrint($cost);
					$VerifyAndUpdateSql = false;
					
					$message = JText::sprintf('PLG_COST_PARAM_NOTLIMIT_F', "$cost->title/$cost->title");
					
					JFactory::getApplication()->enqueueMessage($message,'warning');//'warning''info''error''critical''alert''emergency''notice''emergency'

				}
			}
			
//SELECT * FROM `j4_cost` WHERE type = 'cost' AND content_id = 97 AND field_id = 7 AND list_id = 1 AND sort = 1;
			
			$cost->currency = static::$currency->short_cur;
				
			$new_costs[] = $cost;	
			unset($cost);	
				
//$list = $input->getArray(['cost'=> [$cost->content_id => [$cost->field_id => [$cost->list_id => 'array']]]]);
//toPrint($list,'$list select_param:'.$cost->select_param. ' fieldId:'.$cost->field_id. ' listId:'.$cost->list_id.'     Sort:'.$cost->sort.'       Method:'.$input->getMethod(),0);
//toPrint($selectValue,'$selectValue select_param:'.$cost->select_param. ' fieldId:'.$cost->field_id. ' listId:'.$cost->list_id.'     Sort:'.$cost->sort.'       Method:'.$input->getMethod(),0);
//toPrint($dataForm ['cost'] [$cost->content_id],'$selectValue select_param:'.$cost->select_param. ' fieldId:'.$cost->field_id. ' listId:'.$cost->list_id.'     Sort:'.$cost->sort,0);

//				$fieldsInput = $dataForm ['cost'] [$cost->content_id] [$cost->field_id] [$cost->list_id] [$cost->sort] ;
//toPrint($dataForm,'$dataForm',0);
//toPrint($fieldsInput,'$fieldsInput',0);
//toPrint($selectValue,'$selectValue:'.$cost->selectValue.'   select_param:'.$cost->select_param.'    ---- sort:'.$cost->sort,0);
//toPrint($cost->selectValue,'$cost->selectValue select_param:'.$cost->select_param. ' fieldId:'.$cost->field_id. ' listId:'.$cost->list_id.'     Sort:'.$cost->sort,0);
		}
		
		if($VerifyAndUpdateSql == false){
			
			return false;
		}
		
		if(is_array($VerifyAndUpdateSql) && $VerifyAndUpdateSql)
			foreach ($VerifyAndUpdateSql as $sql){
				JFactory::getDbo()->setQuery($sql)->execute();
//toPrint($sql,'$VerifyAndUpdateSql',0);
			}
			
		
		
		unset($cost);
		return $new_costs;//$costs;
//		return [{'//title, selectValue, option, cost, '}];
//		return [{'//title, value, option, cost, '}];
	}
	
	
	
	/** 
	 * 
	 */
	public function onFieldCostSaveComputeData($context = '', $itemId = 0, &$cost_summ = 0) {
//toPrint('PluginField->onFieldCostSendData() FieldCost-> $name:<b>'.$name.'</b> $fieldname:<b>'.$fieldname.'</b>');//tsena		имя
		
	}
	
	/**
	 * Transforms the field into a DOM XML element and appends it as a child on the given parent.
     * 
     * Преобразует поле в XML-элемент DOM и добавляет его в качестве дочернего элемента к указанному родительскому элементу.
	 * 
	 *---------Вызывается в компоненте Fields методом FieldModel::checkDefaultValue()
	 *---------Вызывается в компоненте Fields методом FieldsHelper::prepareForm()
	 * Вызывается при Сохранение и при Применении.
	 *
	 * @param   stdClass    $field   Настройки поля. Поле
	 * @param   DOMElement  $parent  The field node parent.
	 * @param   JForm       $form    The form.
	 *
	 * @return  DOMElement
	 *
	 * @since   3.7.0
	 */
	public function onCustomFieldsPrepareDom($field, DOMElement $parentFieldset, JForm $form)//Редактор Article каждый раз для отдельного любого поля,
	{
		if($field->type != 'cost')
			return parent::onCustomFieldsPrepareDom($field,  $parentFieldset,  $form);
		
		$form->FieldCostParams = $field;
		
		$this->fields[$field->name] = $field;
		$this->names[$field->id] = $field->name;
		
//toPrint('onCustomFieldsPrepareDom()','',0,'pre');//
//toPrint($field,'$field',0,'pre');//
//		if($field->type != 'cost')
			return parent::onCustomFieldsPrepareDom($field,  $parentFieldset,  $form);
		
		//cost_id	product_id	param_id	user_id		type	params	value	amount
//		$query="
//SELECT cost_id, product_id, param_id,user_id,`type`,params,quantity,amount
//FROM `j4_cost` WHERE product_id =  AND 			";
		
//		JFactory::getDbo()->setQuery($query)->loadObjectList();
		
		
 
//					{
//					"name_param":[""],
//					"option_param":[""],
//					"unit_param":["0"],
//					"compute_param":["+"]
//					"select_param":["number?"]
//					}
		//$list_fields->name_param
		
//		if(isset($field->fieldparams['list_fields']) == false){
//			$field->fieldparams['list_fields'] = (object)[
//				"name_param"	=>[""],
//				"option_param"	=>[""],
//				"unit_param"	=>["0"],
//				"compute_param"	=>["+"],
//				"select_param"	=>["number?"],
////				"select"	=>"number"
//			];
//		}
			
        $field->paramsPlugin = $this->params;
//		$list_fields = $this->paramsField['list_fields'];
//		$list_fields = $this->fieldparams['list_fields'];
		
//		$field->article	= $form->getData();
//		static::$DataKostyl[$field->name] = $field; //$field->name, $field->id
//$field; // $field->params - возможно тут должны быть параметры , но они пустые, возможно надо их формировать для загрузки в поле
//$field->id		;//(int) ID - поля в материале
//$field->value; // JSON - с значениями поля из Article введенными данными
//$field->rawvalue; // JSON - с значениями поля из Article введенными данными
//$field->default_value;// = '{"product_options":{"name":[""],"options":["0"],"cost":["10"],"quantity":["5"],"account":[1],"display":[1]}}'; // пусто, возможно нам надо заполнять значениями по умолчанию.
//$field->name; // tsena -  имя поля
//$field->type;	// cost - тип поля
//$this->_name;	// cost - тип поля

//toPrint($field->id,'$form id ',0,'message');//7		(int) ID - поля в материале
//toPrint($field->type,'$form type ');//tsena		имя
//toPrint($field->name,'$form name ');//tsena		имя
//toPrint($this->_name,'$this name ');//cost		тип
//toPrint($field->type,'$field type ');//cost
//toPrint(array_keys((array)$this),'onCustomFieldsPrepareDom()$field '. get_class($this));
		
//		$field->paramPlugin = $this->params; 
//toPrint(array_keys((array)$field), ++static::$X.'x onCustomFieldsPrepareDom()$field '. get_class($field));
//toPrint($field->fieldparams,'$field->fieldparams '. get_class($field->fieldparams));// Поле   данные
//toPrint($field->params,'$field->params '. get_class($field->params));		//	Материал	JRegistry
//toPrint($this->params,'$this->params '. get_class($this->params));			//	Плагин
//toPrint($field->paramsPlugin,'$field->paramsPlugin '. get_class($field->params));		//	Материал	JRegistry
		
//toPrint( ( $field->article),'$field->article '. get_class($field->article));
//toPrint('id:'. $field->id.' name:'.$field->name,'$field '. get_class($field));

//toPrint($field->name,'$field name ');// tsena
//		$field2 = $form->getField($field->name);
//toPrint($field2,'$field2 '. empty($field2) ? ' False ' : get_class($field2));
//toPrint($field,'$field '. empty($field) ? ' False ' : get_class($field));
//toPrint($field->default_value,'$field default_value ');// 
//toPrint($field->value,'$field value ');//
//toPrint($field->rawvalue,'$field rawvalue ');//

//toPrint($field->params,'$field->params '. get_class($field->params));		//	Материал	JRegistry
//toPrint($field->fieldparams,'$field->fieldparams '. get_class($field->fieldparams));// Поле
//toPrint(array_keys((array)$this),'$this '. get_class($this->params));			//	Плагин
//toPrint($field,'$field '. get_class($field));			//	Плагин
//toPrint($form,'$form ');//
		
		
		
//		JFactory::getApplication()->getDispatcher()->addSubscriber($subscriber);

		
//		$this->paramsArticle	= $params->params;
//		$this->paramsField		= $params->fieldparams;
//		$this->paramsPlugin		= $params->paramsPlugin;
//		$this->article			= $this->form->getData();
//	public $paramsPlugin = []; 
//	public $paramsField = []; 
//	public $paramsArticle = []; 
//	public $article = [];
		$plugin = $this;
		/**
		 * Отсылка данных в поле таблицы редактора материала
		 */
		$sendFieldsData = function(JEvent $event)use($field,$form,$plugin)
		{
//toPrint($field->name, 'Cost->onFieldCostSendData()$field->name',0);
//toPrint($event->getArgument('fieldname'), 'Cost->onFieldCostSendData($event->fieldname)',0);
//toPrint($event->getArgument('subject')->fieldname, 'Cost->onFieldCostSendData($event->subject->fieldname)',0);
//toPrint($event, 'Cost->onFieldCostSendData($event)',0);
			if($field->name != $event->getArgument('fieldname'))
				return $field;
			
			$event->setArgument('plugin',$plugin); 
			$FieldCost		= $event->getArgument('subject');// Поле class JFormFieldCost;
			$plugin->fields[$FieldCost->fieldname]			= $FieldCost;
			$plugin->fieldAliases[]		= $FieldCost->fieldname;
			$plugin->names[]			= $FieldCost->name;
			
			$event->setArgument('fieldname',	$FieldCost->fieldname);
			$event->setArgument('name',			$FieldCost->name);
			$event->setArgument('paramsPlugin',	$field->paramsPlugin);
			$event->setArgument('paramsArticle',$field->params);
			$event->setArgument('paramsField',	$field->fieldparams);
//			$event->setArgument('article',		$form->getData());
//toPrint($field, 'Cost->onFieldCostSendData($field)',0);
			
			
//			$field->name				= $FieldCost->name;
//			$field->fieldname			= $FieldCost->fieldname;
			$FieldCost->paramsPlugin	= $field->paramsPlugin;
			$FieldCost->paramsArticle	= $field->params;
			$FieldCost->paramsField		= $field->fieldparams;
			$FieldCost->fieldId		= $field->id;
//			$FieldCost->article			= $form->getData();
			return $field;
		};
		
		if(JVersion::MAJOR_VERSION == 3){
			JFactory::getApplication()->triggerEvent('onFieldCostSendData', $sendFieldsData);
		}else{
			JFactory::getApplication()->getDispatcher()->addListener('onFieldCostSendData', $sendFieldsData);
		}
//			JEventDispatcher::getInstance()->trigger('onContentPrepare', $sendFieldsData);
		
//		JPluginHelper::importPlugin('system', 'order');
//		$data  = JPluginHelper::getPlugin('system', 'order')->params;
//		$params = new JRegistry($data);
		
		JPluginHelper::importPlugin('fields','cost');		
		
//		$plg = JPluginHelper::getPlugin('fields','cost');
//		$plg = JFactory::getApplication()->bootPlugin('cost','fields');
//		$plg = JFactory::getApplication()->bootPlugin('order','system'); 
		
//		$units = JEventDispatcher::getInstance()->trigger('onFieldCostGetUnits', array ());
		
		
		
		
		
		
		
		
		
		
		
		
		
//echo "<pre>". print_r($parentFieldset, true)."</pre>";
//toPrint($field, 'Cost->onCustomFieldsPrepareDom($field)',0,'pre');
//toPrint( 'Cost->onCustomFieldsPrepareDom($field, DOMElement $parentFieldset, JForm $form)','',0,'pre');  //  
//return '';
		return parent::onCustomFieldsPrepareDom($field,  $parentFieldset,  $form);
		
		
//toPrint($context,'$context #onContentBeforeSave',0);
//		return true;
//            toPrint($this->getOptions(),'$this->getOptions() #Static');
  
				$modules_type = $field->fieldparams->get('modules_type','ids');
//toPrint($modules_type,'$modules_type #onCustomFieldsPrepareDom');
				$field->query = $query = $this->queries[$modules_type];
				$field->key_field = 'id';
				$field->value_field = 'title';
                
//                $field->fieldparams->set('name','modules');
				$field->fieldparams->set('query',$query);
				$field->fieldparams->set('value_field','title');
				$field->fieldparams->set('key_field','id');
//		$field->type = 'sql' ;
		$fieldNode = parent::onCustomFieldsPrepareDom($field, $parentFieldset, $form);
        
		if (!$fieldNode)
		{
			return $fieldNode;
		}
//		$field->type = 'modules' ;
		$fieldNode->setAttribute('type', 'sql'); 
		$fieldNode->setAttribute('query', $query);
		$fieldNode->setAttribute('value_field', 'id');
		$fieldNode->setAttribute('key_field', 'title');

//            toPrint($form,'$form #onCustomFieldsPrepareDom');
//toPrint($field,'$field #onCustomFieldsPrepareDom');
//toPrint($parentFieldset,'$parentFieldset #onCustomFieldsPrepareDom');
//toPrint($fieldNode,'$fieldNode #onCustomFieldsPrepareDom');
                  
		return $fieldNode;
	} 
	 
 	
	
	/**
	 * The form field type.
	 *
	 * @var    string
	 * @since  1.6
	 */
//	public $type = 'Cost';

	/**
	 * set object
	 * @param JFormField|Joomla\CMS\Form\FormField $field 
	 * @return $this
	 */
	function onFieldCostGetPlugin($field = null){
		
		if($field){
			$field->plugin = $this;
			$field->paramsPlugin = $this->params;
		}
			
		
		return $this;
	}



	function onContentBeforeValidateData($form, &$data){
//		return ;
//toPrint( 'Cost->onContentBeforeValidateData()','',0,'message'); 
//toPrint($data['com_fields'],"\$data  :",0,'message');
		foreach($data['com_fields'] as $fieldAlias => $fieldData){
			//$fieldData - значения поля этого материала, по очереди перебераются данные всех полей
			
			if(empty(is_array($fieldData)))
				continue;
			
			$field = $this->fields[$fieldAlias]; //JFormFieldCost
			//$field							- параметры поля. -список таблиц JFormFieldCost
			//$field->paramsPlugin JRegistry	- параметры плагина
			//$this->params						-  параметры плагина
			//$field->paramsField JRegistry		- параметры поля
			//$field->paramsArticle JRegistry	- параметры Материала
			//$field->article JRegistry			- параметры полей материала
			//$field->article->get('com_fields')[$fieldAlias] string- параметры поля материала
//toPrint($fieldData,"\$fieldAlias $fieldAlias:",0,'message');
			
			if($field->fieldparams instanceof JRegistry){
				$list_fields = $field->fieldparams->get('list_fields');//Параметры Поля - $field->paramsField as JRegistry
//toPrint($list_fields->index_param,'$list_fields->index_param',0,'message');
				
			}
			else{
				$list_fields = $field->fieldparams->list_fields;
//				toPrint($field->fieldparams,'$field->fieldparams');
			}
//toPrint($list_fields->index_param,"\$list_fields->index_param  :",0,'message');
//toPrint($fieldData,"\$fieldAlias $fieldAlias:",0,'message');
//toPrint($fieldp->paramsPlugin,'Cost->onContentBeforeSave(): $field->fieldparams:'  ,0,'message');
			
			//$fieldData - массив данных всех таблиц этого поля
			foreach ($list_fields->index_param as $indexTable){ //$fieldData as $indexTable=> $table
				//$table - данные Таблицы 
				$table = $fieldData['i'.$indexTable];
				
				$data['com_fields'][$fieldAlias][$indexTable] = $table;
				unset($data['com_fields'][$fieldAlias]['i'.$indexTable]);
//toPrint($indexTable," $indexTable  :[$fieldAlias] [i$indexTable]",0,'message');
//				$fieldData[$indexTable] = $table;
//				unset($fieldData['i'.$indexTable]);
			}
		}
//toPrint($data['com_fields'],"\$data  :",0,'message');
			
	}

	/**
	 * Вызов после метода сохранения содержимого
	 * Статья передается по ссылке, но после сохранения, поэтому никакие изменения не сохранятся.
	 * Метод вызывается сразу после сохранения содержимого
	 *
	 * Пример после метода сохранения содержимого Статья передается по ссылке, 
	 * но уже после сохранения, поэтому никакие изменения не сохранятся. 
	 * Метод вызывается сразу после сохранения содержимого
	 * 
	 * @param   string   $context  The context of the content passed to the plugin (added in 1.6)
	 * @param   JTable   $item		A JTableContent object
	 * @param   boolean  $isNew    Новый материал. Если контент только собирается быть созданным
	 * @param   array    $data     The validated data
	 *
	 * @return  void
	 *
	 * @since   3.7.0
	 */
	public function onContentNormaliseRequestData($context, $objData = null, $form = null): void // Article*, 
	{		
		// Check if data is an array and the item has an id
		if ($context != 'com_content.article' || !is_object($objData) || is_null($objData->com_fields) || !is_array($objData->com_fields) || empty($objData->com_fields))
		{
			return;
		} 
		
		foreach($objData->com_fields as $fieldAlias => $fieldData){
			//$fieldData - значения поля этого материала, по очереди перебераются данные всех полей
			
//toPrint($fieldAlias,'Cost->onContentBeforeSave() $fieldAlias:',0,'message');
//toPrint($this->fields,'Cost->onContentBeforeSave() $this->fields:',0,'message');
//toPrint($fieldData,'Cost->onContentBeforeSave() $fieldData:',0,'message');
			if(false == is_array($fieldData) || is_null($this->fields[$fieldAlias]) )
				continue;
			
			
//			$field = $this->fields[$fieldAlias]; //JFormFieldCost
			$field = $form->FieldCostParams;
			
			if($field->fieldparams instanceof JRegistry){
				$list_fields = $field->fieldparams->get('list_fields');//Параметры Поля - $field->fieldparams as JRegistry
//toPrint($list_fields->index_param,'$list_fields->index_param',0,'message');
				
			}
			else{
				$list_fields = $field->fieldparams->list_fields;
//				toPrint($field->fieldparams,'$field->fieldparams');
			}
			
			//$fieldData - массив данных всех таблиц этого поля
			foreach ($list_fields->index_param as $indexTable){
				
				$table = &$fieldData['i'.$indexTable];
				
				if($table['type']!='cost')
					continue;
				
				$objData->com_fields[$fieldAlias][(int)$indexTable] = &$table;
				unset($objData->com_fields[$fieldAlias]['i'.$indexTable]);
//				$table = $fieldData[$indexTable];
				
//toPrint($data['com_fields'][$fieldAlias]['i'.$indexTable]," $indexTable  :\$data [com_fields] [$fieldAlias] [i$indexTable]",0,'message');
//toPrint($data['com_fields'][$fieldAlias]['i'.$indexTable]," $indexTable  :\$data [com_fields] [$fieldAlias] [i$indexTable]",0,'message');
				
			}
				
		}
		
//		$objData->com_fields['tsena'][0] = $objData->com_fields['tsena']['i0'];
//		unset($objData->com_fields['tsena']['i0']);
		
//toPrint($objData->com_fields,"onContentNormaliseRequestData($context):",0,'message');
	}

	/**
	 * Вызов после метода сохранения содержимого
	 * Статья передается по ссылке, но после сохранения, поэтому никакие изменения не сохранятся.
	 * Метод вызывается сразу после сохранения содержимого
	 *
	 * Пример после метода сохранения содержимого Статья передается по ссылке, 
	 * но уже после сохранения, поэтому никакие изменения не сохранятся. 
	 * Метод вызывается сразу после сохранения содержимого
	 * 
	 * @param   string   $context  The context of the content passed to the plugin (added in 1.6)
	 * @param   JTable   $item		A JTableContent object
	 * @param   boolean  $isNew    Новый материал. Если контент только собирается быть созданным
	 * @param   array    $data     The validated data
	 *
	 * @return  void
	 *
	 * @since   3.7.0
	 */
	public function onContentAfterSave($context, $item, $isNew, $data = array()): void // Article*, 
	{		
		// Check if data is an array and the item has an id
		if ($context != 'com_content.article' || !is_array($data) || empty($item->id) || empty($data['com_fields']))
		{
			return;
		} 
//toPrint($data['com_fields'],"onContentAfterSave():",0,'message');
//toPrint($field->name,'$field->name',0,'message');
//toPrint($data['com_fields'],'$data[com_fields]',0,'message');
//echo "<pre>". print_r($context, true)."</pre>";
//JFactory::getApplication()->enqueueMessage(print_r($context, true));

//toPrint( 'Cost->onContentAfterSave()','',0,'pre'); 
//toPrint($context,'Cost->onContentAfterSave()$context ',0,'pre'); 
//toPrint($isNew,'Cost->onContentAfterSave()$isNew ',0,'pre'); 
//toPrint(array_keys(get_object_vars($article)),'Cost->onContentAfterSave()$article type:'. get_class($article).' ',0,'message'); 
	}
	/**
	 * The save event.
     * 
     * Событие сохранения Материала/Категории.
	 *
	 * @param   string   $context  The context
	 * @param   JTable   $item     The table Article
	 * @param   boolean  $isNew    Is new item
	 * @param   array    $data     The validated Article data
	 *
	 * @return  boolean
	 *
	 * @since   3.7.0
	 */
	public function onContentBeforeSave($context, $item, $isNew, &$data = []){ // Article Редактор Сохранение - Вызывается один раз для этого поля, 
		
//toPrint($this->_name,'Cost->onContentBeforeSave() $plugin->_name:',0,'message');
//toPrint($this->_name,'Cost->onContentBeforeSave() $plugin->_name:',0,'message');
		
//		// Check the context
		// Only work on new SQL fields
		// Check if data is an array and the item has an id
		if ($context != 'com_content.article' || !is_array($data) || empty($item->id) || empty($data['com_fields']))//$context != 'com_fields.field'
		{
			return;
		}

//		// Create correct context for category
//		if ($context === 'com_categories.category')
//		{
//			$context = $item->extension . '.categories';
//
//			// Set the catid on the category to get only the fields which belong to this category
//			$item->catid = $item->id;
//		}
//
//		$parts = FieldsHelper::extract($context, $item);
		
//toPrint(array_keys((array)$item),'Cost->onContentBeforeSave()$context:'.$context.' class:'. get_class($item).'  ',0,'message'); 
		


//toPrint(( $data['com_fields']),$field->name."\:",0,'message');//array_key_exists
//toPrint($data['com_fields'],"\:",0,'message');
//toPrint($data['com_fields'],++static::$X.'x Cost->onContentBeforeSave()$data[com_fields]:'.$context  ,0,'message'); 
//		return true;
//		if($item->type != 'cost')
//			return parent::onCustomFieldsPrepareDom($field,  $parentFieldset,  $form);
//$context			= com_content.article
//$item->typeAlias	= com_content.article
		
		
//toPrint($this->params,  'Cost->onContentBeforeSave() $this->id:',0,'message'); параметры Плагина
//toPrint($this->_name,  'Cost->onContentBeforeSave() $this->_name:',0,'message');
//toPrint($data,  'Cost->onContentBeforeSave()',0,'message');
//$item->id; // ID article product
//$data;// Article с данными полей
//$data['id'];	// ID article product
//$data['com_fields']['tsena'];				//
//$data['com_fields']['tsena'][0]['name'];	// []= '' - Имя параметра
//$data['com_fields']['tsena'][0]['option'];	// []= 0  - индекс выбранной опции
//$data['com_fields']['tsena'][0]['cost'];	// []= 0  - Цена
//$data['com_fields']['tsena'][0]['quantity'];// []= 0  - Количество
//$data['com_fields']['tsena'][0]['account'];	// []= 1  - Учет 1 или 0
//$data['com_fields']['tsena'][0]['id'];		// = 7 - id поля в менеджере полей
//$data['com_fields']['tsena'][0]['type'];	// = cost
//$data['com_fields']['tsena'][0]['compute'];	// = =+-*/
//$data['com_fields']['kolicestvo'];			//
		 
		
//toPrint($data['com_fields']['tsena'][0]['option'],'$table[option]Save'.$i,0,'message');
//toPrint($data['com_fields'],'$data[com_fields]',0,'pre');
		
//JFactory::getApplication()->enqueueMessage("<pre>".print_r($data['com_fields'], true)."</pre>");
//echo "<pre>". print_r($data['com_fields'], true)."</pre>";
//		$fields = FieldsHelper::getFields($context, $item);
//		foreach($fields as $i => $fld){
//		if($fld->type != 'cost')
//				continue;
//toPrint(array_keys((array)$fld),$i.' Cost->onContentBeforeSave(): FieldsHelper::getFields():'. get_class($fld)  ,0,'message'); 
//toPrint($fld->id,$i.' Cost->onContentBeforeSave(): FieldsHelper::getFields()id:'. get_class($fld)  ,0,'message'); 
//toPrint($fld->name,$i.' Cost->onContentBeforeSave(): FieldsHelper::getFields()name:'. get_class($fld)  ,0,'message'); 
//toPrint($fld->fieldparams,$i.' Cost->onContentBeforeSave(): FieldsHelper::getFields()fieldparams:'. get_class($fld)  ,0,'message');  
//		}
		$queriesInsert = [];
		$queriesDelete = [];
		$userId = Joomla\CMS\User\UserHelper::getProfile()->id;
		
		
//toPrint($this->_name,'Cost->onContentBeforeSave() $plugin->_name:',0,'message');
//toPrint($this->fieldAliases,'Cost->onContentBeforeSave() $plugin->fieldAliases:',0,'message');
//toPrint(array_keys((array)$this),$i.' Cost->onContentBeforeSave(): $plugin:'. get_class($this)  ,0,'message'); 

//toPrint(JFactory::getApplication()->getInput()->get('jform')['com_fields']['tsena'],'',0,'message');//jform[params][list_currencies][default_cur][]	JFactory::getApplication()->getInput()->getRaw('jform')	com_fields

		//$data['com_fields'] - массив данных всех полей этого материала
		foreach($data['com_fields'] as $fieldAlias => $fieldData){
			//$fieldData - значения поля этого материала, по очереди перебераются данные всех полей
			
//toPrint($fieldAlias,'Cost->onContentBeforeSave() $fieldAlias:',0,'message');
//toPrint($this->fields,'Cost->onContentBeforeSave() $this->fields:',0,'message');
//toPrint($fieldData,'Cost->onContentBeforeSave() $fieldData:',0,'message');
			if(false == is_array($fieldData) || is_null($this->fields[$fieldAlias]) )
				continue;
			

			$field = $this->fields[$fieldAlias]; //JFormFieldCost
			//$field							- параметры поля. -список таблиц JFormFieldCost
			//$field->paramsPlugin JRegistry	- параметры плагина
			//$this->params						-  параметры плагина
			//$field->paramsField JRegistry		- параметры поля
			//$field->paramsArticle JRegistry	- параметры Материала
			//$field->article JRegistry			- параметры полей материала
			//$field->article->get('com_fields')[$fieldAlias] string- параметры поля материала
//toPrint($fieldData,"\$fieldAlias $fieldAlias:",0,'message');
			
			if($field->fieldparams instanceof JRegistry){
				$list_fields = $field->fieldparams->get('list_fields');//Параметры Поля - $field->fieldparams as JRegistry
//toPrint($list_fields->index_param,'$list_fields->index_param',0,'message');
				
			}
			else{
				$list_fields = $field->fieldparams->list_fields;
//				toPrint($field->fieldparams,'$field->fieldparams');
			}
			
//$field->fieldparams = $this->params;//fieldparams paramsField
//toPrint($field,"Cost->onContentBeforeSave() \$fieldAlias:$fieldAlias  -\$field:",0,'message');
//toPrint($fieldData,'Cost->onContentBeforeSave() $fieldData:',0,'message');
//toPrint($fieldData,"\$fieldData:",0,'message');
//toPrint($list_fields,"\$list_fields:",0,'message');
//toPrint($list_fields,"\$list_fields:",0,'message');
//toPrint($fieldp->paramsPlugin,'Cost->onContentBeforeSave(): $field->fieldparams:'  ,0,'message');
			
			//$fieldData - массив данных всех таблиц этого поля
			foreach ($list_fields->index_param as $indexTable){ //$fieldData as $indexTable=> $table
				//$table - данные Таблицы 
//				$table = &$fieldData['i'.$indexTable];
//				$data['com_fields'][$fieldAlias][$indexTable] = &$table;
//				unset($data['com_fields'][$fieldAlias]['i'.$indexTable]);
				$table = $fieldData[$indexTable];
				
//toPrint($data['com_fields'][$fieldAlias]['i'.$indexTable]," $indexTable  :\$data [com_fields] [$fieldAlias] [i$indexTable]",0,'message');
//toPrint($data['com_fields'][$fieldAlias]['i'.$indexTable]," $indexTable  :\$data [com_fields] [$fieldAlias] [i$indexTable]",0,'message');
				
				if($table['type']!='cost')
					continue;
				
//toPrint($table,"Cost->onContentBeforeSave() \$indexTable:$indexTable ",0,'message');
//				$data['com_fields'][$fieldAlias][$indexTable] = $table;
//				unset($data['com_fields'][$fieldAlias]['i'.$indexTable]);
				
//				settype($table, 'object');
				
				//$table; // - Таблица с данными товаров, цен, количества, одного списка
//toPrint($table,"\$table $indexTable:",0,'message');
//toPrint(array_keys((array)$table), ' Cost->onContentBeforeSave(): $table:'. get_class($table)  ,0,'message'); 
//				$product_options[$fieldAlias] = $fieldData;
				
//toPrint($list_fields,'$field->fieldparams',0,'message');
//return;
//toPrint($field->fieldparams->get('list_fields'),'$field->fieldparams',0,'message');
//			return true;
				$compute	= $table['compute_param'] ?: $list_fields->compute_param[$indexTable];
				$fieldId	= $table['id'];
				$type		= $table['type'];
				$queriesDelete[(int)$fieldId] = "DELETE FROM #__cost WHERE content_id = $item->id AND field_id = $fieldId AND type = 'cost'; ";
				$field->fieldparams;							//Параметры поля
//toPrint($compute,'$compute',0,'message');
//toPrint($id,"\$table $indexTable:".'$id dSave'.$i,0,'message');
//toPrint("\$indexTable:$indexTable   ",'', 0, 'message');
				foreach($table['option'] as $i => $option){
					
//toPrint("\$indexTable:$indexTable  \$i:$i",'', 0, 'message');
					if( ! isset($table['select'][$i]) && is_array($table['select'][$i]))
						$table['select'][$i] = 0;
					$title		= $table['title'][$i]	?? '';	//Имя опции
					$option		= $table['option'][$i]	?? '';	//Опция
					$cost		= $table['cost'][$i]	?: 0;	//Цена
					$cost		= str_replace(' ', '', $cost);
					$cost		= str_replace(',', '.', $cost);
					$quantity	= $table['quantity'][$i]?: 0;	//Количество
					$account	= $table['account'][$i] ?: 0;	//Учет/Безлим
//					if(!isset($table['display'][$i]))
//						$table['display'][$i] = 0;
					$display	= $table['display'][$i] ?? 0;	//Тип
					$type		= 'cost';// Показ
					$compute	= $compute ?? '+';
//toPrint($display,'$display',0,'message');
//					$params = ['name'=>$title,'option'=>$option,'cost'=>$cost,'quantity'=>$quantity,'account'=>$account,'display'=>$display,
//							'compute'=>$compute];
//					$params = json_encode($params);
					$params = '{}';
//toPrint($params,'PamamsFieldSave'.$i,0,'message');
//toPrint($params,'PamamsFieldSave'.$i,0,'message'); 
						
					$queriesInsert[] = "INSERT INTO `#__cost` (list_id, content_id, field_id,user_id,`type`,params,quantity,cost,compute,display,sort)
								  VALUES ($indexTable, $item->id,$fieldId,$userId,'$type','$params','$quantity','$cost','$compute','$display', $i);
						";
				}
//toPrint(array_keys((array)$field),'Cost->onContentBeforeSave(): $field:'  ,0,'message');
//toPrint($field->paramsArticle,'Cost->onContentBeforeSave(): $field->paramsArticle:'  ,0,'message');
//toPrint($field->fieldparams,'Cost->onContentBeforeSave(): $field->fieldparams:'  ,0,'message');
			}
			
//			$data['com_fields'][$fieldAlias] = json_encode($data['com_fields'][$fieldAlias]);
//			echo "<pre>". print_r($data['com_fields'][$fieldAlias], true)."</pre>";
//JFactory::getApplication()->enqueueMessage("<pre>".print_r($data['com_fields'][$fieldAlias], true)."</pre>");
		}
		$queries = [...$queriesDelete,...$queriesInsert];
//toPrint($queries,'Cost->onContentBeforeSave(): $queries:'  ,0,'message'); 
		
//$prefix = JFactory::getConfig()->get('dbprefix');
		foreach($queries as $query){
//toPrint(str_replace('#__', $prefix, $query),'Cost->onContentBeforeSave(): $queries:'  ,0,'message'); 
			JFactory::getDbo()->setQuery($query)->execute();
		}
		
//toPrint($data['com_fields'],'$data[com_fields]',0,'message');
		
		return true;
		 
		
		$query = "
		"; 
		
		$fieldParams;
		

//$data[''];//
//			$this->paramsPlugin	= $field->paramsPlugin;
//			$this->paramsArticle= $field->params;
//			$this->paramsField	= $field->fieldparams;
//			$this->article		= $form->getData(); 
		
		//cost_id	product_id	param_id	user_id		type	params	value	amount
				
		
//		JFactory::getDbo()->setQuery($query)->loadObjectList();
		
//		foreach($this->fields as $i => $fld){
//toPrint(array_keys((array)$fld),$i.' Cost->onContentBeforeSave(): $this->fields:'. get_class($fld)  ,0,'message'); 
//toPrint($fld->fieldparams,$i.' Cost->onContentBeforeSave(): $this->fields:'. get_class($fld)  ,0,'message'); 
//		}
////		$plg = JFactory::getApplication()->bootPlugin('cost','fields');
////toPrint(array_keys((array)$plg),'Cost->onContentBeforeSave(): $plg'  ,0,'message'); 
////		JPluginHelper::getPlugin('fields','cost');
////		FieldsHelper::getFieldTypes()
////toPrint(array_keys((array)$fld),$i.' Cost->onContentBeforeSave(): FieldsHelper::getFields():'. get_class($fld)  ,0,'message'); 
//		$fields = FieldsHelper::getFields($context, $item);
//		foreach($fields as $i => $fld){
//			if($fld->type != 'cost')
//				continue;
//toPrint(array_keys((array)$fld),$i.' Cost->onContentBeforeSave(): FieldsHelper::getFields():'. get_class($fld)  ,0,'message'); 
//toPrint($fld->id,$i.' Cost->onContentBeforeSave(): FieldsHelper::getFields()id:'. get_class($fld)  ,0,'message'); 
//toPrint($fld->name,$i.' Cost->onContentBeforeSave(): FieldsHelper::getFields()name:'. get_class($fld)  ,0,'message'); 
//toPrint($fld->fieldparams,$i.' Cost->onContentBeforeSave(): FieldsHelper::getFields()fieldparams:'. get_class($fld)  ,0,'message');  
//		}



//toPrint($data, '$data');
        
//toPrint($context,'$context #onContentBeforeSave',0);
//            toPrint($this->element,'$this->element #Static');
//            toPrint($this->getOptions(),'$this->getOptions() #Static');

		// If we are not a super admin, don't let the user create a SQL field
		if (!JAccess::getAssetRules(1)->allow('core.admin', JFactory::getUser()->getAuthorisedGroups()))
		{
			$item->setError(JText::_('PLG_FIELDS_SQL_CREATE_NOT_POSSIBLE'));

			return false;
		}

		$rules = $item->getRules()->getData();

		// Only change the edit rule and when it is empty
		if (key_exists('core.edit', $rules) && !$rules['core.edit']->getData())
		{
			// Set the denied flag on the root group
			$rules['core.edit']->mergeIdentity(1, false);
			JFactory::getApplication()->enqueueMessage(JText::_('PLG_FIELDS_SQL_RULES_ADAPTED'), 'warning');
//			return false;
		}

		return true;
	}
     
    
    /**
     * List queries db for all types lists.
     * @var array 
     */
//    protected $queries = [
//        'ids' => "
//SELECT  CONCAT(id ,': ',title,' :/',module,'/',position,'') title,
//     id  /*id, title, position, module, client_id ,*/
//FROM #__modules 
//WHERE client_id = 0
//ORDER BY position, module, id ; ",
//        
//        'pos' => "
//SELECT position id, CONCAT(position,' |', GROUP_CONCAT(`title` SEPARATOR ', ')) as title 
//FROM (
//SELECT  position,  CONCAT(id ,':/',title,' /',module) title,
//     id  /*id, title, position, module, client_id ,*/ 
//FROM #__modules  
//WHERE client_id = 0 AND position!=''
//ORDER BY position, module, id -- published, showtitle, params, ordering 
//) t 
//GROUP BY position ORDER BY position ; "];
    


    

    
    
	/**
	 * The form event. Load additional parameters when available into the field form.
	 * Only when the type of the form is of interest.
     * 
     * Событие формы.  Загрузите дополнительные параметры, когда они доступны, в форму поля. 
     * Только когда интересует тип формы. 
	 *
	 * @param   JForm     $form  The form
	 * @param   stdClass  $data  The data
	 *
	 * @return  void
	 *
	 * @since   3.7.0
	 */
	public function onContentPrepareForm(JForm $form, $data){ //Редактор Field
//toPrint( 'Cost->onContentPrepareForm()','',0,'message'); 
//toPrint($data,'',0,'message'); 
//$data['fieldparams']['subFields']['subFields0']['idField']
//toPrint(123,'$this #onContentPrepareForm');
        return parent::onContentPrepareForm( $form, $data);
    } 
    

	/**
	 * Returns the custom fields types.
	 * Trigger the event to create the field dom node
     * 
     * Возвращает типы настраиваемых полей.
	 *---------Вызывается в компоненте Fields методом FieldsHelper::getFieldTypes()
	 *
	 * @return  string[][]
	 *
	 * @since   3.7.0
	 */
	public function onCustomFieldsGetTypes() // Вызов в Field, Article, 
	{ 
        $types =  parent::onCustomFieldsGetTypes(); 
			
//toPrint($types, 'Cost->onCustomFieldsGetTypes()',0,'pre');

//            $types[] = ['type'=>'sql','label'=>'SQL'];
//            unset($types[0]);
//toPrint($types,'$types #onCustomFieldsGetTypes',0);
//toPrint($this,'$this #onCustomFieldsGetTypes');
        return $types;
	}
    
	/**
	 * Returns the path of the XML definition file for the field parameters
	 * 
	 * Возвращает путь к файлу определения XML для параметров поля
	 *
	 * @param   Form      $form  The form
	 * @param   stdClass  $data  The data
	 *
	 * @return  string
	 *
	 * @since   4.0.0
	 */
	protected function getFormPath(JForm $form, $data){ // Вызов в Field
//toPrint( 'Cost->getFormPath()','',0,'message');  
		return parent::getFormPath($form, $data);
	}
    
 
 
	/*
	 * On before field prepare
	 * Event allow plugins to modify the output of the field before it is prepared
	 * Before prepares the field value.
	 * 
	 * Перед подготовкой поля
	 * Событие позволяет плагинам изменять вывод поля до того, как оно будет подготовлено
	 * Перед подготовкой значения поля.
	 *---------Вызывается в компоненте Fields методом FieldsHelper::getFields() Сколько угодно раз (больше чем количество полей) 1 раз на поле
	 *
	 * @param   string     $context  The context.
	 * @param   \stdclass  $item     The item. Статья
	 * @param   \stdclass  $field    The field.
	 * 
	 *
	 * @return  void
	 *
	 * @since   3.7.0
	 */
	public function onCustomFieldsBeforePrepareField($context, $item, $field){// Клиент: Статья и Категория.
		 
//echo "<h1>WoW! $item->id T $field->type:$field->id</h1>"; 
//			return;
//		$field = new JFormField;
//		$field->render($context);
		if($field->type != 'cost')
			return;
		
		static $notDoubleExecute;
		
		$item->id;
		$field->id;			// id поля
		$field->name;		// alias поля
		$field->type;		// type поля
		$field->label;		// label поля
		$field->value;		// JSON value опции материала
		$field->context;	// компонент использования поля
		$field->fieldparams;//JRegistry настройки поля
		$field->params;		// JRegistry настройки шаблона поля
		
		if(empty($field->value))
			return;
		
		if(is_string($field->value))
			$field->value = json_decode($field->value);
//		else
//			return;
		if(empty($field->value))
			return;
//toPrint($field, '$field',0,'pre');
		if(is_null($notDoubleExecute))
			$notDoubleExecute = [];

		$key = $context.'_'.$item->id.'_'.$field->id;
		
		if(isset($notDoubleExecute[$key]) && $notDoubleExecute[$key])
			return;
		
		$this->fields[$field->name] = $field;
		
		$notDoubleExecute[$key] = true;
		
		$field->value = (array)$field->value;
		
		
		foreach ($field->value as $i => $list){
//			if(is_object($list))
//				$list->display = (array)$list->display;
//			if(! isset($list->display))
//				$list->display = [];
//			if(is_object($list->display))
//				$list->display = (array)$list->display;
//			if(is_object($list->account))
//				$list->account = (array)$list->account;
			foreach(get_object_vars($list) as $k => $col){
				if(is_object($col))
					$list->{$k} = (array)$col;
			}
				
		}
					
//toPrint($field->value, 'Cost->onCustomFieldsBeforePrepareField($context, $item, $field)					Before() ',0,'pre');
		
		$query = "SELECT list_id, sort, content_id, field_id, type, cost, display, compute, `quantity`
		FROM #__cost WHERE `content_id` = {$item->id} AND `field_id`={$field->id} AND `type` IN ('cost') ORDER BY list_id, sort; ";// AND display=1 
		
		$costsFromBD = JFactory::getDbo()->setQuery($query)->loadObjectList();
		
//toPrint($costsFromBD, 'Cost->onCustomFieldsBeforePrepareField($context, $item, $field)					Before() ',0,'pre');
		foreach($costsFromBD as $row){
			
//toPrint( $field->value[$row->list_id],'Cost->onCustomFieldsPrepareField() $field->value[$row->list_id]:',0,'message');
//				continue;
			
			if($row->display){
				$field->value[$row->list_id]->display[$row->sort] = $row->display;
				$field->value[$row->list_id]->quantity[$row->sort] = $row->quantity;
				$field->value[$row->list_id]->cost[$row->sort] = $row->cost;
				$field->value[$row->list_id]->compute = $row->compute;
				continue;
			}
			
			unset($field->value[$row->list_id]->title[$row->sort]);
			unset($field->value[$row->list_id]->option[$row->sort]);
			unset($field->value[$row->list_id]->cost[$row->sort]);
			unset($field->value[$row->list_id]->quantity[$row->sort]);
			unset($field->value[$row->list_id]->account[$row->sort]);
			unset($field->value[$row->list_id]->value[$row->sort]);
			if(is_array($field->value[$row->list_id]->select))
				unset($field->value[$row->list_id]->select[$row->sort]);
			if($field->value[$row->list_id]->select == $row->sort)
				$field->value[$row->list_id]->select[$row->sort] = 0;
			
			unset($field->value[$row->list_id]->display[$row->sort]);
		}
//toPrint($context,'Type :'.$field->type,0,'pre');
		
//toPrint($field->value, 'Cost->onCustomFieldsBeforePrepareField($context, $item, $field)					Before() ',0,'pre');
	}
    
	/**
	 * Prepares the field value.
	 * Gathering the value for the field
     * 
     * Готовит значение поля.
	 * Сбор значения для поля
	 *---------Вызывается в компоненте Fields методом FieldsHelper::getFields() Сколько угодно раз (больше чем количество полей) 1 раз на поле
	 *
	 * @param   string    $context  The context.
	 * @param   stdclass  $item     The item. Статья
	 * @param   stdclass  $field    The field.
	 *
	 * @return  string Сбор значения для поля . Потом массив этих возвращаемых значений из разных плагинов для одного поля склеиваются.
	 *
	 * @since   3.7.0
	 */
    public function onCustomFieldsPrepareField($context, $item, $field){// Статья клиента вывод
	
	
//if($field->type == 'order')
//if($context == 'com_content.categories')
//toPrint(array_keys((array)$item)," Id:$item->id catId:$item->catid ".'Type :'.$field->type . ' ('.$context.') - '.$item->id,0,'pre');
//toPrint($item->title,'Type :'.$field->type . ' ('.$context.') - '.$item->id,0,'pre');//$this->categoryFieldsOrderIds
//toPrint($this->categoryFieldsOrderIds,"Type :$field->type ($context) - $item->id --  $item->title",0,'pre');//
//toPrint('PlgFieldsCost->onCustomFieldsPrepareField() type:'.$field->type,'',0,'message');
//toPrint('PlgFieldsCost->onCustomFieldsPrepareField() type:'.$field->type,'',0,'pre');
//		$field->paramField = 
//toPrint( $field->type,'Cost->onCustomFieldsPrepareField()',0,'message');
		if($field->type != 'cost')
			return parent::onCustomFieldsPrepareField($context, $item, $field);
		
//		$field->paramPlugin = $this->params;
		
//toPrint($context,'onCustomFieldsPrepareField',0,'pre');
		
//toPrint($this->categoryFieldsOrderIds,'$field->categoryFieldsOrderIds'); 
//		$item_id = $item->id;
		
//		$fields = FieldsHelper::getFields($context, $item);
//		$fieldsOrders = [];
		
//		foreach ($fields as $f){
//			if($f->type == 'order')
//				$fieldsOrders[] = $f;
//		}
		
//toPrint(array_keys((array)$field), ++static::$X.' $field name:'.$field->name.' type:'.$field->type.' class:'. get_class($field));
//toPrint(array_keys((array)$item),static::$X.' $item '. get_class($item));
if(false && static::$X==2){
toPrint(($fieldsOrders),static::$X++.' $fields $itemId:'. $item->id. '  $context:'. $context. '  $fieldType:'. $field->type.'('.$field->title.')',0);
//toPrint(array_keys((array)$item),static::$X.' $item '. get_class($item));
//toPrint(array_keys((array)$item),static::$X.' $item '. get_class($item));
}
//toPrint($field->fieldparams,'$field->fieldparams '. get_class($field->fieldparams));// Поле
//toPrint($field->params,'$field->params '. get_class($field->params));		//	Материал	JRegistry
//toPrint($this->params,'$this->params '. get_class($this->params));			//	Плагин
//toPrint($field->value,'$field->value '. gettype ($field->value));			//	Значение
		
//toPrint('Cost-><b>onCustomFieldsPrepareField</b>($context, $item, $field)');
//		$value = [];
		
		if(is_string($field->value))
			$field->value = json_decode($field->value); //rawvalue //value
//		if(is_object($field->value))
//			$value = (array)$field->value;
//toPrint($field->value,'$field->value '. gettype ($field->value));			//	Значение
		
//toPrint($context,'Type :'.$field->type,0,'pre');
		
//$ignore = array('GLOBALS', '_FILES', '_COOKIE', '_POST', '_GET', '_SERVER', '_ENV', 'ignore');
//$vars = array_diff_key(get_defined_vars() + array_flip($ignore), array_flip($ignore));
//toPrint(array_keys($vars),'$this'); 
//toPrint(array_keys(get_object_vars($this->_subject)),'$this->_subject'); 
//toPrint($this->queries,'queries #onCustomFieldsPrepareField');


//toPrint(parent::onCustomFieldsPrepareField($context, $item, $field),'$this #onCustomFieldsPrepareField',0);
        return parent::onCustomFieldsPrepareField($context, $item, $field);
    }
	
	 

	/**
	 * 
	 * On after field render
	 * Event allows plugins to modify the output of the prepared field 
	 * 
	 * После рендеринга поля
	 * Событие позволяет плагинам изменять вывод подготовленного поля.
	 * 
	 *  Вызывается сколько угодно раз (больше чем количество полей) (окого 2х раз для каждого поля)
	 * 
	 * @param type $context
	 * @param type $item
	 * @param type $field
	 * @param type $value
	 * @return  void
	 */
	public function onCustomFieldsAfterPrepareField($context, $item, $field, &$value) {// Статья клиента вывод
		 
//toPrint($field->value,'Cost->onCustomFieldsAfterPrepareField($context, $item, $field, &$value)				After() ' ); 
	}
	
	
	
	public function getVar($name,$default = null) {
		return $this->{$name} ?? $default;
	}
	public function setVar($name,$value) {
		$this->{$name} = $value;
		return $this;
	}
	

	
	
//PlgSystemFields->Display()
//toPrint('PlgSystemFields->Display()','',0,'message');
//toPrint('PlgSystemFields->Display()','',0,'pre');
//	public function onCustomFieldsBeforeDisplay($context, $item, $field, $displayType, $params)
//	{  
//echo "<pre>$field->type</pre>";
//toPrint($field->type,"FieldCostField->onCustomFieldsBeforeDisplay($displayType)",'pre');
//	}
	
//	public function onCustomFieldsContentPrepare($context, $item, &$fields)
//	{  
//toPrint(count($fields),'<b>FieldCostField->onCustomFieldsContentPrepare()</b>',0,'pre');
//	}
}
