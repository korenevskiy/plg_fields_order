<?php defined('_JEXEC') or die; 
//namespace Joomla\CMS\Form\Field;
/**------------------------------------------------------------------------
 * Field - Table Conatinier data fields
 * ------------------------------------------------------------------------
 * author    Sergei Borisovich Korenevskiy
 * Copyright (C) 2010 //explorer-office.ru. All Rights Reserved.
 * @package  GridFields
 * @license  GPL   GNU General Public License version 2 or later;
 * @modifed  2022-03-25
 * @version  3
 * Websites: //explorer-office.ru/download/joomla/category/view/1
 * Technical Support:  Forum - //fb.com/groups/multimodule
 * Technical Support:  Forum - //vk.com/multimodule
 */ 

// Tasks:
// 1: Fix selected radiobutton with drag line in table
//
 
use Joomla\CMS\Factory as JFactory;
use Joomla\CMS\Document\Document as JDocument;
use Joomla\CMS\Language\Text as JText;
use Joomla\CMS\HTML\HTMLHelper as JHtml;
use Joomla\CMS\Form\FormHelper as JFormHelper;
use Joomla\CMS\Form\Field\ListField as JFormFieldList;
use Joomla\CMS\Form\Field\SqlField as JFormFieldSql;
use Joomla\CMS\Form\FormField as JFormField;
use Joomla\CMS\Helper\ModuleHelper as JModuleHelper;
use Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use Joomla\CMS\Layout\FileLayout as JLayoutFile;
use \Joomla\CMS\Version as JVersion;
//use Joomla\CMS\Layout\BaseLayout as JLayoutBase;

use Joomla\CMS\Layout\FileLayout;
use  Joomla\Database\Exception;
//use Joomla\CMS\Helper\ModuleHelper as JModuleHelper;

use Joomla\CMS\Form\Field;
//use GridFieldsField;
//use JFormFieldGridFields;
//use Joomla\CMS\Form\Field\GridFieldsField;
//use Joomla\CMS\Form\Field\JFormFieldGridFields;
//use Joomla\CMS\Form\Field\GridFieldsField as JFormFieldGridFields;
//use Joomla\CMS\Form\Field\JFormFieldGridFields as GridFieldsField;
 

if(class_exists('JFormFieldGridFields') == false && file_exists(__DIR__ . '/gridfields.php')){
	require_once  __DIR__ . '/gridfields.php';
}
//echo "<h1>123123</h1>";
//toPrint('abraCadabra','$this',0,'message');
//toPrint('abraCadabra','$this',0,'message');
//return;
//if(file_exists(__DIR__ . '/../functions.php'))
//	require_once  __DIR__ . '/../functions.php';


//toPrint(1234,'1234',0,'pre',true);
//echo "<pre>";
//print_r('Какого хрена', true);
//echo "</pre>";

//toPrint('abraCadabra','$this',0,'pre');
//return;

JHtml::_('jquery.framework');
JHtml::_('bootstrap.framework');

//JFormHelper::addFieldPath(__DIR__.DIRECTORY_SEPARATOR.'');

JFormHelper::loadFieldClass('field');
JFormHelper::loadFieldClass('list');
JFormHelper::loadFieldClass('sql');

//namespace Joomla\CMS\Form\Field;

//   \Joomla\CMS\Form\FormField
//JFormHelper::loadFieldClass('filelist');
//use Joomla\CMS\Form\Field\FilelistField as JFormFieldFileList;

class JFormFieldGridFieldsMod extends JFormFieldGridFields  {//JFormField  //JFormFieldList //JFormFieldSql 
//JFormFieldGridFields  -- class for custom uses -- имя класса для испльзования в своих компонентах и модулях
//GridFieldsField -- class for system location path -- имя класса для размещения в системной папке полей, 
//
//Joomla\CMS\Form\Field\TableFieldsField/
//JFormFieldGridFields
 
	/**
	 * Method to instantiate the form field object.
	 *
	 * @param   Form  $form  The form to attach to the form field object.
	 *
	 * @since   1.7.0
	 */
    public function __construct($form = null){
//        $this->default;
//        $script = "jQuery(function(){
//            
//            });";
 
        
        parent::__construct($form);
    }
    
	/**
	 * Method to attach a JForm object to the field.
	 *
	 * @param   \SimpleXMLElement  $element  The SimpleXMLElement object representing the `<field>` tag for the form field object.
	 * @param   mixed              $value    The form field value to validate.
	 * @param   string             $group    The field name group control value. This acts as as an array container for the field.
	 *                                       For example if the field has name="foo" and the group value is set to "bar" then the
	 *                                       full field name would end up being "bar[foo]".
	 *
	 * @return  boolean  True on success.
	 *
	 * @since   1.7.0
	 */
	public function setup(\SimpleXMLElement $element, $value, $group = null)
	{
//toPrint(gettype($value['index_param'][0]),'$value',0,'pre');
//toPrint($value['index_param'],'$value[index_param]',0,'pre');
//toPrint($value,'$value',0,'pre');
	
		$indexMax = 0;

		if(isset($value['index_param'])){
			//unset( $value['index_param']);
			$new_value = [];
			
			foreach ((array)$value['index_param'] as $i => $index_param){
				$index_param = $index_param === null || $index_param === '' ? $i : $index_param;
				
				$new_value['index_param'][$index_param]		= (string)$index_param;
				$new_value['name_param'][$index_param]		= $value['name_param'][$i];
				$new_value['option_param'][$index_param]	= $value['option_param'][$i];
				$new_value['unit_param'][$index_param]		= $value['unit_param'][$i];
				$new_value['compute_param'][$index_param]	= $value['compute_param'][$i];
				$new_value['account_param'][$index_param]	= $value['account_param'][$i];
				$new_value['select_param'][$index_param]	= $value['select_param'][$i];
				$new_value['layout_param'][$index_param]	= $value['layout_param'][$i];
			}
			$value = $new_value;
			$indexMax = max($new_value['index_param']);
		}
		elseif(isset($value['unit_param'])){
			foreach ((array)$value['unit_param'] as $i => $unit_param){
				$value['index_param'][$i] = (string)$i;
			}
			$indexMax = max($value['index_param']);
		}
		
		if(isset($value['indexMax']))
			$indexMax = max($value['indexMax'], $indexMax);
		
//toPrint($value,'$value No',0,'pre',true);
//        $element['multiple'] = true; 
		$this->addColumn(static::createField("<field type=\"hidden\"  />"),'index_param'); //default=\"\" value=\"\"
		
		
		$result = parent::setup($element, $value, $group);
        
		$this->caption = $this->title;
		$this->caption .= static::createField("<field name=\"indexMax\" type=\"hidden\" />",$indexMax)->getInput();
		
//toPrint($this->value,'$value  ',0,'pre',true);
        return $result;
         
	}
	
//	public function setValue( $value = null)
//	{
////toPrint($this,'$this',0,'pre');
//		 
//		
////        $element['multiple'] = true; 
////		$this->addColumn(static::createField("<field type=\"hidden\" />"),'index_param');
//        
////toPrint($value,                   '$value'              ,0,'message',true); 
//        parent::setValue($value);
//	}
	
//toPrint($field,'$field',0,'pre'); //->children()
//toPrint($fieldXML,'$fieldXML',0,'pre'); //->children()
//toPrint($this->rowsLayoutData,'$this->rowsLayoutData',0,'pre'); 
//        $fieldText = new Joomla\CMS\Form\Field\TextField;
//toPrint((array)$element->xpath('field'),'$element',0,'pre'); //->children()
//toPrint($this->columns,'$element',0,'pre'); //->children()
//toPrint($this->columnsXML,'$element',0,'pre'); //->children()
        
//toPrint((string)$element->default,'Default: $element',0,'pre');
//toPrint($element,'Setup: $element',0,'pre');
//toPrint($this->columnsLayoutData,'Setup: $element',0,'pre'); 
    
	  
    
}



?> 