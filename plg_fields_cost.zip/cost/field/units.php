<?php defined('_JEXEC') or die; 
/**------------------------------------------------------------------------
 * field_cost - Fields for accounting and calculating the cost of goods
 * ------------------------------------------------------------------------
 * author    Sergei Borisovich Korenevskiy
 * Copyright (C) 2010 www./explorer-office.ru. All Rights Reserved.
 * @package  mod_multi_form
 * @license  GPL   GNU General Public License version 2 or later;  
 * Websites: //explorer-office.ru/download/joomla/category/view/1
 * Technical Support:  Forum - //fb.com/groups/multimodule
 * Technical Support:  Forum - //vk.com/multimodule
 */  
 

use Joomla\CMS\Plugin\PluginHelper as JPluginHelper;
use Joomla\Registry\Registry as JRegistry;
use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\Form\Field\ListField as JFormFieldList;
use \Joomla\CMS\Form\FormField as JFormField;
use Joomla\CMS\Language\Text as JText;
use Joomla\CMS\HTML\HTMLHelper as JHtml; 
use Joomla\CMS\Factory as JFactory;
//use Joomla\CMS\Document\Document as JDocument;
//use Joomla\CMS\Form\FormHelper as JFormHelper;
use Joomla\CMS\Helper\ModuleHelper as JModuleHelper;
use Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use Joomla\CMS\Layout\FileLayout as JLayoutFile;
use \Joomla\CMS\Version as JVersion;
use Joomla\CMS\Form\Form as JForm;
//use Joomla\CMS\Layout\BaseLayout as JLayoutBase;
 

if(file_exists(__DIR__ . '/../functions.php'))
	require_once  __DIR__ . '/../functions.php';



if(explode('.', PHP_VERSION)[0] < 8 && JVersion::MAJOR_VERSION == 3){
	class_alias( 'JFormFieldList','Joomla\\CMS\\Form\\Field\\ListField');
}

 
//JFormFieldList		
class JFormFieldUnits extends JFormFieldList  {//JFormField  //JFormFieldList   \Joomla\CMS\Form\FormField  Joomla\CMS\Form\Field;
	
	
	public function getOptions() {
		
		static $options;
		
		if(isset($options) && is_array($options) && $options){
			
			return $options;
		}
		
			
		$options = parent::getOptions();
		
//		JPluginHelper::importPlugin('system', 'order');
//		$data  = JPluginHelper::getPlugin('system', 'order')->params;
//		$params = new JRegistry($data);
		
		JPluginHelper::importPlugin('fields','cost');		
		
//		$plg = JPluginHelper::getPlugin('fields','cost');
//		$plg = JFactory::getApplication()->bootPlugin('cost','fields');
//		$plg = JFactory::getApplication()->bootPlugin('order','system'); 
		
//		$plg->loadLanguage('',JPATH_PLUGINS.'/fields/cost/');
//		$plg->loadLanguage('plg_fields_cost',JPATH_PLUGINS.'/fields/cost/');
		
		$units = [];
		
//		if(JVersion::MAJOR_VERSION == 3){
//			$units = JFactory::getApplication()->triggerEvent('onFieldCostGetUnits', []);
//		}else{
////			$units = JFactory::getApplication()->getDispatcher()->addListener('onFieldCostGetUnits', []);
//			$units = JEventDispatcher::getInstance()->trigger('onFieldCostGetUnits', array ());
//		}
		$units = JFactory::getApplication()->triggerEvent('onFieldCostGetUnits', []);
		
		if(isset($units) && is_array($units) && isset($units[0]) && is_array($units[0]))
			$units = $units[0];
		
//toPrint($plg,'$plg',0,'pre');
//toPrint($units,'$units',0,'pre');
//toPrint(PlgFieldsCost::$units,'PlgFieldsCost::$units',0,'pre');
//return;
//		if(empty($plg)){
//			return $options;
//		}
		
//		$plg->loadLanguage('',JPATH_PLUGINS.'/fields/cost/');
//		$plg->loadLanguage('plg_fields_cost',JPATH_PLUGINS.'/fields/cost/');
		
//toPrint($plg->onFieldCostGetUnits(),'$plg->onFieldCostGetUnits()',0,'pre');
		foreach ($units as $i => $unit){ 
			$options[] = JHtml::_('select.option', $i, JText::_($unit->name_unit).' ('.JText::_($unit->short_unit).')');
		} 
//toPrint($options,'$options',0,'pre');
			
//		if(empty($plg->params['list_units'])){
//			$list = $plg->onFieldCostGetUnits();
//			
//			foreach ($list as $i => $unit){ 
//				$options[$i] = JHtml::_('select.option', $i, JText::_($unit->name_unit).' ('.JText::_($unit->short_unit).')');
//			} 
//		}else{
//			$list = $plg->params['list_units'];
//			
//			foreach (array_keys($list->type_unit) as $key){ 
//				$options[$key] = JHtml::_('select.option', $key, JText::_($list->name_unit[$key]).' ('.JText::_($list->short_unit[$key]).')');
//			} 
//		}
		
		
		 
		
		return $options; 
		
		
	} 
}