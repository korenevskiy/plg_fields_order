<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Fields.Sql
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;



//Поле выводимое в редакторе материалов ------ Материал !!!
//Это поле вызывается автоматически исходя из типа Кастомного поля.
//файл поля с именем типа поля ищется в папке fields а потом ищется в системной папке fields
//----------------------------------------------------------------------------------------
use Joomla\CMS\Factory as JFactory;
//use Joomla\CMS\Form\Form as JForm;
use Joomla\CMS\Plugin\PluginHelper as JPluginHelper;
use Joomla\Registry\Registry as JRegistry;
use Joomla\CMS\Form\Field\ListField as JFormFieldList;
use \Joomla\CMS\Form\FormField as JFormField;
use Joomla\CMS\Language\Text as JText;
use Joomla\CMS\HTML\HTMLHelper as JHtml;
//use Joomla\CMS\Document\Document as JDocument;
use Joomla\CMS\Form\FormHelper as JFormHelper;
use Joomla\Component\Fields\Administrator\Helper\FieldsHelper as JFieldsHelper;
use Joomla\CMS\Helper\ModuleHelper as JModuleHelper;
use Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use Joomla\CMS\Layout\FileLayout as JLayoutFile;
use \Joomla\CMS\Version as JVersion;
use Joomla\CMS\Form\Form as JForm;
use Joomla\CMS\Event\GenericEvent as JEvent;
//use Joomla\CMS\Layout\BaseLayout as JLayoutBase;
// return;

//if(file_exists(__DIR__ . '/../functions.php'))
//	require_once  __DIR__ . '/../functions.php';


if(file_exists(JPATH_ROOT.'/functions.php'))
	require_once  JPATH_ROOT.'/functions.php'; 

if(explode('.', PHP_VERSION)[0] < 8){
	require_once __DIR__ . '/../lib/helper.php'; 
}

//if(file_exists(__DIR__ . '/../field/gridfields.php'))
//	require_once  __DIR__ . '/../field/gridfields.php'; 

//toPrint(get_defined_vars(),'Доступные переменные !!!!!!!!!!',0);

//echo "fields/cost.php";
//if(explode('.', PHP_VERSION)[0] < 8){
//	require_once  JPATH_ROOT . '/libraries/vendor/symfony/polyfill-php80/Php80.php';
//	require_once  JPATH_ROOT . '/libraries/vendor/symfony/polyfill-php80/bootstrap.php';
////	return;
//}

//Поле выводимое в редакторе материалов
/**
 * Поле выводимое в редакторе материалов
 */
class JFormFieldCost extends JFormField  {//JFormField//JFormFieldList   \Joomla\CMS\Form\FormField  Joomla\CMS\Form\Field;
	
	function __construct($form = null){
//toPrint($form,'FieldCost::__construct($form)',0);
		
//		PlgFieldsCost::$DataKostyl[$this->fieldname] = true;
		
		JFormHelper::addFieldPath(__DIR__ . '/../field/');//gridfields.php
//		JFormHelper::loadFieldClass($type);
//		JFormHelper::loadFieldType('gridfields');
		
		/**
		 *  $this->plugin = (object)PlgFieldsCost; 
		 */
        JFactory::getApplication()->triggerEvent('onFieldCostGetPlugin',[$this]);
		
//		JFactory::getApplication()->getDispatcher()->dispatch('onFieldCostGetPlugin',$this);
//		JFactory::getApplication()->getDispatcher()->addListener('onFieldCostGetPlugin', $this);
		
//toPrint($event,'$event',0); 
//toPrint($this->paramsPlugin,'$fieldData',0);  
		
//toPrint((PlgFieldsCost::$DataKostyl[$this->fieldname]),'$params',0); 
//		$this->hiddenLabel = true;
//		$this->setValue($value);
		parent::__construct($form);
		
		
//toPrint($this->type,'$this->type',0); 
	}
	
	/**
	 * Параметры Плагина
	 * @var array
	 */
	public $paramsPlugin = [];
	
	/**
	 * Плагин
	 * @var array
	 */
	public $plugin = null;
	
	/**
	 * Параметры Поля
	 * @var array
	 */
	public $paramsField = [];
	
	/**
	 * Параметры Материала
	 * @var array
	 */
	public $paramsArticle = [];
	
	public $article = [];


    /**
	 * Строка описания таблицы.
	 *
	 * @var    bool
	 * @since  3.2
	 */
    public $hiddenLabel = true; 


	/**
	 * Name of the layout being used to render the field
	 *
	 * @var    string
	 * @since  4.0.0
	 */
//	protected $layout = 'joomla.form.field.list';
	
	
	/** НЕТ вызова
	 * Simple method to set the value 
	 * 
	 * Простой способ установки значения
	 *
	 * @param   mixed  $value  Value to set
	 *
	 * @return  void
	 *
	 * @since   3.2
	 */
	public function setValue($value)
	{
//toPrint($value,' setValue($value) '. get_class($value),0,'message',true);		//	 НЕТ вызова
//		return;
		
		parent::setValue($value); 
	}
 
	/**
	 * Method to attach a Form object to the field.
	 *
	 * @param   \SimpleXMLElement  $element  The SimpleXMLElement object representing the `<field>` tag for the form field object.
	 * @param   mixed              $value    The form field value to validate.
	 * @param   string             $group    The field name group control value. This acts as as an array container for the field.
	 *                                       For example if the field has name="foo" and the group value is set to "bar" then the
	 *                                       full field name would end up being "bar[foo]".
	 *
	 * @return  boolean  True on success.
	 *
	 * @since   1.7.0
	 */
	public function setup(\SimpleXMLElement $element, $value = '', $group = null){
		
//toPrint($element, 'setup($element)');
		$success = parent::setup($element, $value, $group);
		
//toPrint($value,'setup($value)',0,'pre',true);
//toPrint(array_keys((array)$this),'FieldProperties',0,'pre',true);
//return false;
//		$val = json_decode($value);// new JRegistry($value);
		if(is_string($value))
			$this->value = (array)json_decode($value);
		else
			$this->value = (array)$value;
//toPrint($val, 'setup($value)');
//toPrint($this->value, 'setup($value)');
		//$this->name		- jform[com_fields][tsena]
		//$this->fieldname  - tsena
		//$this->type		- cost
		
//		$event = JEvent::create('onFieldCostSendData',['subject'=>$this,'name'=>$this->name,'fieldname'=>$this->fieldname,'type'=>$this->type,'id'=>$this->id]);
//		$event = JFactory::getApplication()->getDispatcher()->dispatch('',$event);
//		$plugin = $event->getArgument('plugin');
//		$app = $plugin->getVar('app');
		
		$formArticle = $this->form->getData();
		
		$contentId = $formArticle['id'];
		

		$fieldId = $this->form->FieldCostParams->id;
		
		if(empty($contentId) || empty($fieldId))
			return true;
//		jform[com_fields][kolicestvo]
//		jform[com_fields][tsena][0][name][]
		
//		$this->paramsArticle->id;
		$query = "SELECT list_id, sort, content_id, field_id, type, cost, display, compute, quantity
		FROM #__cost WHERE `content_id` = {$contentId} AND `field_id`={$fieldId} AND `type` IN ('cost') ORDER BY list_id, sort; ";
		
//toPrint($this->form->FieldCostParams, '$this->form->FieldCostParams');
//toPrint($this->article, '$this->article');
//toPrint($this->paramsArticle, '$this->paramsArticle');
//toPrint($this->paramsField, '$this->paramsField');

		$fromBD = JFactory::getDbo()->setQuery($query)->loadObjectList();
		
//toPrint($query, 'setup()$query ');
//toPrint($this->value, 'setup()$this->value ',0);
//toPrint($fromBD, 'setup()$fromBD ',2);
//echo "<pre>". print_r($fromBD, true)."</pre>";
//echo "<pre>". print_r($this->value, true)."</pre>";
////$this->value = [];
//return $success;
//		
//		foreach ($this->value as $list_id => $list_fields){
//			$this->value[$list_id] = (object) $list_fields;
//		}

		
		foreach($fromBD as $row){
			settype($this->value[$row->list_id],'object');
//			$this->value[$row->list_id]->compute_param			= $row->compute;
			$this->value[$row->list_id]->quantity[$row->sort]	= $row->quantity;
			$this->value[$row->list_id]->cost[$row->sort]		= $row->cost;
			if(! isset($this->value[$row->list_id]->display))
				$this->value[$row->list_id]->display = [];
			if(is_object($this->value[$row->list_id]->display))
				$this->value[$row->list_id]->display = (array)$this->value[$row->list_id]->display;
			$this->value[$row->list_id]->display[$row->sort]= $row->display;
		}
//toPrint($this->value, 'setup()$this->value ',0);
		
//		$val = json_decode($value);




//[	
//	{
//		"type":"cost",
//		"id":"7",
//		"compute":"",
//		"name":["\u0422\u0430\u0431\u0443\u0440\u0435\u0442\u043a\u0430","\u0421\u0430\u0440\u0434\u0435\u043b\u044c\u043a\u0430","\u0421\u0435\u0440\u0433\u0435\u0439 \u0411\u043e\u0440\u0438\u0441\u043e\u0432\u0438\u0447 \u041a\u043e\u0440\u0435\u043d\u0435\u0432\u0441\u043a\u0438\u0439"],
//		"option":["0","1","2"],"cost":["123","100","60"],
//		"quantity":["66","69","11"],
//		"account":["1","1","1"],
//		"display":["1","1","1"]
//	}
//]

		return $success;
	}
	 
	public function getLabel() {
		return parent::getLabel();
	}
	
	/**
	 * Method to get the field input markup for a generic list.
	 * Use the multiple attribute to enable multiselect.
	 * 
	 * Способ получения разметки ввода полей для общего списка.
	 * Используйте атрибут множественный, чтобы включить множественный выбор.
	 *
	 * @return  string  The field input markup.
	 *
	 * @since   3.7.0
	 */
	public function getInput() { //Поле выводимое в редакторе материалов
		
//toPrint(555555,'$params',0,'message',true);
//toPrint(555555,'$params',0,'mesage',true);
//toPrint(555555,'$params',0,'message',true);
//toPrint(555555,'$params',0,'mesage',true);
//toPrint(555555,'$params',0,'pre',true);
//toPrint(555555,'$params',0,'pre',true);
//toPrint($this->value, 'setup($value)',0);
		
		JFactory::getApplication()->getLanguage()->load('plg_fields_cost', realpath(__DIR__.'/../')); 
		
//toPrint($this->hidden,'$params',0); 
//		$this->hidden = false;
//		$this->hidden = true;
		$html = '<h4>';
		$html .= $this->getTitle();
		$html .= '</h4>';
		
//toPrint($this->value, 'setup($value)',0);
//		$field = JFormHelper::loadFieldType('text', true);
//		$field->name = 'user';
//		$field->label = 'Юзер';
//		$html .= $field->renderField();
//		$html .= '<br>';
		
//		$params = PlgFieldsCost::$DataKostyl[$this->fieldname];
		
//		$this->paramsArticle	= $params->params;
//		$this->paramsField		= $params->fieldparams;
//		$this->paramsPlugin		= $params->paramsPlugin;
//		$this->article			= $this->form->getData();
		
		
		$data = $this->getLayoutData();
//		$data['options'] = (array) $this->getOptions();
//		return $this->getRenderer($this->layout)->render($data);
//		$this->setValue($data);
		
//toPrint($this->value, 'setup($value)',0);
//toPrint($data, 'FielCos->getLayoutData()',0);
		
//toPrint(class_exists('JFormFieldGridFields'), 'JFormFieldGridFields',0); 
//		$field = JFormHelper::loadFieldType('gridfields', true);
//		$field= new JFormFieldGridFields;
		
//toPrint($field, 'JFormHelper::loadFieldType()',0);
//		$i = $field->addColumn($field::createField('<field type="" label="Формат" format="Дорогой %s, я тебя очень люлю, \n Ты %s !!!"/>'),'xxx');
//		$i = $field->addColumn($field::createField("<field type=\"\" label=\"\"/>"),'name');
//		$i = $field->addColumn($field::createField('<field type="" label=""/>'),'options'); 
//		$i = $field->addColumn($field::createField('<field type="" label=""/>'),'unit');
//		$i = $field->addColumn($field::createField('<field type="" label=""/>'),'compute');
//		$field->addRow(['name'=>'Сергей','options'=>'Хороший','unit'=>'123','compute'=>'Лучший']);
//		$html .= $field->getControl();
//		return;
//		$field->columns[$i]->x = 444;
//toPrint($i, '$i',0);
//$fieldx = $field::createField('<field type="" label=""/>','name');
//toPrint($fieldx, '$field',0);
//toPrint($field->columns, '$field->columns',0);
//$field::createField($type, $value, $data);
		
		JPluginHelper::importPlugin('fields', 'cost');
		
//		$plg = JPluginHelper::getPlugin('fields','cost');
//		$plg = JFactory::getApplication()->bootPlugin('cost','fields');
		
//toPrint($this->value, 'setup($value)',0);
		
//toPrint(get_class($plg), '$plg',0,'message');
//		$plg = JPluginHelper::getPlugin('fields', 'cost');
		
		// Валюта по умолчанию из Плагина // ->name_unit, ->short_unit, ->type_unit, ->enable_unit
		$currency = PlgFieldsCost::$currency;
//		$plugin = JFactory::getApplication()->triggerEvent('onFieldCostGetPlugin');
//		if($plugin)
//			$currency = $plugin[0]::$currency;

//toPrint($this->value, 'setup($value)',0);
		
		
//		$currencies = JFactory::getApplication()->triggerEvent('onFieldCostGetCurrencies', []);
//		$currencies = $plg->onFieldCostGetCurrencies();//PlgFieldsCost::$currencies;
		
//		$list_currencies = $this->paramsPlugin['list_currencies'];
//		$currency = new class{}; //$list_currencies->{};//[name_cur, short_cur, code_cur, ratio_cur, display_cur]
//		foreach(get_object_vars($list_currencies) as $prop_name => $property_cur ){
////toPrint($property_cur, '$property_cur',0);
//			$currency->{$prop_name} =  $list_currencies->{$prop_name}[$list_currencies->default_cur] ?? null;
//		}
		
//toPrint($currencies, '$currencies',0,'message');
//toPrint($currency, '$currency',0,'message'); 
		 
//toPrint($list_currencies, '$list_currencies',0);
//toPrint($currencies, '$currency',0);
//toPrint($list_currencies->default_cur, '$list_currencies->default_cur',0);
		
		
		// Еденицы учета из Плагина // ->name_unit, ->short_unit, ->type_unit, ->enable_unit
//		$units_list = $plg->onFieldCostGetUnits();//PlgFieldsCost::$units;
//		$list_units = $this->paramsPlugin['list_units'];
//		foreach ($list_units->name_unit as $i => $name){
//			$units_list[$i]['name_unit']	= $list_units->name_unit[$i]  ?? '';	//Имя длинное
//			$units_list[$i]['short_unit']	= $list_units->short_unit[$i] ?? '';	//Имя короткое
//			$units_list[$i]['type_unit']	= $list_units->type_unit[$i]  ?? '';	//Тип измерения
//			$units_list[$i]['enable_unit']	= $list_units->enable_unit[$i]?? '';	//Включён
//		}
		
		
//toPrint($this->name, 'name',0);
//toPrint($this->paramsArticle, 'paramsArticle',0);
//toPrint($this->paramsField, 'paramsField',0);
//toPrint($this->paramsField['list_fields'], '$list_fields',0);

		/**
		 * Переменная для исправления проблема определения индексов браузера при отсылке формы с численными индексами в именах полей.
		 */
		static $index_fix; 
		
		if(is_null($index_fix)){
			$fix_index = [];
		}
		if(empty($index_fix[$this->fieldname])){
			$fix_index[$this->fieldname] = 0;
		}

//toPrint($this->value, 'setup($value)',0);
		
		// Типы опций из Поля
		/** 
		 * Список параметров настроек поля - объект с массивами
		 * @var object  Список параметров настроек поля - объект с массивами  
		 */ 
//		$list_fields = $this->fieldparams['list_fields'];
		$list_fields = $this->form->FieldCostParams->fieldparams->get('list_fields',[]);
		$fieldId = $this->form->FieldCostParams->id;
		
//toPrint($this->value, 'setup($value)');
//		unset($this->form->FieldCostParams);
		
//toPrint($list_fields, '$list_fields',0);
		
//		$formArticle = $this->form->getData();
		
//		if(empty($list_fields)){
//			$list_fields = PlgFieldsCost::$units;
//		}
//toPrint($list_fields, '$list_fields',0,'pre',true);
//echo "<pre>".print_r($list_fields,true)."</pre>";
//return '';
//toPrint($this->value, ' $this->value:',0,'message',true); // 0 Макет
//return "";
		if(false == is_array($this->value))
			$this->value = [];
		
		foreach ($list_fields->index_param as $i => $index_param){ 
			//$index_param - индекс таблицы параметров в материале
			//$title - Название таблицы параметров
			$title = $list_fields->name_param[$i];
//toPrint($title, '$title',0);
//toPrint($i, '$i',0);
//toPrint($name, ' $name:'. $i); // 0 Упаковка
			
			$fieldRender = '';

			
//			if(is_null($index_fix)){
//				$fix_index = [];
//			}
//toPrint($fix_index, '$fix_index:'.$this->fieldname,0,'message');
			$field = JFormHelper::loadFieldType('hidden', true);
			$field->setup(simplexml_load_string('<field />'),$index_param); //$index_param // $this->name."[{$fix_index[$this->fieldname]}]ndex_fix]"
			$field->name = $this->name."[i{$fix_index[$this->fieldname]}][index_fix]";
			$fieldRender .= $field->getInput();
			$fix_index[$this->fieldname]++;
//			$value = null;
//toPrint($list_fields->name_param[$i], '$list_fields->name_param[$i]',0);
				
//toPrint(str_replace($field->fieldname, 'cost', $this->name), ' fieldname:'.$field->fieldname.' name:'.$this->name);
//			if(isset($this->value[$i]))
			$value = isset($this->value[ $index_param ]) ? (object)$this->value[ $index_param ] : null;
			
//toPrint($value, '$value',0,'message');
//return;
			if(isset($value) && (isset($value->compute_param) == false || empty($value->compute_param)))
				$value->compute_param = '+';
			
//toPrint($value, ' $value:'. $i);
//toPrint($value, ' $value:',0,'pre',true); // 0 Макет
//return "";
			
			// Field: Hidden : namefield. --< DONE
			$field = JFormHelper::loadFieldType('hidden', true);
			$field->setup(simplexml_load_string('<field />'),'cost');
//			$field->name = str_replace($this->fieldname, 'cost', $this->name).'[]';//jform[com_fields][cost][]		//jform[com_fields][tsena][cost][]
			$field->name = $this->name."[i$index_param][type]";
			$fieldRender .= $field->getInput();										   //jform[com_fields][cost][]		//jform[com_fields][tsena][]
			//																		 jform[com_fields][cost][]

			// Field: Hidden : fieldId. --< DONE
			$field = JFormHelper::loadFieldType('hidden', true);
			$field->setup(simplexml_load_string('<field />'),$fieldId);
//			$field->name = str_replace($this->fieldname, 'cost', $this->name).'[]';//jform[com_fields][cost][]		//jform[com_fields][tsena][cost][]
			$field->name = $this->name."[i$index_param][id]";
			$fieldRender .= $field->getInput();	
			
			
			
//toPrint($value, ' $value:'. $i);
//toPrint($list_fields->compute_param, ' $list_fields->compute_param: '. $i, 0);
			
			// Поле [Вычисление при покупке в клиента] настраивается в редакторе Продукта
			// Параметр [Вычисление] из поля 
			$compute_param = $list_fields->compute_param[$i] ?? ''; //'equal','plus','minus','times','divide' '','=','+','-','*','/',
			$readonly = $compute_param ? ' readonly="true" disabled="true"' : '';
			$field = JFormHelper::loadFieldType('list', true);
			$field->setup(simplexml_load_string("<field $readonly/>"),$compute_param);
			$field->hidden = true;
//			$field->default = $value->compute_param;
//			if( $value->compute_param)
			$field->value = $compute_param;
//toPrint($compute_param == 0 && isset($value->compute_param) && $value->compute_param, " $compute_param ". $i);
			if(($compute_param === 0 || $compute_param === "0") && isset($value->compute_param) && $value->compute_param){
//				$field->value = $value->compute_param; 
				$field->setValue($value->compute_param);
			}else{
				$field->setValue($compute_param);
			}
			$field->id = $this->id.'_options_compute_param_'.$index_param;
			$field->name = $this->name."[i$index_param][compute_param]";//'jform[com_fields][product_options_compute]';  //
			$field->class = 'form-select valid form-control-success form-select form-control-sm form-select-sm w-auto d-inline-block ';
			$field->class .= $readonly ? ' readonly disabled' : '';
			foreach (static::$compute_param as $operator=>$operation)//'','equal','plus','minus','times','divide',
				$field->addOption(JText::_($operation), ['value'=>$operator]);//static::JText ($operation)
			$fieldRender .= JText::sprintf('PLG_COST_PARAM_COMPUTE_F',$currency->short_cur).$field->getInput(); //renderField(); 
			
//toPrint($compute, ' $compute'); //
//toPrint($field->name, ' $field->name:'); //  
			
			
//			$type = in_array($type, ['radio','checkbox','number',]) ? $type : '';
			
			// Поле [Выбора количества при покупке в клиента] настраивается в редакторе Продукта
			$field = JFormHelper::loadFieldType('list', true);
			$select_param = $list_fields->select_param[$i] ?? ''; //'0','one','multi','quantity' 
			$is_q = str_ends_with($select_param, '?') && $select_param = substr($select_param, 0, -1); 
			str_ends_with($select_param, '!') && $select_param = substr($select_param, 0, -1);
			$readonly = $select_param && ! $is_q ? ' readonly="true" disabled="true"' : '';
			$field->setup(simplexml_load_string("<field $readonly/>"),$select_param);
			$field->hidden = true;
			if(isset($value->select_param) && $value->select_param)
				$field->value = $value->select_param;
			if($is_q)
				$field->default = $select_param;
			else
				$field->value = $select_param;
			$field->id = $this->id.'_options_select_param_'.$index_param;
			$field->name = $this->name."[i$index_param][select_param]";//'jform[com_fields][product_options_compute]';  //
			$field->class = 'form-select valid form-control-success form-select form-control-sm form-select-sm w-auto d-inline-block ';
			$field->class .= $readonly ? ' readonly disabled' : '';
			foreach (static::$select_param as $operator=>$operation)//'','equal','plus','minus','times','divide',
				$field->addOption(JText::_($operation), ['value'=>$operator]);//static::JText ($operation)
			$fieldRender .= JText::_('PLG_COST_PARAM_SELECT').$field->getInput(); //renderField();
			
			
			
			// Параметр [Макет] из поля 
			$layout_param = $list_fields->layout_param[$i] ?? -1; // Выбранный макет файла из папки поля //-1
//toPrint($layout_param, ' $layout_param'); //
//toPrint($layout_param, ' $layout_param'); //
			
			 // Поле [Макет] в редакторе Продукта
			$readonly = $layout_param != -1 ? ' readonly="true" disabled="true"' : '';//-1
			$field = JFormHelper::loadFieldType('filelist', true);
			$field->setup(simplexml_load_string("<field $readonly/>"),$layout_param);
			$field->hidden = true;
			$field->id = $this->id.'_options_layout_param_'.$index_param;
			$field->name = $this->name."[i$index_param][layout_param]";//'jform[com_fields][product_options_compute]';  //
			$field->class = 'form-select valid form-control-success form-select form-control-sm form-select-sm w-auto d-inline-block ';
			$field->class .= $readonly ? ' readonly disabled' : '';
			$field->directory = JPATH_PLUGINS . "/fields/cost/tmpl/group";
			$field->default='';
			$field->value = str_replace('.php', '', $layout_param);
			if(isset($value->layout_param) && $layout_param == -1)
				$field->value=$value->layout_param;
			$field->stripExt=true;
			$field->hideNone=true;
			$field->hideDefault=false;
			$field->fileFilter="^(?!(layout_*)|(cost.php)|(default.php)).*.php$"; 
			$fieldRender .= JText::_('PLG_COST_PARAM_LAYOUT').$field->getInput(); //renderField(); 
//toPrint($field->name, ' $field->name:'); //
			
//toPrint($layout_param, ' $layout_param:',0,'message'); // 0 Макет
			 
			
//		return $fieldRender.'666666666';//$field->getInput();//$html;
			
//toPrint($value, ' $value:',0,'pre',true); // 0 Макет
//return "";
			$fieldTable = JFormHelper::loadFieldType('GridFields', true);
//			$fieldTable= new JFormFieldGridFields;

			if(empty($fieldTable)){
				JFactory::getApplication()->enqueueMessage(JText::_('PLG_ERROR_GRIDFIELDS_EMPTY'),'error');
				return '';
			}
				
			
//toPrint($fieldTable, ' $value:',0,'message',true); // 0 Макет
//return "";  
//			$value = isset($this->value[$i]) ? get_object_vars($this->value[$i]) : [];
			if($value)
				$fieldTable->setValue($value);
			//jform[com_fields][kolicestvo]
			//jform[com_fields][tsena][product_options][name][]
			$fieldTable->name = $this->name."[i$index_param]"; //product_options jform[com_fields][tsena][product_options][name][] jform[com_fields][kolicestvo]
			$fieldTable->label = $list_fields->name_param[$i];
			$prefIndex = false ? "$index_param: " : "";
			$fieldTable->caption = "<div class='d-flex justify-content-between'><div>$prefIndex$title&nbsp;</div><div class=''>$fieldRender</div></div>";
			
//toPrint($value, ' $value:',0,'pre',true); // 0 Макет
//return "";
			
//toPrint($value, ' $value:',0,'pre',true); // 0 Макет
//			$fieldTable->addColumn($fieldTable::createField("<field type=\"hidden\" value=\"0\" />"),
//					'id');
//			$fieldTable->addColumn($fieldTable::createField("<field type=\"hidden\"  />"),'index'); //default=\"\" value=\"\"
			
			$typeColumn = $title ? 'text' : 'hidden';
			$fieldTable->addColumn($fieldTable::createField('<field label="PLG_COST_PARAM_TITLE" type="'.$typeColumn.'"/>'),'title');
			
			
			$options = explode('|', $list_fields->option_param[$i]);
			$typeField = $options == [''] ? 'text' : 'list';
			$opts = '<field name="options" type="'.$typeField.'" label="PLG_COST_PARAM_OPTIONS" required="false" >'; 
			foreach ($options as $i_opt => $option)
				$opts .= "<option value=\"$i_opt\">$option</option>";
			$opts .= '</field>';
			$fieldTable->addColumn($fieldTable::createField($opts),'option');
//toPrint($options, '$options ',0);
//$Element = simplexml_load_string($opts);
//toPrint($Element->children(), '231 ',0);
//toPrint($opts, '$opts',0,'pre');
//toPrint($options, '$options',0);
//class="form-select form-select-sm w-5"			
//			$fieldTable->addColumn($fieldTable::createField('$options'),'optios'); //------- 
//			$fieldTable->addColumn($fieldTable::createField(array()),'optiodns'); //-------
//			JLayoutFile::addIncludePath(  "plugins/fields/cost/layout");
//				addfieldpath="plugins/fields/cost/field"
//		$layoutFile = __DIR__.DS.'layouts';
//		JLayoutHelper::render('cost.php','',$layoutFile);
//		JPluginHelper::getLayoutPath('fields', 'cost', 'default');
//			$fieldTable->addColumn($fieldTable::createField("<field label=\"Класс\"/>"),'unit');
//			$fieldTable->addColumn($fieldTable::createField("<field label=\"Файл\"/>"),'unit');
//			$fieldTable->addColumn($fieldTable::createField("<field label=\"Картинка\"/>"),'unit');
//			continue;
			
//			JLayoutHelper::render($opts);
//			JForm::addFieldPath($path);
			JFormHelper::addFieldPath(JPATH_PLUGINS . "/fields/cost/field");
			
			
			$fieldTable->addColumn(
					$fieldTable::createField('<field label="'.JText::sprintf('PLG_COST_PARAM_PRICE',$currency->short_cur).'" description="PLG_COST_PARAM_PRICE_DESC"  classCell="" parentclass=""
					type="number" inputtype="number" default="0" value="0" required="false"  />'),
					'cost');
//			$fieldTable->label = JText::sprintf('PLG_COST_PARAM_PRICE',$currency->short_cur);
			$fieldTable->css .= '.gridFields .name_cost{max-width: 100px;}';//
			

			$accounting = $list_fields->account_param[$i] ?? 1; //    on off allways never 1, 0, 1!, 0!
//Количество
			//Учет продуктов
			if(in_array($accounting,['on','allways',1,'1','1!','',]))
				$fieldTable->addColumn($fieldTable::createField('<field label="PLG_COST_PARAM_QUANTITY"  description="PLG_COST_PARAM_QUANTITY_DESC"  
					type="number" default="0" value="0" required="false" parentclass="w-10"/>'),
					'quantity');
			else
				$fieldTable->addColumn($fieldTable::createField('<field type="hidden" value="0" />'),
					'quantity');
			$fieldTable->css .= '.gridFields .name_quantity{max-width: 100px;}';//
			
			$checked = in_array($accounting,['on','allways',1,'1','1!','',])? 1 : 0;
			
			if(in_array($accounting,['on','off',1,0,'1','0','',])){ 
				$fieldTable->addColumn($fieldTable::createField("<field label=\"PLG_COST_PARAM_ACCOUNT\" type=\"checkbox\"  checked=\"$checked\" required=\"false\"	parentclass=\"w10 check    btn-mini   input_small  \"  classCell=\"w-10\" />"),
					'account');
			}
			else
				$fieldTable->addColumn($fieldTable::createField('<field type="hidden" value="1"/>'),
					'account');
				
			$fieldTable->addColumn($fieldTable::createField('<field label="PLG_COST_PARAM_DISPLAY" type="checkbox"  checked="checked" required="false" parentclass="w10 check    btn-mini   input_small  "  classCell="w-10" />'),
					'display'); 
	
						
			
//toPrint($list_fields,'$list_fields',0,'pre');
//echo "<pre>". print_r($list_fields,true)."</pre>";
//echo "<pre>". print_r($value,true)."</pre>";
//			$type = $list_fields->select_param[$i];
			
			$is_q = str_ends_with($list_fields->select_param[$i], '?');
			$type = $is_q ? ($value->select_param ?? substr($list_fields->select_param[$i], 0, -1)) : $list_fields->select_param[$i];
//			$type = $is_q ? ($value->select_param ?? substr($list_fields->select, 0, -1)) : $list_fields->select_param[$i];	
			$type = in_array($type, ['radio','checkbox','number',]) ? $type : 'hidden';
//toPrint($type,'$type:'.$i );
//toPrint($list_fields->select_param[$i],'$list_fields->select_param[$i]:'.$i.'-'.$title);
//toPrint($is_q,'$is_q:'.$i );
//			if($type){
//toPrint("<br>".htmlspecialchars($s),'$s:' ,0,'pre');
			$fld = $fieldTable::createField("<field type=\"$type\"  label=\"PLG_COST_PARAM_DEFAULT\" description=\"PLG_COST_PARAM_DEFAULT_DESC\" 
					 default=\"0\" value=\"0\" required=\"false\" parentclass=\"w10 check    btn-mini   input_small  \"  classCell=\"w-10\"/>");
//			$fld->label = JText::_('PLG_COST_SELECT');//label=\""."\" $type.' '.
//			if($is_q)
//			$fld->default = 0; 
//toPrint($fld,'$fld:' );
//toPrint($fld->id,'$fld->id:'.$i );
			$fieldTable->addColumn($fld,
					'select');
//			}else{
//				
//			}
//toPrint($fieldTable->value);
//return $html; 
//toPrint($fieldTable->columns['select'],' value:');
//toPrint($list_fields->select_param[$i],'select_param type:'.$type);
			
//					<option value="0">JOPTION_DO_NOT_USE</option>
//					<option value="_">JHIDE</option>
//					<option value="one">PLG_COST_PARAM_ONE</option>
//					<option value="multi">PLG_COST_PARAM_MULTI</option>
//					<option value="quantity">PLG_COST_PARAM_QUANTITY</option>
					// ,null,['layout'=>"checkbox"]  //layout=\"checkbox\" layout=\"checkbox\" renderLayout
//	  $layout = 'joomla.form.field.text';
//			continue;
//			$fieldTable->addRow(new class { public $options='1шт'; });
//			foreach ($options as $option){
////				$fieldTable->addRow(['options'=>$option]);
//				$row = new class { public $options=''; };
//				$row->options = $option;
//				$fieldTable->addRow($row);
//			}
//toPrint($fieldTable->columns, '$fieldTable->value',0);
//toPrint($fieldTable->value, '$fieldTable->value',0);
		
			$html .=  $fieldTable->getControl();
				
//			$html .= "<br><br> $name ";
//			$html .= "<br> {$list_fields->name_param[$i]} ";			// Имя
//			$html .= "<br> {$list_fields->option_param[$i]} ";			// Опции
//			$html .= "<br> {$list_fields->unit_param[$i]} ";			// Еденица учета
//			$html .= "<br> {$list_fields->compute_param[$i] } ";			// Вычисление
//			$html .= "<br>$i   printR". gettype($list_fields->account_param[$i]) .print_r($list_fields->account_param[$i],true);		// Учёт
			
//toPrint($list_fields->name_param, 'FielCos->name_param',0);
//toPrint($list_fields->option_param[$i], 'FielCos->option_param',0);
//toPrint($list_fields->unit_param, 'FielCos->unit_param',0);
//toPrint($list_fields->compute_param, 'FielCos->compute_param',0);
//toPrint($list_fields->account_param, 'FielCos->account_param',0);
		}
//		$html .= '<hr>'; //	protected $layout = 'joomla.form.field.checkbox';
//		JLayoutHelper::$defaultBasePath = JPATH_PLUGINS . '/fields/cost/layouts/';
//		$html .= JLayoutHelper::render('checkbox', [], JPATH_PLUGINS . '/fields/cost/layouts/');//, $basePath,$options
//		$html .= JLayoutHelper::render('joomla.form.field.checkbox', null, JPATH_PLUGINS . '/fields/cost/layouts/');//, $basePath,$options
		
		return $html;
		
//		[
//						'checked' => true,
//						'basePath'=>"plugins/fields/cost/field/layouts/checkbox.php",
//						'addfieldpath'=>"plugins/fields/cost/field/layouts/checkbox.php",
//						'layout'=>"plugins/fields/cost/field/layouts/checkbox.php",
//						'layoutFile'=>"plugins/fields/cost/field/layouts/checkbox.php",
//						'layoutPath'=>"plugins/fields/cost/layouts/",
//						'renderLayout'=>"plugins/fields/cost/field/layouts/checkbox.php",
//						]
		
		
		$html .= "";
//		$html .= JHtml::_('select.groupedlist', $groups, $this->name,
//				array('id' => $this->id, 'group.id' => 'id', 'list.attr' => $attr, 'list.select' => $selected)
//			);
		
		
//toPrint(array_keys((array)$this),'$this.keys '. get_class($this));
//toPrint(($this->params),'$this->params',0); 
//toPrint(($this->id),'$this->id',0);
//toPrint(($this ),'$this ',0);
		 
		
		return "<h1>Привет любимый</h1>";
		return parent::getInput();
	}
	
	/**
	 * Render a layout of this field
	 *
	 * @param   string  $layoutId  Layout identifier
	 * @param   array   $data      Optional data for the layout
	 *
	 * @return  string
	 *
	 * @since   3.5
	 */
	public function render($layoutId, $data = array()){
		
toPrint($data,'render($data)',0);
		return parent::render($layoutId, $data);
	}
	
	/**
	 * Method to get a control group with label and input.
	 *
	 * @param   array  $options  Options to be passed into the rendering of the field
	 *
	 * @return  string  A string containing the html for the control group
	 *
	 * @since   3.2
	 */
	public function renderField($options = array()){ //Выполняется в Article
		
//toPrint($options,'renderField($options )',0);
		return parent::renderField($options);
	}
	
	public function setPlgField($pluginField) {
		
toPrint( '000000000000000000000000000000000000000000000000000');
toPrint(array_keys((array)$pluginField),'$this.keys');
toPrint(($pluginField->params),'$this->params',0);
	}
	
	/**
	 * Параметры режима выбора опций на клиенте
	 * Настройка делается в редакторе материала
	 * Отображение галок и выбора количеста на клиенте
	 * @var array  
	 */
	public static $select_param = [
				'_'			=> 'JHIDE',
				'radio'		=> 'PLG_COST_PARAM_ONE',
				'checkbox'	=> 'PLG_COST_PARAM_MULTI', 
				'number'	=> 'PLG_COST_PARAM_QUANTITY',
			];
	/**
	 * Операторы вычисления итоговой суммы.
	 * Настройка делается в редакторе материала
	 * Отображение цен в клиенте
	 * @var array ['+' = 'PLG_COST_PARAM_PLUS',...]
	 */
	public static $compute_param = [
				'0' => 'JOPTION_DO_NOT_USE',
				'_' => 'JHIDE',
				'☺' => 'JSHOW',
//				'=' => 'PLG_COST_PARAM_EQUAL',
				'+' => 'PLG_COST_PARAM_PLUS',
				'-' => 'PLG_COST_PARAM_MINUS',
				'*' => 'PLG_COST_PARAM_TIMES',
				'/' => 'PLG_COST_PARAM_DIVIDE',
			];
	
	public static function JText($text = ''){
		$text = static::$operations[$text] ?? $text;
		return JText::_($text);
	}
}


//echo '<br>Вывод  из папки FIELDS Opera_82.0.4227.43_Setup_x64.exe 111111111111111';
//
//return 'ВЫВОД поля из папки FIELDS Opera_82.0.4227.43_Setup_x64.exe';

if(empty($item->params))
    return;

if(empty($field->value) )
    return;

return;










// <editor-fold defaultstate="collapsed" desc="comment">

//toPrint($this, 'modules.php');
//toPrint(array_keys((array)$this),'$this.keys');
//toPrint(($this->params),'$this->params',0);
$context; // тип блога, тип статьи. Пример: com_content.article
$item; // объект Статьи в блоге
$field; // объект добавляемого поля к статье в блоге
$field_modules_type = $fieldParams->get('method', 'pos');
$field_multiple = $fieldParams->get('multiple', TRUE);
$field_value = $fieldParams->get('query', 0);
$tasks = $fieldParams->get('task', []);

$display = $field->params->get('display'); // Место где должен отображатся поле. ПослеЗаголовка, ПослеТекса, ПередТекстом.
$context = $field->context; //com_content.article 

$show_text = $item->params->get('show_text'); // Место как должно отображатся текст описания
//,hide,or,intro,full,all
$show_intro = $item->params->get('show_intro'); // Место как должно отображатся текст описания
//,use_article,0,1

$ignore = array('GLOBALS', '_FILES', '_COOKIE', '_POST', '_GET', '_SERVER', '_ENV', 'ignore');
$vars = array_diff_key(get_defined_vars() + array_flip($ignore), array_flip($ignore));
//toPrint(array_keys($vars),'$this'); 
//toPrint($this->path,'$path'); 
//toPrint(array_keys(get_object_vars($this->_subject)),'$this->_subject'); 

//$values = explode(',', $field_value);

//toPrint($field_value,'$field_value'); 
//toPrint($context,'$context'); //com_content.article 
//toPrint($field,'$field'); 






//else {    
//$query = "
//SELECT  CONCAT(id ,': ',title,' :/',module,'/',position,'') title,
//     id  /*id, title, position, module, client_id ,*/
//FROM #__modules 
//WHERE id IN ($where) ; " ;
//}

$mod_type = $field_modules_type;

//if(count($value)==1 && empty($value[0]))
//    return '';

//toPrint($value,'$value',0);  
//toPrint($fieldParams,'$fieldParams'); 
//toPrint($context,'$context'); 
//toPrint(array_keys((array)$item),'$item'.$item->title); 
//toPrint($field,'$field'); 
 //toPrint($fieldParams,'$fieldParams'); 


$view = JFactory::getApplication()->input->getCmd('view');

//toPrint($view,'$view',0);
//toPrint($tasks,'$tasks',0);
//toPrint(!in_array('', $tasks) && !in_array($view, $tasks),'inArray \'\'',0);
//toPrint(!in_array($view, $tasks),'inArray '.$view,0);

				
//toPrint("Enable!");
//echo "Enable";



$ids = [];

$condition = '';
$db = JFactory::getDbo();


foreach ((array) $field->value as $v) {
	if (empty($v))     {
		continue;
	}

	$ids[] = $db->q($v);
}
$where = implode(',', $ids);


$query = $fieldParams->get('query', '');



//toPrint($field->value,'$field->value',0);
//toPrint($ids,'$ids1');
//toPrint($value,'$value');
//toPrint($value,'$value');
//return '123';



$tag = JFactory::getLanguage()->getTag();

if ($field_modules_type == 'pos') {

	$query = "
SELECT id, title, position, module, client_id, published, showtitle, params, ordering, language, content  
     /*CONCAT(id ,': ',title,' :/',module,'/',position,'') title, id  */
FROM #__modules 
WHERE position IN ($where) AND position != '' AND published = 1  AND language IN ('$tag','*')
ORDER BY position, ordering, id ; ";

} 
elseif ($field_modules_type == 'ids') {

	$query = "
SELECT id, title, position, module, client_id, published, showtitle, params, ordering,  language, content 
     /*CONCAT(id ,': ',title,' :/',module,'/',position,'') title, id  */
FROM #__modules 
WHERE id IN ($where)  AND published = 1  AND language IN ('$tag','*')
ORDER BY position, ordering, id ; ";

}

//toPrint($field_modules_type,'$field_modules_type',0,true, true);
//toPrint($where,'$where',0,true, true);
//toPrint($query,'$query',0,true, true);
//return;

// Run the query with a having condition because it supports aliases
$db->setQuery($query);
$items = $db->loadObjectlist('id'); // id, title, position, module, client_id, published, showtitle, params.
//    $items = $db->loadAssocList('id', 'id'); 


//$ix = [];
//foreach ($items as $i => $item){
//    $ix[$i] = [$item->ordering,$item->title,$item->module];
//}
//159, 162, 166, 174, 158, 157        166, 158, 157, 159, 162,           174
//  5    1    6   11    9   10          2    6    7    8   11   
//$ids = array_keys($items) ;
//toPrint($ids,'$ids2');
//foreach ($items as &$item)
//    $item->params = '';
//toPrint($items,'$items',0); 
//toPrint($ix,'$items',0); 
//toPrint($items[155],'$items',0);  
//toPrint($items,'$items',0,true, true);
//return;


$texts = array();


$modules = [];

//if(!toPrint()){
//    return;
//}

//$menuitem = JFactory::getApplication()->getMenu()->getActive();
//$doc = JFactory::getDocument();
$view = JFactory::getApplication()->input->getCmd('view');
//$router2 = JFactory::getApplication()->getRouter()->getVars();
 
// $item->params->get('category_layout');   [category_layout] => _:blog   [show_text]
// introtext   fulltext   text   jcfields
// 
//  task
//toPrint($field,'$field');
//toPrint($router1,'$router1',0);
//toPrint($router2,'$router2',0);
//toPrint($menuitem,'$menuitem');
//toPrint($doc,'$doc');
//toPrint($fieldParams,'$fieldParams');
//toPrint(array_keys((array)$field) ,'$field');
//toPrint(array_keys((array)$item) ,'$item',0);
//toPrint($item,'$item');
//toPrint(array_keys((array)$this) ,'$this');
//toPrint(array_keys((array)$this) ,'$this');
//toPrint(array_keys((array)$this) ,'$this');
//toPrint($this->type ,'$thisType');
//toPrint(JFactory::getApplication() ,'JFactory::getApplication()');
//toPrint($this ,'$this');

//return;

foreach ($items as $mod_id => $module) {
//    toPrint($mod_id,'$mod_id');
//    toPrint($module,'$module '.$mod_id);
//    if (in_array($mod_id, (array)$field->value))
//    { 
	//$multi_items[$key]->module = $module->module;
	//
	//if(!isset($module->module))            {echo "<pre>$multi_module_id: ".print_r($module,true). "</pre>";continue;}


	$file = JPATH_SITE . "/modules/$module->module/$module->module.php";

	//    echo $file."<br>";//149,142,146
	//echo "<pre> ** ".print_r($multi_items,true)."++</pre>"; 
	//$b = $params->get('base');
                 
//toPrint($module,'$mod_id');    continue;
	if (file_exists($file)) {


//toPrint($file,'$file: '.$mod_id);
		//$multi_items[$key]->params = unserialize  ($module->params);
//                $module->params = json_decode ($module->params);
		//echo "<pre> **".print_r( $module,true). "++</pre>"; 
		//var_dump($module->params);
		//echo "<br>".$file."<br>". $module->params."<br> ";
		$module->params = $params = new Joomla\Registry\Registry($module->params);
		//$params->setProperties($module->params);
		
                //$module->params = $params;
		$module->parentId = 0;
//				$module->style = $module->params->get('style','');
//				$module->moduleclass_sfx = $module->params->get('moduleclass_sfx','');
//				$module->module_tag = $module->params->get('module_tag','');
//				$module->header_tag = $module->params->get('header_tag','');
//				$module->header_class = $module->params->get('header_class',''); 
				
//                $items[$mod_id]->params= $module->params;
//                $items[$mod_id]->parentId= $module->parentId;
//                $items[$mod_id]->style= $module->style;
//                $items[$mod_id]->moduleclass_sfx= $module->moduleclass_sfx;
//                $items[$mod_id]->module_tag= $module->module_tag;
//                $items[$mod_id]->header_tag= $module->header_tag; 
//                $items[$mod_id]->header_class= $module->header_class;
		
				//if ($multi_module_id == 144 || $multi_module_id == 145)echo "<pre> **".print_r( $module,true). "++</pre>"; 


		JFactory::getLanguage()->load($module->module);


		
                $content = '';

		ob_start();

		require $file;
		$content = ob_get_clean() . $content;


		if (empty($module->published) || empty($content)) {
			unset($items[$mod_id]);
			continue;
			;
		}


//toPrint($module,'$module');
//                ob_start();
		//echo $file."<br>" ;//149,142,146
		$module_tag = (empty($module->style)) ? "div" : $module->module_tag;


		echo "<$module_tag class=\" field_module $module->module $module->moduleclass_sfx id_$module->id \">";


		if ($module->showtitle) {
			echo "<$module->header_tag class=\"$module->header_class\" >$module->title</$module->header_tag>";
		}




		echo $content;


		
                echo "</$module_tag>";
//toPrint($module,'$mod_id');    continue;
//                $items[$multi_module_id]->content = ob_get_clean();
		//$multi_items[$multi_module_id]->id = $multi_module_id; 
	}
	
//    }
}





//echo htmlentities(implode(', ', $modules));
//echo "LaLa !!!";// </editor-fold>
