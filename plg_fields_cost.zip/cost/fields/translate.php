<?php defined('_JEXEC') or die; 
/**------------------------------------------------------------------------
 * field_cost - Fields for accounting and calculating the cost of goods
 * ------------------------------------------------------------------------
 * author    Sergei Borisovich Korenevskiy
 * Copyright (C) 2010 www./explorer-office.ru. All Rights Reserved.
 * @package  mod_multi_form
 * @license  GPL   GNU General Public License version 2 or later;  
 * Websites: //explorer-office.ru/download/joomla/category/view/1
 * Technical Support:  Forum - //fb.com/groups/multimodule
 * Technical Support:  Forum - //vk.com/multimodule
 */  
 

use Joomla\CMS\Plugin\PluginHelper as JPluginHelper;
use Joomla\Registry\Registry as JRegistry;
use Joomla\CMS\Form\Field\ListField as JFormFieldList;
use \Joomla\CMS\Form\FormField as JFormField;
use Joomla\CMS\Language\Text as JText;
use Joomla\CMS\HTML\HTMLHelper as JHtml; 
use Joomla\CMS\Factory as JFactory;
//use Joomla\CMS\Document\Document as JDocument;
//use Joomla\CMS\Form\FormHelper as JFormHelper;
use Joomla\CMS\Helper\ModuleHelper as JModuleHelper;
use Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use Joomla\CMS\Layout\FileLayout as JLayoutFile;
use \Joomla\CMS\Version as JVersion;
use Joomla\CMS\Form\Form as JForm;
use Joomla\CMS\Language\Language as JLanguage;
//use Joomla\CMS\Layout\BaseLayout as JLayoutBase;
 

 

class TranslateField extends JFormField  {//JFormField  //JFormFieldList   \Joomla\CMS\Form\FormField  Joomla\CMS\Form\Field; JFormFieldTranslate TranslateField
	
	public function __construct($param) {
		$this->path = dirname(__DIR__);
		$this->file = '';
	}
	
	public function setup(\SimpleXMLElement $element, $value, $group = null) {
		
		$this->path = $element['path'] ?? __DIR__;
		
		if($element['path'])
			$this->path = dirname($element['path']);
		
		if($element['file'])
			$this->file = dirname($element['file']);
		
		
		
		$lang = JFactory::getApplication()->getLanguage();

		$lang->load($file, $this->path);
		$lang->load($file, JPATH_SITE);
		$lang->load($file, JPATH_ADMINISTRATOR);

//		$lang->load($file, JPATH_ADMINISTRATOR);
//		$lang->load($this->option, JPATH_SITE);//JPATH_ADMINISTRATOR
		
//		$lng = new JLanguage;
//		$lng->load($file, $this->path);
//		
//		\Joomla\CMS\Language\LanguageHelper::parseLanguageFiles($path);
		
//echo "<pre>".print_r($lang,true)."</pre>";
//		parent::setup($element, $value, $group);
		return true;
	}
	
	public $path = '';
	
	public $file = '';
	
	private $options = null;
	
	public function getInput() {
		return (string)$this->path.'123';
	}
	public function getLabel() {
		return (string)$this->file;
	}
//	public function getTitle() {  
//		return '';
//	}
//	public function getId($fieldId, $fieldName) { 
//		return '';
//	}
}