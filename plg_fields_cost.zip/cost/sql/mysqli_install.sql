/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/SQLTemplate.sql to edit this template
 */
/**
 * Author:  koren
 * Created: 7 апр. 2022 г.
 */

CREATE TABLE IF NOT EXISTS `#__cost` (
  `list_id` int(11) NOT NULL COMMENT 'index table',
  `content_id` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `quantity` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `cost` float NOT NULL DEFAULT 0,
  `display` tinyint(1) NOT NULL DEFAULT 1,
  `compute` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '=',
  `sort` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Сортировка как в таблице'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;