<?php

/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   (C) 2016 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;

use Joomla\CMS\Factory as JFactory;
use Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use Joomla\CMS\Layout\FileLayout as JLayoutFile;
use Joomla\CMS\Language\Text as JText;

//extract($displayData);

/**
 * Layout variables
 * -----------------
 * 
 * @var   boolean  $item			Материал
 * @var   array    $field         Options available for this field.
 * @var   array    $fieldParams       Options available for this field.
 * @var   string   $table			Таблица опций
 * @var   array    $i				index таблицы (table) опций в массиве $field->value
 * @var   string   $currency		Валюта
 * @var   array    $currencies		Валюты
 * @var   array    $options			Опции
 */
// Initialize some field attributes.
//$class    = !empty($class) ? ' class="' . $class . '"' : '';
//$disabled = $disabled ? ' disabled' : '';
//$onchange = $onchange ? ' onchange="' . $onchange . '"' : '';


//$select_param_field = $displayData['select_param_field']; // Способ выбора элемента указанный в настройках поля Field
//$select_param_table = $displayData['select_param_table']; // Способ выбора элемента указанный в редакторе материала Article
$select_param = $displayData['select_param'];  // Способ выбора элемента из списка опций
$compute_param = $displayData['compute_param']; // Способ вычисления суммы
$layout_param = $displayData['layout_param'];  // Имя макета группы, т.е. имя этого файла
$item = $displayData['item'];   // Материал
$field = $displayData['field']; // 
$fieldParams = $displayData['fieldParams']; 
$name_param	 = $displayData['name_param']; 
$table = $displayData['table']; //Таблица опций
$index_table = $displayData['index_table'];  //index таблицы (table) опций в массиве $field->value
//$short_cur_default = $fieldParams['list_currencies']->short_cur[($fieldParams['list_currencies']->default_cur)]; //Название параметра
$short_cur_default = PlgFieldsCost::$currency->short_cur;//
$dataFormCost = $displayData['dataFormCost'];; //Данные из формы только что введенные пользователем
$typeField		= $displayData['typeField'];
$options		= $displayData['options'];
$formName		= $displayData['formName'];
//$option			= $displayData['option']; 

//toPrint($table->select, '$table->select:' . $i,0);
//toPrint($displayData, '$displayData',0);

//echo "<pre>\$table:$i\n".(print_r($layout_param,true)) ."</pre>";

//else{
//	$table->select = '';
//}


//toPrint($table->select, '$table->select:' . $i,0);

$fieldParams['list_fields'];  // Список Параметров
$fieldParams['list_currencies']; // Список Валют
$fieldParams['list_units'];   // Список едениц учета

$currency	= PlgFieldsCost::$currency;
$currencies = PlgFieldsCost::$currencies;

//toPrint($table->title,'$table->title:',0); 
//toPrint($currency->short_cur,'$currency->short_cur'); 
//toPrint($fieldParams,'$fieldParams'); 
//echo "<hr>";
//echo JText::sprintf('PLG_COST_PARAM_PRICE',$currency->short_cur);//$currency->short_cur
//echo "<hr>"; 
//echo "<hr>";


echo "<table class='tbl table caption-top'>";

echo "<caption>{$fieldParams['list_fields']['name_param'][$index_table]}</caption>";

echo "<tr><th>";
if($name_param && $displayData['is_titles']){
	echo JText::_('PLG_COST_PARAM_TITLE');
	echo "</th><th>";
}
if($displayData['is_options']){
	echo JText::_('PLG_COST_PARAM_OPTIONS');
	echo "</th><th>";
}
echo JText::_('PLG_COST_PARAM_PRICE'); //$currency->short_cur PLG_COST_PARAM_PRICE JText::sprintf('PLG_COST_PARAM_PRICE_F', $currency->short_cur)
if($select_param != '_'){
	echo "</th><th>";
	echo JText::_('');
}
echo "</th></tr>";

foreach (array_keys($table->option) as $index_row) { // light  info   secondary
//$select_param;
//$select_param_table;
//$select_param_field;
	$value = 0;
	$checked = '';
	$name_sfx = '';
	$class_sfx_control = '';
	$class_sfx_label = '';
//	if(empty($table->select[$index_row]))
//		$table->select[$index_row] = '';

//	if($select_param && $select_param == $table->select_param) {//Задан параметр выбора поля
		switch ($typeField) {//$table->select_param
			case 'radio' :
			case 'one' :
				$value = 1;
				$checked = isset($table->select[$index_row]) && $table->select[$index_row] ? 'checked' : '';
				$name_sfx = "";
				$class_sfx_control .= '-check';
				$class_sfx_label .= '-check'; 
				break;
			case 'checkbox' :
			case 'multi' :
				$value = 1;
				$checked = isset($table->select[$index_row]) && $table->select[$index_row] ? 'checked' : '';
				$name_sfx = "[$index_row]";
//toPrint($table->select[$index_row],'$table->select[$index_row]:'); 
				$class_sfx_control .= '-check';
				$class_sfx_label .= '-check'; 
				break;
			case 'number' : 
			case 'quantity' : 
				$value = isset($table->select[$index_row]) ? $table->select[$index_row] : 0; 
				$name_sfx = "[$index_row]";
				$class_sfx_control .= '-control';
				$class_sfx_label .= ''; 
				break;
			case '_' : 
				$value = isset($table->select[$index_row]) ? $table->select[$index_row] : '';
				$name_sfx = '';
				$class_sfx_control .= '';
				$class_sfx_label .= ''; 
				break;
			default : 
				$value = isset($table->select[$index_row]) ? $table->select[$index_row] : '';
				$name_sfx = '';
				$class_sfx_control .= '';
				$class_sfx_label .= ''; 
				break;
		}
//	}
		
	
			$checked = $dataFormCost ? '' : $checked;
			$dataForm = $dataFormCost[$index_table] ?? FALSE;
			if($dataForm !== FALSE){
				$dataForm = in_array($typeField, ['radio','one']) && is_scalar($dataForm)
					? JFilterInput::getInstance([], [], 1, 1)->clean($dataForm, 'INT')
					: JFilterInput::getInstance([], [], 1, 1)->clean(($dataForm[$index_row] ?? 0), 'INT');
			}
			if(in_array($typeField, ['radio','one']) && $dataForm !== FALSE){
				$checked = $dataForm == $index_row ? 'checked' : '';
				$value = $index_row ?? FALSE;
			}
			if(in_array($typeField, ['checkbox','multi']) && $dataForm !== FALSE){
				$checked = $dataForm ? 'checked' : '';
				$value = 1;
			}
			if(in_array($typeField, ['number','quantity']) && $dataForm !== FALSE){
				$checked = $dataForm ? 'checked' : '';
				$value = $dataForm;
			}
		
//	if($select_param && $select_param != $table->select_param) {//Задан параметр выбора поля
//	}
//		
//	if(empty($select_param)) {//Задан параметр выбора поля
//		switch ($table->select_param) {
//			case 'one' :
//				$value = $index_row;
//				$checked = isset($table->select) && is_scalar($table->select) && $index_row == (int)$table->select ? 'checked' : '';
//				break;
//			case 'multi' :
//				$value = $index_row;
//				$checked = isset($table->select) && is_array($table->select) && in_array($index_row, (array)$table->select) ? 'checked' : '';
//				break;
//			case 'quantity' : 
//				$value = isset($table->select[$index_row]) ? $table->select[$index_row] : 0;
//				break;
//			case '_' : $value = isset($table->select[$index_row]) ? $table->select[$index_row] : '';
//				break;
//		}
//	}

//toPrint($options,'$options',0); 
//toPrint($table->option[$index_row],'$table->option[$index_row]'); 
		$option = $options && $options != [''] && $options != [] ? $options[$table->option[$index_row]] : $table->option[$index_row];


	echo "<tr class='checkboxes '>";
	
	if($name_param && $displayData['is_titles'])
		echo "<td><label class='form{$class_sfx_label}-label form-control-plaintext' for='cost_{$item->id}_{$field->id}_{$index_table}_{$index_row}'><span>{$table->title[$index_row]}</span></label></td>";

	if($displayData['is_options'])	
		echo "<td><label class='form{$class_sfx_label}-label form-control-plaintext' for='cost_{$item->id}_{$field->id}_{$index_table}_{$index_row}'><span>{$option}</span></label></td>";
	
	echo "<td><label class='form{$class_sfx_label}-label form-control-plaintext' for='cost_{$item->id}_{$field->id}_{$index_table}_{$index_row}'><b>{$table->cost[$index_row]} $short_cur_default</b></label></td>";
	
	if($select_param != '_')
		echo <<<OPT
	<td>
		<label class='form{$class_sfx_label}-label form-control-plaintext' >
		<input type='$typeField' name='cost[$item->id][$field->id][$index_table]$name_sfx'  data-cost='{$table->cost[$index_row]}'   data-compute='{$compute_param}' 
			autocomplete='off' min='0'
						class='form{$class_sfx_control}-input '  form='$formName' 
		  $checked value='$value' id='cost_{$item->id}_{$field->id}_{$index_table}_{$index_row}'></label></td>
OPT;
	echo "</tr>";
}


echo "</table>"; //? >
