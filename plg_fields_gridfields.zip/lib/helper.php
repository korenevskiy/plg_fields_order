<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */


if (!function_exists('str_starts_with')) {
	function str_starts_with(?string $haystack, ?string $needle): bool
    {
		$haystack = $haystack  ?? ''; $needle = $needle  ?? '';
        return 0 === strncmp($haystack, $needle, \strlen($needle));
    }
	
}
if (!function_exists('str_ends_with')) {
    function str_ends_with(?string $haystack, ?string $needle): bool
    {
		$haystack = $haystack  ?? ''; $needle = $needle  ?? '';
        return '' === $needle || ('' !== $haystack && 0 === substr_compare($haystack, $needle, -\strlen($needle)));
    }
}