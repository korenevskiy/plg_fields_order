<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Fields.Sql
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
//toPrint($context,'Type :'.$field->type,0,'pre');

//Поле выводимое в клиенте материала -------- Клиент !!!
//----------------------------------------------------------------------------------------
use Joomla\CMS\Factory as JFactory;
use Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use Joomla\CMS\Layout\FileLayout as JLayoutFile;
use Joomla\CMS\Language\Text as JText;
//use Joomla\CMS\Form\Form as JForm;




//Поле выводимое в клиенте материала
//echo '<br>Вывод  из папки TMPL Opera_82.0.4227.43_Setup_x64.exe';
//return;

if(empty($item->params))
    return;

//toPrint($field->content, get_class($this));// 

if(empty($field->value))
    return;

$value = $field->value;


//toPrint(array_keys((array)$this), get_class($this));// 
//toPrint($this->categoryFieldsOrderIds,'$field->categoryFieldsOrderIds :'.$field->context); 
//toPrint($fieldParams,'$fieldParams :'.$field->context); 

$formName = "form{$fieldParams['orderId']}_{$item->id}";
//form10_97	form7_97
if($this->categoryFieldsOrderIds){
//	$form_id[]
//	form='form{$item->id}_{$fieldParams['orderId']}'
	$orderInfo = reset($this->categoryFieldsOrderIds);
	$formName = "form{$orderInfo['field_id']}_{$orderInfo['itemId']}";
}
//toPrint($value,'$field->value',0); 
//toPrint($fieldParams['orderId'],'orderId');//list_fields
//toPrint($item);// 
//toPrint($field);// 
//toPrint($paramPlugin);//
//form10_97	form7_97
$itemId = $item->id;
//$item->jcfields;							//array - массив Полей
//$item->jcfields[$fieldId];				//stdClass  - Поле
//$item->jcfields[$fieldId]->fieldparams;	//JRegistry - Параметры поля
//$item->jcfields[$fieldId]->params;		//JRegistry - остальные настройки поля.
//$item->jcfields[$fieldId]->paramPlugin;	//JRegistry - Параметры плагина

$input = JFactory::getApplication()->input;// getInput();
$dataFormCost = $input->getArray(['cost'=>[$item->id=>[$field->id=>'ARRAY']]]);
$dataFormCost = $dataFormCost['cost'][$item->id][$field->id] ?? [];

//toPrint('-');
//toPrint($input->get('cost'));
//toPrint($dataFormCost,'',0);
//toPrint($value,'',0);

//toPrint($this->article, '$this->article');
//toPrint($this->paramsArticle, '$this->paramsArticle');
//toPrint($this->paramsField, '$this->paramsField');

//return;

//toPrint(PlgFieldsCost::$currency);

//toPrint(get_class($this));
$fieldParams['list_fields'];		// Список Параметров
$fieldParams['list_currencies'];	// Список Валют
$fieldParams['list_units'];			// Список едениц учета
//$fieldParams['list_fields']['name_param'][$index_table]; //Название параметра
//if(is_array($fieldParams['list_currencies']->default_cur))
//	$default_cur = array_search(true, $fieldParams['list_currencies']->default_cur);
//else
//	$default_cur = $fieldParams['list_currencies']->default_cur;

$short_cur_default = PlgFieldsCost::$currency->short_cur;// $fieldParams['list_currencies']->short_cur[$default_cur]; //Название параметра

$html = "<output id='cost' data-currency='$short_cur_default' class='h4'>0 $short_cur_default</output>";

//toPrint($fieldParams['list_fields'] ,'',0 ); 
//toPrint($value ,'',0 ); 
//$html .= '<dl>';
//foreach($field->value as $k => $kk)
//	toPrint($k ,'$value',0 ); 

//$fieldParams['list_params_fields'];
//$fieldParams['list_params_captions'];
$list_min_cost		= false;//$fieldParams['list_min_cost'];
$list_max_cost		= false;//$fieldParams['list_max_cost'];
$list_count_quantity= 0;//$fieldParams['list_count_quantity'];
$list_count_params	= 0;//$fieldParams['list_count_params'];
$list_params_captions = '';


foreach ($fieldParams['list_fields']['index_param'] as $i_table => $index_table){
////$field->value as $index_table => $table 
////$fieldParams['list_fields']['index_param'] as $i_table => $index_table
//
//
//
//	$index_table = (int)$index_table;
//toPrint($index_table, "\$i_table:$i_table \$index_table:$index_table ".(isset($field->value[$index_table])?'True':'False') ); 
	$table = $field->value[(int)$index_table] ;
//toPrint($table  ); 
	
	if(false == isset($table->display) || empty($table->display) || false == is_array($table->display))
		continue;
		
	foreach($table->display as $i => $show){
		if(empty($show))
			unset($table->display[$i]);
	}
		
	if(empty($table->display))
		continue;
	
	// Определяем наличие всех Наименований, для показа этой колонки
	$is_titles = false;
	if(isset($table->title) && is_array($table->title)){
		foreach ($table->title as $title){
			$is_titles = $title ? true : $is_titles;
		}
	}
	
	// Определяем наличие всех Опций, для показа этой колонки
	$is_options = false; 
	if(isset($table->option) && is_array($table->option)){
		foreach ($table->option as $opt){
			$is_options = $opt ? true : $is_options;
		}
	}

	foreach($table->display as $i => $show){
		is_null($table->title[$i])	&& $table->title[$i]	= '';
		is_null($table->option[$i])	&& $table->option[$i]	= '';
	}

//	$html .= "<dt>".$fieldParams['list_fields']['name_param'][$index_table]."</dt>";

//toPrint($table,'$table:'.$index_table); 

//toPrint($fieldParams['list_fields']['layout_param'][$index_table],'$fieldParams[list_fields][layout_param][$index_table]'); 

	$name_param		= $fieldParams['list_fields']['name_param'][$index_table];
	$select_param	= empty($fieldParams['list_fields']['select_param'][$index_table])  ? $table->select_param  : $fieldParams['list_fields']['select_param'][$index_table];
	$compute_param	= empty($fieldParams['list_fields']['compute_param'][$index_table]) ? $table->compute_param : $fieldParams['list_fields']['compute_param'][$index_table];
	$layout_param	= $fieldParams['list_fields']['layout_param'][$index_table] == -1  ? $table->layout_param  : $fieldParams['list_fields']['layout_param'][$index_table];
	$layout_param   = str_replace('.php', '', $layout_param);
	
	$options = explode('|', trim($fieldParams['list_fields']['option_param'][$i_table]) ?? ''); //$options[]
	
//toPrint($fieldParams['list_fields']['option_param'][$i_table]," $index_table "); 
//toPrint($table->select_param.'-----------------------------------------------------');
//toPrint($table->select, '',0);
//toPrint($table, '$table:'.$index_table);
//toPrint($layout_param, '$table:'.$index_table);
	
	if(false == isset($table->select)){
		$table->select = [];//array_fill_keys(array_keys($table->option), 0);
	}
	if(in_array($table->select_param, ['radio','checkbox','one','multi'])){
		$selects = array_fill_keys(array_keys($table->option), 0);
//toPrint($selects, '$selects',0);
		foreach ((array)$table->select as $key)
			$selects[(int)$key] = 1;
		$table->select = $selects;
	}
	if($table->select_param == 'number' && isset($table->option)){
		foreach ((array)$table->option as $key => $v_select)
			$table->select[$key] = (int)($table->select[$key] ?? 0);
	}

//	$select_param_field = $fieldParams['list_fields']['select_param'][$index_table];
	$is_q = str_ends_with($select_param, '?');
	
//toPrint($select_param, '$is_q: '.$is_q.' ' . $i,0);
	
	switch (substr($select_param, -1)){
		case '!':
		case '?':
			$select_param = substr($select_param, 0, -1);
			break;
	}
	
	
	
	$typeField = $is_q && $table->select_param != $select_param ? $table->select_param : $select_param;
	
	switch ($typeField) {
//		case 'radio'	: $typeField = 'radio';		break;
//		case 'checkbox' : $typeField = 'checkbox';	break;
//		case 'number'	: $typeField = 'number';	break;
		case '_'		: $typeField = 'hidden';	break;
//		case 'hidden'	: $typeField = 'hidden';	break;
	}
	
	
	
	
	foreach ($table->display as $index_row => $display){ // light  info   secondary
		//$table->cost[$index_row]} $short_cur_default		$list_min_cost//$fieldParams['list_min_cost'];
			
//toPrint($options,$table->title[$index_row]); 
		$option = $options && $options != [''] && isset($table->option[$index_row]) && isset($options[$table->option[$index_row]]) 
				? $options[$table->option[$index_row]] : $table->option[$index_row];
			
		$title = $table->title[$index_row] && $option ? $table->title[$index_row].' - '.$option : $table->title[$index_row].' '.$option;
		
		
		if($table->cost[$index_row] < $list_min_cost || $list_min_cost === false){
			$list_min_cost = $table->cost[$index_row]; 
//toPrint(($fieldParams['list_fields']['account_param']),$index_row.' $table->account[$index_row] '.$title);		
//toPrint($table->cost,$index_row.' $table->account[$index_row] '.$title);	
		}
		
		
		if($table->cost[$index_row] > $list_max_cost || $list_max_cost === false)
			$list_max_cost = $table->cost[$index_row];
		
		$list_count_params += 1;
		
		if(in_array($fieldParams['list_fields']['account_param'][$index_table], ['1','1!']) 
				&& isset($table->account) && is_array($table->account) && $table->account[$index_row] == 1)
			$list_count_quantity += $table->quantity[$index_row];
		
		

				
		if($fieldParams['list_params_captions'])
			$list_params_captions .= "<label class='list_params_captions'>$title</label> ";
	}
	
	
	if($this->categoryFieldsOrderIds && empty($fieldParams['list_params_fields']))
		continue;
	
//toPrint($select_param, '$table->select: '.$typeField.' ' . $i,0);
//toPrint($table->select, '$table->select: '.$typeField.' ' . $i,0);
//toPrint($table->select, '$table->select: '.$typeField.' ' . $i,0);
//	$select_param_field = str_ends_with($fieldParams['list_fields']['select_param'][$index_table], '!') 
//			? $select_param = substr($fieldParams['list_fields']['select_param'][$index_table], 0, -1) : $fieldParams['list_fields']['select_param'][$index_table];
//	$select_param_field = str_ends_with($fieldParams['list_fields']['select_param'][$index_table], '!') 
//			? $select_param = substr($fieldParams['list_fields']['select_param'][$index_table], 0, -1) : $fieldParams['list_fields']['select_param'][$index_table];
	
//	jform[list_fields][name_param][]
//	jform[fieldparamsx][list_fields][name_param][]  hidden default
			
		
	$html .= "<input type='hidden' name='cost[$item->id][$field->id][item_title]' 
				default='" . htmlspecialchars($item->title) . "' value='" . htmlspecialchars($item->title) . "' form='$formName' >";
	$html .= "<input type='hidden' name='cost[$item->id][$field->id][item_id]' 
				default='$item->id' value='$item->id' form='$formName' >"; 

//toPrint($table, '$field->value $layout_param:'.$layout_param,0,'message');
//continue;
//return;
//toPrint($select_param, '$select_param');
//toPrint($table->select_param, '$select_param_table');
//toPrint($select_param_field, '$select_param_field');
	
//toPrint($fieldParams['list_fields']['select_param'][$index_table],'$fieldParams[list_fields][select_param][$index_table]');
//toPrint($fieldParams['list_fields']['layout_param'][$index_table],'$fieldParams[list_fields][layout_param][$index_table]');
//toPrint($table->layout,'$table->layout');
//toPrint($layout_param,'$layout_param');

	if($layout_param){	
////toPrint($table, '$field->value $layout_param:'.$layout_param,0,'message');
//continue;
////return;
//		$file = JPATH_PLUGINS . "/fields/cost/tmpl/group/$layout_param.php";
		$path = JPATH_PLUGINS . "/fields/cost/tmpl/group/";
//		$html .= "<dd class='form-check'>";
		$html .= JLayoutHelper::render($layout_param,
				[
					'table'			=> $table,
					'fieldParams'	=> $fieldParams,
					'item'			=> $item,
					'field'			=> $field,
					'i_table'		=> $i_table,
					'index_table'	=> $index_table,
					'compute_param'	=> $compute_param,
					'layout_param'	=> $layout_param,
					'select_param'	=> $select_param,
					'name_param'	=> $name_param,
					'formName'		=> $formName,
//					'select_param_table'=>$table->select_param,
//					'select_param_field'=>$fieldParams['list_fields']['select_param'][$index_table],
//					'select_param_field'=> $select_param_field,
					'typeField'		=> $typeField,
					'options'		=> $options,
					'dataFormCost'	=> $dataFormCost,
					
					'is_titles'		=> $is_titles,
					'is_options'	=> $is_options, 
				],
				$path);
		continue;
//echo "<pre>\$cost:$i\t".(print_r($layout_param,true)) ."</pre>";
//echo "<pre>\$cost:$i\t".(print_r($path,true)) ."</pre>";
//		$html .= "</dd>";
	}
		
	
	
//				data-cost='{$table->cost[$index_row]}'  data-compute='{$compute_param}'  placeholder='$title' 
//				name='cost[$item->id][$field->id][$index_table]$name_sfx' form='$formName' $checked 
//				class='$class_sfx_control-check col-auto' id='cost_{$item->id}_{$field->id}_{$index_table}_{$index_row}' autocomplete='off' min='0'

//toPrint($table, '$field->value $layout_param:'.$layout_param,0,'message');
//continue;
//return;
		

		
	$class_sfx_form = in_array($typeField, ['radio','one','checkbox','multi',]) ? '_form-check' : ' ';
	$default_check = isset($table->option) && $table->option ? '' : ' checked ';
	$html .= "<dd class='$class_sfx_form hstack row-cols-auto gap-2 row xg-3'>";//$typeField&emsp;&emsp;&emsp;
	foreach ($table->display as $index_row => $display){ // light  info   secondary
			
		
		
		//$table->cost[$index_row]} $short_cur_default		$list_min_cost//$fieldParams['list_min_cost'];
			
//toPrint($options,$table->title[$index_row]); 
		$option = $options && $options != [''] && isset($table->option[$index_row]) && isset($options[$table->option[$index_row]]) 
				? $options[$table->option[$index_row]] : $table->option[$index_row];
			
		$title = $table->title[$index_row] && $option ? $table->title[$index_row].' - '.$option : $table->title[$index_row].' '.$option;
		
		
		
		
		
		
		
			
		$value = 0;
		$checked = '';
		$class_sfx_control = ''; 
		$class_sfx_label = '';
		$name_sfx = '';
//	if(empty($table->select[$index_row]))
//		$table->select[$index_row] = '';

//	if($select_param && $select_param == $table->select_param) {//Задан параметр выбора поля
		switch ($typeField) {//$table->select_param
			case 'radio' :
			case 'one' :
				$value = $index_row; // 1;
				$checked = $table->select[$index_row] ? 'checked' : '';
				$class_sfx_control .= 'btn';
				$class_sfx_label .= ' btn-outline btn-outline-secondary btn'; 
				$name_sfx = "";
				break;
			case 'checkbox' :
			case 'multi' :
				$value = 1;
				$checked = $table->select[$index_row] ? 'checked' : '';
//toPrint($table->select[$index_row],'$table->select[$index_row]:'); 
				$class_sfx_control .= 'btn';
				$class_sfx_label .= 'btn-outline btn-outline-secondary btn'; 
				$name_sfx = "[$index_row]";
				break;
			case 'number' : 
			case 'quantity' : 
				$value = $table->select[$index_row] ?? 0; 
				$class_sfx_control .= 'form-control w-auto ';
				$class_sfx_label .= ' _visually-hidden'; 
				$name_sfx = "[$index_row]";
				break;
			case '_' : 
				$value = $table->select[$index_row] ?? '';
				$class_sfx_control .= '';
				$class_sfx_label .= ''; 
				$name_sfx = '';
				break;
			default : 
				$value = $table->select[$index_row] ?? '';
				$class_sfx_control .= '';
				$class_sfx_label .= ''; 
				$name_sfx = '';
				break;
		} 
//echo 'fieldId:'. $field->id.' indexRow:'. $index_row.' type:'. $typeField."   cost_{$item->id}_{$field->id}_{$index_table}_{$index_row}<br>";
			
		/**
		 * @var array $title Заголовок
		**/
			$title = $table->title[$index_row] && $option ? $table->title[$index_row].' - '.$option : $table->title[$index_row].' '.$option;
			
			$checked = $dataFormCost ? '' : $checked;
			$dataForm = $dataFormCost[$index_table] ?? FALSE;
			if($dataForm !== FALSE){
				$dataForm = in_array($typeField, ['radio','one']) && is_scalar($dataForm)
					? JFilterInput::getInstance([], [], 1, 1)->clean($dataForm, 'INT')
					: JFilterInput::getInstance([], [], 1, 1)->clean(($dataForm[$index_row] ?? 0), 'INT');
			}
			if(in_array($typeField, ['radio','one']) && $dataForm !== FALSE){
				$checked = $dataForm == $index_row ? 'checked' : '';
				$value = $index_row ?? FALSE;
			}
			if(in_array($typeField, ['checkbox','multi']) && $dataForm !== FALSE){
				$checked = $dataForm ? 'checked' : '';
				$value = 1;
			}
			if(in_array($typeField, ['number','quantity']) && $dataForm !== FALSE){
				$checked = $dataForm ? 'checked' : '';
				$value = $dataForm;
			}
			
//toPrint($dataForm,' type:'.$typeField.'  $i:'.$i. ' $index_row:'.$index_row.'  -'.$checked, 0 );
			
//			name='order{$item->id}' form{$item->id}_{$field->id}
		
			$html .= <<<OPT
			
			<input type='$typeField' value='$value' data-cost='{$table->cost[$index_row]}'  data-compute='{$compute_param}'  placeholder="$title"
				name='cost[$item->id][$field->id][$index_table]$name_sfx' form='$formName' $checked 
				id='cost_{$item->id}_{$field->id}_{$index_table}_{$index_row}'	class='$class_sfx_control-check col-auto' autocomplete='off' min='0'>
				
			<label class='$class_sfx_label col-auto ' for='cost_{$item->id}_{$field->id}_{$index_table}_{$index_row}'>
				
			<span>{$title} <b>{$table->cost[$index_row]} $short_cur_default</b></span></label>
OPT;
	}
	$html .= "</dd>";
	
}
//$html .= '</dl>';



	if($this->categoryFieldsOrderIds && $fieldParams['list_count_params'])
		$html .= "<label class='list_count_params'>$list_count_params</label> ";
	if($this->categoryFieldsOrderIds && $fieldParams['list_count_quantity'])
		$html .= "<label class='list_count_quantity'>$list_count_quantity</label> ";
	if($this->categoryFieldsOrderIds && $fieldParams['list_max_cost'])
		$html .= "<label class='list_max_cost'>$list_max_cost $short_cur_default</label> ";
	if($this->categoryFieldsOrderIds && $fieldParams['list_min_cost'])
		$html .= "<label class='list_min_cost'>$list_min_cost $short_cur_default</label> ";
	if($this->categoryFieldsOrderIds && $fieldParams['list_params_captions'])
		$html .= "$list_params_captions";
	
	

echo $html;
return ;



// <editor-fold defaultstate="collapsed" desc="Мусор">


$fieldParams;//параметры поля и плагина
//toPrint($this,'modules.php');
//toPrint(array_keys((array)$this),'$this.keys');
//toPrint(($this->params),'$this->params',0);
$context;// тип блога, тип статьи. Пример: com_content.article
$item;// объект Статьи в блоге
$field; // объект добавляемого поля к статье в блоге
$field_modules_type = $fieldParams->get('method', 'pos');
$field_multiple = $fieldParams->get('multiple', TRUE);
$field_value = $fieldParams->get('query', 0);
$tasks = $fieldParams->get('task', []);

$display = $field->params->get('display'); // Место где должен отображатся поле. ПослеЗаголовка, ПослеТекса, ПередТекстом.
$context = $field->context; //com_content.article 

$show_text = $item->params->get('show_text'); // Место как должно отображатся текст описания
//,hide,or,intro,full,all
$show_intro = $item->params->get('show_intro'); // Место как должно отображатся текст описания
//,use_article,0,1

$ignore = array('GLOBALS', '_FILES', '_COOKIE', '_POST', '_GET', '_SERVER', '_ENV', 'ignore');
$vars = array_diff_key(get_defined_vars() + array_flip($ignore), array_flip($ignore));
//toPrint(array_keys($vars),'$this'); 
//toPrint($this->path,'$path'); 
//toPrint(array_keys(get_object_vars($this->_subject)),'$this->_subject'); 

//$values = explode(',', $field_value);

//toPrint($field_value,'$field_value'); 
//toPrint($context,'$context'); //com_content.article 
//toPrint($field,'$field'); 


//else {    
//$query = "
//SELECT  CONCAT(id ,': ',title,' :/',module,'/',position,'') title,
//     id  /*id, title, position, module, client_id ,*/
//FROM #__modules 
//WHERE id IN ($where) ; " ;
//}

$mod_type = $field_modules_type;

//if(count($value)==1 && empty($value[0]))
//    return '';

//toPrint($value,'$value',0);  
//toPrint($fieldParams,'$fieldParams'); 
//toPrint($context,'$context'); 
//toPrint(array_keys((array)$item),'$item'.$item->title); 
//toPrint($field,'$field'); 
 //toPrint($fieldParams,'$fieldParams'); 


$view = JFactory::getApplication()->input->getCmd('view'); 
 


$ids = [];

$condition = '';
$db = JFactory::getDbo();


foreach ((array) $field->value as $v) {
	if (empty($v))     {
		continue;
	}

	$ids[] = $db->q($v);
}
$where = implode(',', $ids);


$query = $fieldParams->get('query', '');



//toPrint($field->value,'$field->value',0);
//toPrint($ids,'$ids1');
//toPrint($value,'$value');
//toPrint($value,'$value');
//return '123';



$tag = JFactory::getLanguage()->getTag();

if ($field_modules_type == 'pos') {

	$query = "
SELECT id, title, position, module, client_id, published, showtitle, params, ordering, language, content  
     /*CONCAT(id ,': ',title,' :/',module,'/',position,'') title, id  */
FROM #__modules 
WHERE position IN ($where) AND position != '' AND published = 1  AND language IN ('$tag','*')
ORDER BY position, ordering, id ; ";

} 
elseif ($field_modules_type == 'ids') {

	$query = "
SELECT id, title, position, module, client_id, published, showtitle, params, ordering,  language, content 
     /*CONCAT(id ,': ',title,' :/',module,'/',position,'') title, id  */
FROM #__modules 
WHERE id IN ($where)  AND published = 1  AND language IN ('$tag','*')
ORDER BY position, ordering, id ; ";

}

//toPrint($field_modules_type,'$field_modules_type',0,true, true);
//toPrint($where,'$where',0,true, true);
//toPrint($query,'$query',0,true, true);
//return;

// Run the query with a having condition because it supports aliases
$db->setQuery($query);
$items = $db->loadObjectlist('id'); // id, title, position, module, client_id, published, showtitle, params.
//    $items = $db->loadAssocList('id', 'id'); 


//$ix = [];
//foreach ($items as $i => $item){
//    $ix[$i] = [$item->ordering,$item->title,$item->module];
//}
//159, 162, 166, 174, 158, 157        166, 158, 157, 159, 162,           174
//  5    1    6   11    9   10          2    6    7    8   11   
//$ids = array_keys($items) ;
//toPrint($ids,'$ids2');
//foreach ($items as &$item)
//    $item->params = '';
//toPrint($items,'$items',0); 
//toPrint($ix,'$items',0); 
//toPrint($items[155],'$items',0);  
//toPrint($items,'$items',0,true, true);
//return;


$texts = array();


$modules = [];

//if(!toPrint()){
//    return;
//}

//$menuitem = JFactory::getApplication()->getMenu()->getActive();
//$doc = JFactory::getDocument();
$view = JFactory::getApplication()->input->getCmd('view');
//$router2 = JFactory::getApplication()->getRouter()->getVars();
 
// $item->params->get('category_layout');   [category_layout] => _:blog   [show_text]
// introtext   fulltext   text   jcfields
// 
//  task
//toPrint($field,'$field');
//toPrint($router1,'$router1',0);
//toPrint($router2,'$router2',0);
//toPrint($menuitem,'$menuitem');
//toPrint($doc,'$doc');
//toPrint($fieldParams,'$fieldParams');
//toPrint(array_keys((array)$field) ,'$field');
//toPrint(array_keys((array)$item) ,'$item',0);
//toPrint($item,'$item');
//toPrint(array_keys((array)$this) ,'$this');
//toPrint(array_keys((array)$this) ,'$this');
//toPrint(array_keys((array)$this) ,'$this');
//toPrint($this->type ,'$thisType');
//toPrint(JFactory::getApplication() ,'JFactory::getApplication()');
//toPrint($this ,'$this');

//return;

foreach ($items as $mod_id => $module) {
//    toPrint($mod_id,'$mod_id');
//    toPrint($module,'$module '.$mod_id);
//    if (in_array($mod_id, (array)$field->value))
//    { 
	//$multi_items[$key]->module = $module->module;
	//
	//if(!isset($module->module))            {echo "<pre>$multi_module_id: ".print_r($module,true). "</pre>";continue;}


	$file = JPATH_SITE . "/modules/$module->module/$module->module.php";

	//    echo $file."<br>";//149,142,146
	//echo "<pre> ** ".print_r($multi_items,true)."++</pre>"; 
	//$b = $params->get('base');
                 
//toPrint($module,'$mod_id');    continue;
	if (file_exists($file)) {


//toPrint($file,'$file: '.$mod_id);
		//$multi_items[$key]->params = unserialize  ($module->params);
//                $module->params = json_decode ($module->params);
		//echo "<pre> **".print_r( $module,true). "++</pre>"; 
		//var_dump($module->params);
		//echo "<br>".$file."<br>". $module->params."<br> ";
		$module->params = $params = new Joomla\Registry\Registry($module->params);
		//$params->setProperties($module->params);
		
                //$module->params = $params;
		$module->parentId = 0;
//				$module->style = $module->params->get('style','');
//				$module->moduleclass_sfx = $module->params->get('moduleclass_sfx','');
//				$module->module_tag = $module->params->get('module_tag','');
//				$module->header_tag = $module->params->get('header_tag','');
//				$module->header_class = $module->params->get('header_class',''); 
				
//                $items[$mod_id]->params= $module->params;
//                $items[$mod_id]->parentId= $module->parentId;
//                $items[$mod_id]->style= $module->style;
//                $items[$mod_id]->moduleclass_sfx= $module->moduleclass_sfx;
//                $items[$mod_id]->module_tag= $module->module_tag;
//                $items[$mod_id]->header_tag= $module->header_tag; 
//                $items[$mod_id]->header_class= $module->header_class;
		
				//if ($multi_module_id == 144 || $multi_module_id == 145)echo "<pre> **".print_r( $module,true). "++</pre>"; 


		JFactory::getLanguage()->load($module->module);


		
                $content = '';

		ob_start();

		require $file;
		$content = ob_get_clean() . $content;


		if (empty($module->published) || empty($content)) {
			unset($items[$mod_id]);
			continue;
			;
		}


//toPrint($module,'$module');
//                ob_start();
		//echo $file."<br>" ;//149,142,146
		$module_tag = (empty($module->style)) ? "div" : $module->module_tag;


		echo "<$module_tag class=\" field_module $module->module $module->moduleclass_sfx id_$module->id \">";


		if ($module->showtitle) {
			echo "<$module->header_tag class=\"$module->header_class\" >$module->title</$module->header_tag>";
		}




		echo $content;


		
                echo "</$module_tag>";
//toPrint($module,'$mod_id');    continue;
//                $items[$multi_module_id]->content = ob_get_clean();
		//$multi_items[$multi_module_id]->id = $multi_module_id; 
	}
//    }
}

// </editor-fold>



//echo htmlentities(implode(', ', $modules));
//echo "LaLa !!!";
