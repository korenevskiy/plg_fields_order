<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_fields
 *
 * @copyright   (C) 2019 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

//namespace Joomla\Component\Fields\Administrator\Field;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\SubformField;
//use Joomla\Component\Fields\Administrator\Field\SubfieldsField as JFormSubFields;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
//use Joomla\Component\Fields\Administrator\Helper\FieldsHelper;

use Joomla\CMS\Plugin\PluginHelper as JPluginHelper;
use Joomla\Registry\Registry as JRegistry;
use Joomla\CMS\Form\Field\ListField as JFormFieldList;
use \Joomla\CMS\Form\FormField as JFormField;
use Joomla\CMS\Language\Text as JText;
use Joomla\CMS\HTML\HTMLHelper as JHtml; 
use Joomla\CMS\Factory as JFactory;
//use Joomla\CMS\Document\Document as JDocument;
//use Joomla\CMS\Form\FormHelper as JFormHelper;
use Joomla\CMS\Helper\ModuleHelper as JModuleHelper;
use Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use Joomla\CMS\Layout\FileLayout as JLayoutFile;
use \Joomla\CMS\Version as JVersion;
use Joomla\CMS\Form\Form as JForm;
use Joomla\CMS\Language\Language as JLanguage;
//use Joomla\CMS\Layout\BaseLayout as JLayoutBase;

//JLoader::import('fields.sql.sql', JPATH_PLUGINS);

if(explode('.', PHP_VERSION)[0] < 8){
//	require_once __DIR__ . '/lib/helper.php';
	class_alias( 'JFormFieldList','JFormSubFields');
//	class_alias( 'Joomla\\CMS\\Form\\Field\\ListField','JFormSubFields');
	JLoader::register('FieldsHelper', JPATH_ADMINISTRATOR . '/components/com_fields/helpers/fields.php'); 
//	JLoader::register('FieldsHelper', JPATH_ADMINISTRATOR . '/components/com_fields/helpers/fields.php');
//	class_alias( 'Joomla\Component\Fields\Administrator\Helper\FieldsHelper','JFormSubFields'); 
}else{
	class_alias( 'Joomla\\Component\\Fields\\Administrator\\Field\\SubfieldsField','JFormSubFields');
//	class_alias( 'Joomla\\CMS\Form\\Field\\ListField','JFormSubFields'); 
	class_alias( 'Joomla\Component\Fields\Administrator\Helper\FieldsHelper','FieldsHelper'); 
}

/**
 * Fields Subfields. Represents a list field with the options being all possible
 * custom field types, except the 'subform' custom field type.
 *
 * @since  4.0.0
 */
//class SubfieldsField extends ListField 
class JFormFieldFieldslist extends JFormSubFields //JFormFieldList //JFormField //SubfieldsField //JFormSubFields  \Joomla\CMS\Form\FormField  Joomla\CMS\Form\Field; 
{
	/**
	 * The Field type exlude from list. The separating character is a comma
	 *
	 * @var string
	 *
	 * @since 4.0.0
	 */
	public $exclude = ''; 

	
	/**
	 * Array to do a fast in-memory caching of all custom field items. Used to not bother the
	 * FieldsHelper with a call every time this field is being rendered.
	 *
	 * @var array
	 *
	 * @since 4.0.0
	 */
	protected static $customFieldsCache = array();
	
	/**
	 * Method to get the field options.
	 *
	 * @return  array  The field option objects.
	 *
	 * @since   4.0.0
	 */
	protected function getOptions()
	{
		// Check whether we have a result for this context yet
		if (!isset(static::$customFieldsCache[$this->context]))
		{
			static::$customFieldsCache[$this->context] = FieldsHelper::getFields($this->context, null, false, null, true);
		}
		
		$exclude = ['subform', 'fieldslist'];
			
		if($this->exclude && is_string($this->exclude))
		{
			$exc = str_replace(' ', ',', $this->exclude);
			
			$exc = explode(',', $exc);
			
			$exc = array_map(fn($str) => trim($str), $exc);
			
			$exclude = array_merge($exclude, $exc);
		}
		
		if($this->exclude && is_array($this->exclude))
		{
			$exclude = array_merge($exclude, $this->exclude);
		}

//toPrint($exclude,'',0);
		// Iterate over the custom fields for this context
		foreach (static::$customFieldsCache[$this->context] as $i => $customField)
		{
			$customField->value = $customField->id;
			$customField->text = "$customField->title ($customField->type/$customField->name)";
			
//toPrint(static::$customFieldsCache[$this->context],$customField->type,0);
			// Skip our own subform type. We won't have subform in subform.
			if (in_array($customField->type, $exclude))
			{
				unset(static::$customFieldsCache[$this->context][$i]);
			}
		}
		
		if(explode('.', PHP_VERSION)[0] > 7){
			return parent::getOptions();
		}
		
//toPrint(static::$customFieldsCache[$this->context] , 'static::$customFieldsCache[$this->context]',1,'message');
		
//			$new = array(
//					'value'    => $value,
//					'text'     => JText::alt($text, $fieldname),
//					'disable'  => $disabled,
//					'class'    => (string) $option['class'],
//					'selected' => ($checked || $selected),
//					'checked'  => ($checked || $selected),
//			);
		
		return array_merge(parent::getOptions(), static::$customFieldsCache[$this->context]);
	}

	/**
	 * Method to attach a JForm object to the field.
	 *
	 * @param   \SimpleXMLElement  $element  The SimpleXMLElement object representing the `<field>` tag for the form field object.
	 * @param   mixed              $value    The form field value to validate.
	 * @param   string             $group    The field name group control value. This acts as an array container for the field.
	 *                                       For example if the field has name="foo" and the group value is set to "bar" then the
	 *                                       full field name would end up being "bar[foo]".
	 *
	 * @return  boolean  True on success.
	 *
	 * @since   4.0.0
	 */
	public function setup(\SimpleXMLElement $element, $value, $group = null)
	{
		if ($element['exclude'])
		{
			$this->exclude = (array)(string) $element['exclude'];
		}

		return parent::setup($element, $value, $group);
	}
}
