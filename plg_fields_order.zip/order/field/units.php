<?php defined('_JEXEC') or die; 
/**------------------------------------------------------------------------
 * field_cost - Fields for accounting and calculating the cost of goods
 * ------------------------------------------------------------------------
 * author    Sergei Borisovich Korenevskiy
 * Copyright (C) 2010 www./explorer-office.ru. All Rights Reserved.
 * @package  mod_multi_form
 * @license  GPL   GNU General Public License version 2 or later;  
 * Websites: //explorer-office.ru/download/joomla/category/view/1
 * Technical Support:  Forum - //fb.com/groups/multimodule
 * Technical Support:  Forum - //vk.com/multimodule
 */  
 

use Joomla\CMS\Plugin\PluginHelper as JPluginHelper;
use Joomla\Registry\Registry as JRegistry;
use Joomla\CMS\Form\Field\ListField as JFormFieldList;
use \Joomla\CMS\Form\FormField as JFormField;
use Joomla\CMS\Language\Text as JText;
use Joomla\CMS\HTML\HTMLHelper as JHtml; 
use Joomla\CMS\Factory as JFactory;
//use Joomla\CMS\Document\Document as JDocument;
//use Joomla\CMS\Form\FormHelper as JFormHelper;
use Joomla\CMS\Helper\ModuleHelper as JModuleHelper;
use Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use Joomla\CMS\Layout\FileLayout as JLayoutFile;
use \Joomla\CMS\Version as JVersion;
use Joomla\CMS\Form\Form as JForm;
//use Joomla\CMS\Layout\BaseLayout as JLayoutBase;
 

if(file_exists(__DIR__ . '/../functions.php'))
	require_once  __DIR__ . '/../functions.php';
  
 

class JFormFieldUnits extends JFormFieldList  {//JFormField  //JFormFieldList   \Joomla\CMS\Form\FormField  Joomla\CMS\Form\Field;
	
	private $options = null;
	
	public function getOptions() {
		
		if(is_array($this->options))
			return $this->options;
		
		$options = parent::getOptions();
		
//		JPluginHelper::importPlugin('system', 'order');
//		$data  = JPluginHelper::getPlugin('system', 'order')->params;
//		$params = new JRegistry($data);
		
//		$plg = JPluginHelper::getPlugin('fields', 'cost');
//		$plg = JFactory::getApplication()->bootPlugin('order','system'); 
		$plg = JFactory::getApplication()->bootPlugin('cost','fields');
		if(empty($plg) || empty($plg->params['list_units'])){
			return $options;
		}
		
		$list = $plg->params['list_units'];
		
		foreach (array_keys($list->type_unit) as $key){ 
			$options[$key] = JHtml::_('select.option', $key, JText::_($list->name_unit[$key]).' ('.JText::_($list->short_unit[$key]).')');
		} 
		
		return $options; 
		
		
	} 
}