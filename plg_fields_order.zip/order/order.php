<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Fields.Sql
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

$toFun = JPATH_ROOT.'/functions.php';
//echo "<b> $toFun</b>";
if(file_exists($toFun))
	require_once  $toFun;
//return;
use Joomla\CMS\Factory;

use Joomla\Event\SubscriberInterface;
use Joomla\Component\Fields\Administrator\Plugin;  
//use Joomla\Component\Fields\Administrator\Plugin\FieldsPlugin;
use Joomla\Component\Fields\Administrator\Plugin\FieldsListPlugin;
use Joomla\CMS\Form\Form as JForm;

use Joomla\CMS\Language\Text as JText;

use \Joomla\CMS\MVC\Model\BaseDatabaseModel as JModelLegacy;
use \Joomla\CMS\MVC\Controller\BaseController as JControllerLegacy;


use Joomla\CMS\Factory as JFactory;
use Joomla\CMS\Plugin\CMSPlugin;  
use Joomla\CMS\Plugin\CMSPlugin as JPlugin;
use Joomla\CMS\Event\GenericEvent as JEvent;
//use Joomla\CMS\Event\AbstractEvent;
//use Joomla\Event\Event;
use Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use Joomla\CMS\Language\Multilanguage;
use Joomla\Component\Finder\Administrator\Indexer\Indexer;
use Joomla\Registry\Registry as JRegistry;

use \Joomla\CMS\Helper\LibraryHelper as JLibraryHelper;
use \Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use \Joomla\CMS\Helper\ContentHelper as JHelperContent;
use \Joomla\CMS\Helper\CMSHelper as JHelper;
use \Joomla\CMS\Plugin\PluginHelper as JPluginHelper;
use \Joomla\CMS\Filter\InputFilter as JFilterInput;
 
use \Joomla\CMS\Form\FormField as JFormField;
use \Joomla\CMS\Form\FormHelper as JFormHelper;
//use Joomla\Application

use \Joomla\CMS\Session\Session as JSession;
use \Joomla\CMS\Date\Date as JDate;

defined('_JEXEC') or die;

if(file_exists(JPATH_ROOT . '/administrator/components/com_fields/libraries/fieldsplugin.php')){
	require_once JPATH_ROOT . '/administrator/components/com_fields/libraries/fieldsplugin.php';
}
if(explode('.', PHP_VERSION)[0] < 8){
	require_once __DIR__ . '/lib/helper.php';
}
//JLoader::import('components.com_fields.libraries.fieldslistplugin', JPATH_ADMINISTRATOR);
JLoader::import('fields.sql.sql', JPATH_PLUGINS);
//JLoader::import('components.com_fields.libraries.fieldsplugin', JPATH_ADMINISTRATOR);

JLoader::import('components.com_fields.libraries.fieldsplugin', JPATH_ADMINISTRATOR);
JLoader::import('components.com_fields.libraries.fieldslistplugin', JPATH_ADMINISTRATOR);

JLoader::register('FieldsHelper', JPATH_ADMINISTRATOR . '/components/com_fields/helpers/fields.php');


//$jform = JFactory::getApplication()->input->post->get('jform', array(), 'array');
//$jform = JFactory::getApplication()->input->getArray();
//$jform = JFactory::getApplication()->input->post;
//toPrint($jform, '$jform',0);

//toPrint($_SERVER,'$_SERVER',0);
//toPrint($_ENV,'$_ENV',0);
//toPrint($_POST,'$_POST',0);
//toPrint($_GET,'$_GET',0);
//toPrint($_SERVER,'$_SERVER',0);//jform[params][list_currencies][default_cur][]	JFactory::getApplication()->getInput()->getRaw('jform')
//toPrint(JFactory::getApplication()->getInput());//jform[params][list_currencies][default_cur][]	JFactory::getApplication()->getInput()->getRaw('jform')


/**
 * Fields Sql Plugin
 *
 * @since  3.7.0
 */
class PlgFieldsOrder extends FieldsPlugin  //implements SubscriberInterface //FieldsListPlugin//FieldsPlugin  // PlgFieldsSql Plgfieldscost
{
	public static $X = 0;
	
	public static $ArticlesIdFromOtherField = [];
	
	public static $FieldsContext = [];
	
	public static $FieldsContent = [];
	
	
//	public static $Fields = [];
			
	/**
	 * Constructor
	 *
	 * @param   DispatcherInterface  &$subject  The object to observe
	 * @param   array                $config    An optional associative array of configuration settings.
	 *                                          Recognized key values include 'name', 'group', 'params', 'language'
	 *                                         (this list is not meant to be comprehensive).
	 *
	 * @since   1.5
	 */
	public function __construct(&$subject, $config = array())
	{
//		// Пример данных $config
//		$config = [
//		    [type] => 'fields',
//			[name] => 'order',
//			[params] => {"sendMailUser":"148","sendMailText":"","sendMailGroup":["3","8"]},
//			[id] => 251,
//		];
//toPrint($this->params , '$this->params',0,'message');
//toPrint($this->params , '$this->params',0,'message');
		

//        $field->paramsPlugin = $this->params;
//		static::$DataKostyl[$field->name] = $field; //$field->name, $field->id
//toPrint($config,'PlgFieldsOrder->__construct()',0,'pre');
//echo "<pre>PlgFieldsOrder->__construct()</pre>";
//toPrint(static::$DataKostyl,'Cost->__construct() static::$DataKostyl ',0);
//toPrint(array_keys(get_object_vars($subject)),'Cost->__construct()$subject type:'. get_class($subject).' ',0,'message'); 
		
		parent::__construct($subject, $config);	

		
		
		if(is_null($this->params['sendMailSystem']))
			$this->params['sendMailSystem'] = true;
		
		if(is_null($this->params['sfxTitleOrder']))
			$this->params['sfxTitleOrder'] = ' {phone} {name} {mail} ';
		
		if(is_null($this->params['sendMailGroup']))
			$this->params['sendMailGroup'] = [8];
		
		if(is_null($this->params['workflowstage'])){
			$query = " 
SELECT s.id 
FROM #__workflows w, #__workflow_stages s 
WHERE s.workflow_id = w.id AND w.default AND s.default 
UNION 
SELECT s.id 
FROM #__workflow_stages s 
WHERE s.default 
LIMIT 2; ";
			
			$ids = (explode('.', PHP_VERSION)[0] > 7) ? JFactory::getDbo()->setQuery($query)->loadColumn() : [ 1 ];
			$id = reset($ids);
			$this->params['workflowstage'] = $id ?: 1;
		}
		
//    echo $file."<br>";//149,142,146
//echo "<pre>Order->Constructor() \n ".
//		print_r($this->params ,true). gettype($this->params)."</pre>"; //$this->params

		
		JFactory::getApplication()->getLanguage()->load('plg_fields_order', __DIR__);

		foreach (static::$list_fields as $i => $row_field){
			$row_field['title_field'] = JText::_($row_field['title_field']);
			$row_field['hold_field'] = JText::_($row_field['hold_field']);
			$row_field['alias_field'] = JText::_($row_field['alias_field']);
			static::$list_fields[$i] = (object) $row_field;
		}


	}
	 
	
	/**
	 * @var array
	 */
	public   $fieldnames = [];
	/**
	 * @var array
	 */
	public   $names = [];
	/**
	 * @var array
	 */
//	public   $fields = [];
	
	/**
	 * Default currency
	 * @var stdObject
	 */
	public static $currency = null;
	
	/**
	 * list currencies
	 * @var array
	 */
	public static $currencies = [];
	
	/**
	 * List accounting units.
	 * @var array
	 */
	public static $fileds = [];
	
	/**
	 * Name of the layout being used to render the field
	 *
	 * @var    string
	 * @since  3.5
	 */
	protected $layout = '';

    
	/**
	 *  
	 *
	 * @var    bool
	 * @since  3.2
	 */
	protected $formating = false; 
    
     
	/**
	 * Layout to render the form field
	 *
	 * @var  string
	 */
	protected $renderLayout = 'joomla.form.order';
//	protected $renderLayout = 'joomla.form.renderfield';  
	/**
	 * Layout to render the label
	 *
	 * @var  string
	 */
//	protected $renderLabelLayout = 'joomla.form.renderlabel';
	
	
	
	/**
	 * Возвращает массив событий, которые будет прослушивать этот подписчик.
	 *
	 * @return  array
	 */
	public static function getSubscribedEvents(): array
	{
		return [ 
//			'<EventName>' => 'myFunctionName',
		];
	}
 
	/**
	 * 
	 * @return void
	 */
	public function onBeforeRender()
	{
					
					

//toPrint(array_keys(get_object_vars($item)), $context.'  '.static::$X);
//		$layoutFile = __DIR__.DS.'layouts';
//		JLayoutHelper::render('cost.php','',$layoutFile);
//		JPluginHelper::getLayoutPath('fields', 'cost', 'default');
//toPrint('onBeforeRender');
//toPrint(123,'Context',0);
	}
	
	
	/**
	 * 
	 * @var array
	 */
	public static $DataKostyl = [];
	 
	
	/**
	 * Вызов из класса поля в редакторе Article <b>FieldCost->setup();</b>
	 * @param type $field		- object <b>class FieldCost;</b>
	 * @param type $name		- jform[com_fields][tsena]
	 * @param type $fieldname	- tsena
	 * @param type $type		- cost
	 */
	public function onFieldOrderSendData($FieldOrder,$name,$fieldname,$type) { // Редактор Article
		 
			$this->fields[$fieldname] = $FieldOrder;
			$this->fieldnames[]		  = $FieldOrder->fieldname;
			$this->names[]			  = $FieldOrder->name;
			
//toPrint('PluginField->onFieldCostSendData() FieldCost-> $name:<b>'.$name.'</b> $fieldname:<b>'.$fieldname.'</b>');//tsena		имя
	}
	
	
	
	/**
	 * set object
	 * @param JFormField|Joomla\CMS\Form\FormField $field 
	 * @return FieldsPlugin $this
	 */
	function onFieldOrderGetPlugin($field = null){
		
		if($field){
			$field->plugin = $this;
			$field->paramsPlugin = $this->params;
		}
			
		
		return $this;
	}
	
	/**
	 * Transforms the field into a DOM XML element and appends it as a child on the given parent.
     * 
     * Преобразует поле в XML-элемент DOM и добавляет его в качестве дочернего элемента к указанному родительскому элементу.
	 * 
	 *---------Вызывается в компоненте Fields методом FieldModel::checkDefaultValue()
	 *---------Вызывается в компоненте Fields методом FieldsHelper::prepareForm()
	 * Вызывается при Сохранение и при Применении.
	 *
	 * @param   stdClass    $field   Настройки поля. Поле
	 * @param   DOMElement  $parent  The field node parent.
	 * @param   JForm       $form    The form.
	 *
	 * @return  DOMElement
	 *
	 * @since   3.7.0
	 */
	public function onCustomFieldsPrepareDom($field, DOMElement $parentFieldset, JForm $form)// Редактор Article каждый раз для отдельного любого поля,
	{
		if($field->type != 'order')
			return parent::onCustomFieldsPrepareDom($field,  $parentFieldset,  $form);
//		return parent::onCustomFieldsPrepareDom($field,  $parentFieldset,  $form); 
		//cost_id	product_id	param_id	user_id		type	params	value	amount
//		$query="
//SELECT cost_id, product_id, param_id,user_id,`type`,params,`value`,amount
//FROM `j4_cost` WHERE product_id =  AND 
//			";
		
//		JFactory::getDbo()->setQuery($query)->loadObjectList();
		
		$this->fields[$field->name] = $field;
		$this->names[$field->id] = $field->name;
		
        $field->paramsPlugin = $this->params; 
		$form->FieldOrderParams = $field;
		
		return parent::onCustomFieldsPrepareDom($field,  $parentFieldset,  $form);

			
//		$field->article	= $form->getData();
//		static::$DataKostyl[$field->name] = $field; //$field->name, $field->id
$field; // $field->params - возможно тут должны быть параметры , но они пустые, возможно надо их формировать для загрузки в поле
$field->id		;//(int) ID - поля в материале
$field->value; // JSON - с значениями поля из Article введенными данными
$field->rawvalue; // JSON - с значениями поля из Article введенными данными
$field->default_value;// = '{"product_options":{"name":[""],"options":["0"],"cost":["10"],"quantity":["5"],"account":["1"],"display":["1"]}}'; // пусто, возможно нам надо заполнять значениями по умолчанию.
$field->name; // tsena -  имя поля
$field->type;	// cost - тип поля
$this->_name;	// cost - тип поля

//toPrint($field->id,'$form id ',0,'message');//7		(int) ID - поля в материале
//toPrint($field->type,'$form type ');//tsena		имя
//toPrint($field->name,'$form name ');//tsena		имя
//toPrint($this->_name,'$this name ');//cost		тип
//toPrint($field->type,'$field type ');//cost
//toPrint(array_keys((array)$this),'onCustomFieldsPrepareDom()$field '. get_class($this));
		
//		$field->paramPlugin = $this->params; 
//toPrint(array_keys((array)$field), ++static::$X.'x onCustomFieldsPrepareDom()$field '. get_class($field));
//toPrint($field->fieldparams,'$field->fieldparams '. get_class($field->fieldparams));// Поле   данные
//toPrint($field->params,'$field->params '. get_class($field->params));		//	Материал	JRegistry
//toPrint($this->params,'$this->params '. get_class($this->params));			//	Плагин
//toPrint($field->paramsPlugin,'$field->paramsPlugin '. get_class($field->params));		//	Материал	JRegistry
//toPrint($field,'$field '. get_class($field->params));		//	Материал	JRegistry
		
//toPrint( ( $field->article),'$field->article '. get_class($field->article));
//toPrint('id:'. $field->id.' name:'.$field->name,'$field '. get_class($field));

//toPrint($field->name,'$field name ');// tsena
//		$field2 = $form->getField($field->name);
//toPrint($field2,'$field2 '. empty($field2) ? ' False ' : get_class($field2));
//toPrint($field,'$field '. empty($field) ? ' False ' : get_class($field));
//toPrint($field->default_value,'$field default_value ');// 
//toPrint($field->value,'$field value ');//
//toPrint($field->rawvalue,'$field rawvalue ');//

//toPrint($field->params,'$field->params '. get_class($field->params));		//	Материал	JRegistry
//toPrint($field->fieldparams,'$field->fieldparams '. get_class($field->fieldparams));// Поле
//toPrint(array_keys((array)$this),'$this '. get_class($this->params));			//	Плагин
//toPrint($field,'$field '. get_class($field));			//	Плагин
//toPrint($form,'$form ');//
		
		
		
//		JFactory::getApplication()->getDispatcher()->addSubscriber($subscriber);

		
//		$this->paramsArticle	= $params->params;
//		$this->paramsField		= $params->fieldparams;
//		$this->paramsPlugin		= $params->paramsPlugin;
//		$this->article			= $this->form->getData();
//	public $paramsPlugin = []; 
//	public $paramsField = []; 
//	public $paramsArticle = []; 
//	public $article = [];
		$plugin = $this;
		
		$sendFieldsData = function(JEvent $event)use($field,$form,$plugin){
//toPrint($field->name, 'Cost->onFieldCostSendData()$field->name',0);
//toPrint($event->getArgument('fieldname'), 'Cost->onFieldCostSendData($event->fieldname)',0);
//toPrint($event->getArgument('subject')->fieldname, 'Cost->onFieldCostSendData($event->subject->fieldname)',0);
//toPrint($event, 'Cost->onFieldCostSendData($event)',0);
			if($field->name != $event->getArgument('fieldname'))
				return $field;
			
			$event->setArgument('plugin',$plugin); 
			$FieldCost			= $event->getArgument('subject');// Поле class JFormFieldCost;
			$plugin->fields[$FieldCost->fieldname]			= $FieldCost;
			$plugin->fieldnames[]		= $FieldCost->fieldname;
			$plugin->names[]			= $FieldCost->name;
			
			$event->setArgument('fieldname',	$FieldCost->fieldname);
			$event->setArgument('name',			$FieldCost->name);
			$event->setArgument('paramsPlugin',	$field->paramsPlugin);
			$event->setArgument('paramsArticle',$field->params);
			$event->setArgument('paramsField',	$field->fieldparams);
			$event->setArgument('article',		$form->getData());
//toPrint($field, 'Cost->onFieldCostSendData($field)',0);
			
			
//			$field->name				= $FieldCost->name;
//			$field->fieldname			= $FieldCost->fieldname;
			$FieldCost->paramsPlugin	= $field->paramsPlugin;
			$FieldCost->paramsArticle	= $field->params;
			$FieldCost->paramsField		= $field->fieldparams;
			$FieldCost->fieldId			= $field->id;
			$FieldCost->article			= $form->getData();
			return $field;
		};

		
		if(JVersion::MAJOR_VERSION == 3){
			JFactory::getApplication()->triggerEvent('onFieldOrderSendData', $sendFieldsData);
		}else{
			JFactory::getApplication()->getDispatcher()->addListener('onFieldOrderSendData', $sendFieldsData);
		}
//			JEventDispatcher::getInstance()->trigger('onContentPrepare', $sendFieldsData);
		
//toPrint( 'Cost->onCustomFieldsPrepareDom($field, DOMElement $parentFieldset, JForm $form)','',0,'pre');  //  
		return parent::onCustomFieldsPrepareDom($field,  $parentFieldset,  $form);
		
		
//toPrint($context,'$context #onContentBeforeSave',0);
//		return true;
//            toPrint($this->getOptions(),'$this->getOptions() #Static');
  
				$modules_type = $field->fieldparams->get('modules_type','ids');
//toPrint($modules_type,'$modules_type #onCustomFieldsPrepareDom');
				$field->query = $query = $this->queries[$modules_type];
				$field->key_field = 'id';
				$field->value_field = 'title';
                
//                $field->fieldparams->set('name','modules');
				$field->fieldparams->set('query',$query);
				$field->fieldparams->set('value_field','title');
				$field->fieldparams->set('key_field','id');
//		$field->type = 'sql' ;
		$fieldNode = parent::onCustomFieldsPrepareDom($field, $parentFieldset, $form);
        
		if (!$fieldNode)
		{
			return $fieldNode;
		}
//		$field->type = 'modules' ;
		$fieldNode->setAttribute('type', 'sql'); 
		$fieldNode->setAttribute('query', $query);
		$fieldNode->setAttribute('value_field', 'id');
		$fieldNode->setAttribute('key_field', 'title');

//            toPrint($form,'$form #onCustomFieldsPrepareDom');
//toPrint($field,'$field #onCustomFieldsPrepareDom');
//toPrint($parentFieldset,'$parentFieldset #onCustomFieldsPrepareDom');
//toPrint($fieldNode,'$fieldNode #onCustomFieldsPrepareDom');
                  
		return $fieldNode;
	} 
	 
 	
	
	/**
	 * The form field type.
	 *
	 * @var    string
	 * @since  1.6
	 */
//	public $type = 'Cost';

	 
 

	/**
	 * The save event.
     * 
     * Событие сохранения.
	 *
	 * @param   string   $context  The context
	 * @param   JTable   $item     The table Article
	 * @param   boolean  $isNew    Is new item
	 * @param   array    $data     The validated Article data
	 *
	 * @return  boolean
	 *
	 * @since   3.7.0
	 */
	public function onContentBeforeSave($context, $item, $isNew, $data = []){ // Article* РедакторНаверно вызывается один раз для этого поля, 
	
		return true;
//toPrint(array_keys((array)$item),'Cost->onContentBeforeSave()$context:'.$context.' class:'. get_class($item).'  ',0,'message'); 
//toPrint($data['com_fields'],++static::$X.'x Cost->onContentBeforeSave()$data[com_fields]:'.$context  ,0,'message'); 
		// Only work on new SQL fields
		if ($context != 'com_content.article' || empty($data['com_fields']))//$context != 'com_fields.field'
		{
			return true;
		}
//		if($item->type != 'cost')
//			return parent::onCustomFieldsPrepareDom($field,  $parentFieldset,  $form);

		return true;
	}
     
	/**
	 * Don't allow categories to be deleted if they contain items or subcategories with items
	 *
	 * @param   string  $context  The context for the content passed to the plugin.
	 * @param   object  $data     The data relating to the content that was deleted.
	 *
	 * @return  boolean
	 *
	 * @since   1.6
	 */
	public function onContentBeforeDelete($context, $data)
	{ 
		return true;
	}
	/**
	 * Smart Search after delete content method.
	 * Content is passed by reference, but after the deletion.
	 *
	 * @param   string  $context  The context of the content passed to the plugin (added in 1.6).
	 * @param   object  $article  A JTableContent object.
	 *
	 * @return  void
	 *
	 * @since   2.5
	 */
	public function onContentAfterDelete($context, $article): void
	{
//		PluginHelper::importPlugin('finder');
//
//		// Trigger the onFinderAfterDelete event.
//		Factory::getApplication()->triggerEvent('onFinderAfterDelete', array($context, $article));
	}
    
	/**
	 * Don't allow workflows/stages to be deleted if they contain items
	 *
	 * @param   string  $context  The context for the content passed to the plugin.
	 * @param   object  $pks      The IDs of the records which will be changed.
	 * @param   object  $value    The new state.
	 *
	 * @return  boolean
	 *
	 * @since   4.0.0
	 */
	public function onContentBeforeChangeState($context, $pks, $value)
	{
		return true;
	}
	/**
	 * Smart Search content state change method.
	 * Method to update the link information for items that have been changed
	 * from outside the edit screen. This is fired when the item is published,
	 * unpublished, archived, or unarchived from the list view.
	 *
	 * @param   string   $context  The context for the content passed to the plugin.
	 * @param   array    $pks      A list of primary key ids of the content that has changed state.
	 * @param   integer  $value    The value of the state that the content has been changed to.
	 *
	 * @return  void
	 *
	 * @since   2.5
	 */
	public function onContentChangeState($context, $pks, $value)
	{
//		PluginHelper::importPlugin('finder');
//
//		// Trigger the onFinderChangeState event.
//		Factory::getApplication()->triggerEvent('onFinderChangeState', array($context, $pks, $value));
	}
	
    /**
     * List queries db for all types lists.
     * @var array 
     */
//    protected $queries = [
//        'ids' => "
//SELECT  CONCAT(id ,': ',title,' :/',module,'/',position,'') title,
//     id  /*id, title, position, module, client_id ,*/
//FROM #__modules 
//WHERE client_id = 0
//ORDER BY position, module, id ; ",
//        
//        'pos' => "
//SELECT position id, CONCAT(position,' |', GROUP_CONCAT(`title` SEPARATOR ', ')) as title 
//FROM (
//SELECT  position,  CONCAT(id ,':/',title,' /',module) title,
//     id  /*id, title, position, module, client_id ,*/ 
//FROM #__modules  
//WHERE client_id = 0 AND position!=''
//ORDER BY position, module, id -- published, showtitle, params, ordering 
//) t 
//GROUP BY position ORDER BY position ; "];
    


    
    /**
     * Get modules List or positions list
     * Получить список модулей или список позиций
     * @param string $type
     * @return array
         */
    public function getModules($type = 'ids') {
//toPrint($type,'$type ',0,true,true);
        if (!isset($this->queries[$type])) {
            return [];
        }
 

//            $items = JFactory::getDbo()->setQuery($query)->loadObjectlist('id'); 
        $items = JFactory::getDbo()->setQuery($this->queries[$type])->loadAssocList('id', 'title');
//toPrint(array_keys($items),'$modles_ids ',0,true,true);
        
        return $items;
    }
    
    
	/**
	 * The form event. Load additional parameters when available into the field form.
	 * Only when the type of the form is of interest.
     * 
     * Событие формы.  Загрузите дополнительные параметры, когда они доступны, в форму поля. 
     * Только когда интересует тип формы. 
	 *
	 * @param   JForm     $form  The form
	 * @param   stdClass  $data  The data
	 *
	 * @return  bool
	 *
	 * @since   3.7.0
	 */
	public function onContentPrepareForm(JForm $form, $data){ //Редактор Field
//toPrint( 'Cost->onContentPrepareForm()','',0,'message'); 
//toPrint(123,'$this #onContentPrepareForm');
        return parent::onContentPrepareForm( $form, $data);
    } 
	/**
	 * Вызывается после получения данных для JForm. Его можно использовать для изменения данных объекта JForm в памяти перед рендерингом.
	 * Обычно это используется в тандеме с методом onContentPrepareForm - это событие добавляет данные в уже измененную JForm.
	 * Этот метод вызывается всякий раз, когда Joomla готовит данные для формы XML для отображения.
	 * Add the SocialLogin custom user profile field data to the core Joomla user profile data. This is required to
	 * populate the "sociallogin.dontremind" field with its current value.
	 * 
	 * @param	string|null	$context  Контекст для данных (название формы)(например,. com_content.article)  
	 * @param   array|object|null  $data    Объект или массив, содержащий данные для формы.
	 * 
	 *
	 * @return  bool
	 */
	public function onContentPrepareData(?string $context, &$data){ //Редактор Field
        return true;
    } 
	
	/**
	 * Plugin that shows a custom field
	 *
	 * @param   string  $context  The context of the content being passed to the plugin.
	 * @param   object  &$item    The item object.  Note $article->text is also available
	 * @param   object  &$params  The article params
	 * @param   int     $page     The 'page' number
	 *
	 * @return void
	 *
	 * @since 
	 */
	public function onContentPrepare($context, &$item, &$params, $page = 0){//Клиент- категория, 
//toPrint($context,'',0,'pre');
//		if(in_array($context, ['com_content.categories','','','',]) == false) //com_content.category , com_content.article ,com_content.category 
//			return;
//		
//		
//		
//		
//		foreach ($item->jcfields as $field){
//			if($field->type != 'order')
//				continue;
//			
//			$key = $context.'_'.$item->id.'_'.$field->id;
//			
//			$item->text = static::$FieldsContent[$context][$field->id][$item->id];
//			$item->description = static::$FieldsContent[$context][$field->id][$item->id];
//		}
		
//		$item->text = 'Text<br>';
//		$item->description = 'Description<br>';
		
//		static::$fileds[$field->id] = $field;
		
//toPrint(array_keys(get_object_vars($item)), $context.'  '.static::$X);
//toPrint(array_keys(($item->jcfields)), $context.'  '.static::$X);
//toPrint(($item->jcfields[11]), $context.'  '.static::$X);
//toPrint(array_keys((array)$field),  static::$X.' name:'.$field->name.' type:'.$field->type.' class:'. get_class($field));
	}
	/**
	 * The display event.
	 *
	 * @param   string    $context     The context
	 * @param   stdClass  $item        The item
	 * @param   Registry  $params      The params
	 * @param   integer   $limitstart  The start
	 *
	 * @return  string
	 *
	 * @since   3.7.0
	 */
	public function onContentAfterTitle($context, $item, $params, $limitstart = 0)
	{
		return '';
	}

	
	/**
	 * If in the article view and the parameter is enabled shows the page navigation
	 *
	 * @param   string   $context  The context of the content being passed to the plugin
	 * @param   object   &$item     The article/category object
	 * @param   mixed    &$params  The article params ItemMenu||Component
	 * @param   integer  $page     The 'page' number
	 *
	 * @return  mixed  void or true
	 *
	 * @since   1.6
	 */
	public function onContentBeforeDisplay($context, &$item, &$params, $page = 0) 
	{
//		return ;
		if(in_array($context, ['_com_content.categories','com_content.article','','',]) == false) //com_content.categories , com_content.article ,com_content.category 
			return;
		
		
//toPrint(array_keys(($item->jcfields)), $context.'  '.static::$X);
//toPrint(($item->jcfields[11]), $context.'  '.static::$X);
//toPrint(array_keys((array)$field),  static::$X.' name:'.$field->name.' type:'.$field->type.' class:'. get_class($field));
//		return;
		$return = '';
		
		foreach ($item->jcfields as $field){
			if($field->type != 'order')
				continue;
			
//			$key = $context.'_'.$item->id.'_'.$field->id;
			
			if(isset(static::$FieldsContent[$context][$field->id][$item->id])){
//				$return .= "Return:".static::$FieldsContent[$context][$field->id][$item->id];
				$item->text .= static::$FieldsContent[$context][$field->id][$item->id];
			}
//			$item->description = static::$FieldsContent[$context][$field->id][$item->id];
//			$item->introtext = static::$FieldsContent[$context][$field->id][$item->id]; //introtext fulltext  text
		}
		
		
//toPrint($context,'',0,'message');

//toPrint('<br>'.$row->id.'-'.$row->title,'onContentBeforeDisplay():$context:'.$context,0);
//toPrint(array_keys(get_object_vars($row)),'onContentBeforeDisplay():$context:'.$context,0);
		
		
//		return  $return;  
//		return "<h3>onContentBeforeDisplay()</h3><br>".$return; // MainMenuItem, MainPage, , Article:3 раза вызов
	}

	
	
	/**
	 * Displays the voting area when viewing an article and the voting section is displayed after the article
	 *
	 * @param   string   $context  The context of the content being passed to the plugin
	 * @param   object   &$item     The article object
	 * @param   object   &$params  The article params
	 * @param   integer  $page     The 'page' number
	 *
	 * @return  string|boolean  HTML string containing code for the votes if in com_content else boolean false
	 *
	 * @since   3.7.0
	 */
	public function onContentAfterDisplay($context, &$item, &$params, $page = 0)
	{
		
		if(in_array($context, ['com_content.categories','_com_content.article','','',]) == false) //com_content.category , com_content.article ,com_content.category 
			return;
		
		
//toPrint(array_keys(($item->jcfields)), $context.'  '.static::$X);
//toPrint(array_keys(get_object_vars($item)), $context.'  '.static::$X);
//toPrint(array_keys(($item->jcfields)), $context.'  '.static::$X);
//toPrint(($item->jcfields[11]), $context.'  '.static::$X);
//toPrint(array_keys((array)$field),  static::$X.' name:'.$field->name.' type:'.$field->type.' class:'. get_class($field));
//		return;
		$return = '';
		
		foreach ($item->jcfields as $field){
			if($field->type != 'order')
				continue;
			
//toPrint(array_keys(get_object_vars($field)), $context."    \$item->id:$item->id    \$field->context:$field->context   \$field->id:$field->id ".static::$X);
//			$field->context;
//			$field->id;
//			$field->context;
//			$field->context;


//			$key = $context.'_'.$item->id.'_'.$field->id;
			if(isset(static::$FieldsContent[$context][$field->id][$item->id])){
				$return .= static::$FieldsContent[$context][$field->id][$item->id];
				$item->text .= static::$FieldsContent[$context][$field->id][$item->id];
			}
//			$item->description .= static::$FieldsContent[$context][$field->id][$item->id];
//			$item->introtext .= static::$FieldsContent[$context][$field->id][$item->id]; //introtext fulltext  text
		}
//com_content.article , com_content.categories, com_content.category, 
//toPrint($context,'onContentAfterDisplay():$context');
//toPrint(array_keys(get_object_vars($row)),'onContentAfterDisplay():$context:'.$context,0);

		return  $return;
//		return "<h3>onContentAfterDisplay()</h3><br>".$return; // MainMenuItem,  MainPage, Category, Article/1
	}
	
	
	public function onContentAfterItems($context, $item, $params) : string{
		return "";
	}
	
	/**
	 * Returns the custom fields types.
	 * Trigger the event to create the field dom node
     * 
     * Возвращает типы настраиваемых полей.
	 *---------Вызывается в компоненте Fields методом FieldsHelper::getFieldTypes()
	 *
	 * @return  string[][]
	 *
	 * @since   3.7.0
	 */
	public function onCustomFieldsGetTypes() // Клиент Материал и материалы Категории и Редактор Field, Редактор Article, 
	{ 
//toPrint(123,'No:' ,0,'pre');
        $types =  parent::onCustomFieldsGetTypes(); 
			
//toPrint( 'Cost->onCustomFieldsGetTypes()','',0,'pre');

//            $types[] = ['type'=>'sql','label'=>'SQL'];
//            unset($types[0]);
//toPrint($types,'$types #onCustomFieldsGetTypes',0);
//toPrint($this,'$this #onCustomFieldsGetTypes');
        return $types;
	}
    
	/**
	 * Returns the path of the XML definition file for the field parameters
	 * 
	 * Возвращает путь к файлу определения XML для параметров поля
	 *
	 * @param   Form      $form  The form
	 * @param   stdClass  $data  The data
	 *
	 * @return  string
	 *
	 * @since   4.0.0
	 */
	protected function getFormPath(JForm $form, $data){ // Вызов в Field
//toPrint( 'Cost->getFormPath()','',0,'message');   
		return parent::getFormPath($form, $data);
	}
    
 
 
	/*
	 * On before field prepare
	 * Event allow plugins to modify the output of the field before it is prepared
	 * Before prepares the field value.
	 * 
	 * Перед подготовкой поля
	 * Событие позволяет плагинам изменять вывод поля до того, как оно будет подготовлено
	 * Перед подготовкой значения поля. 
	 *---------Вызывается в компоненте Fields методом FieldsHelper::getFields() Сколько угодно раз (больше чем количество полей) 2 раз на поле, 
	 * -------- возможно подправят баг в Гитхаб, вызывается 1 при рендеринге и 1 просто так. В будущем будет вызыватся 1 раз
	 *
	 * @param   string     $context  The context.
	 * @param   \stdclass  $item     The item. Статья
	 * @param   \stdclass  $field    The field.
	 * 
	 *
	 * @return  void
	 *
	 * @since   3.7.0
	 */
	public function onCustomFieldsBeforePrepareField($context, $item, $field){// Статья и статьи в Категории клиента
		
		if($field->type != 'order') // && in_array($field->id, static::$FieldsId) == false
			return;
		
//toPrint($context,'Type :'.$field->type,0,'pre');

		
//		$field = new JFormField;
//		$field->render($context);
		
//		static $count;
//		if(is_null($count))
//			$count = 0;
//		
//		$count += 1;
//toPrint( 'Cost->onCustomFieldsBeforePrepareField('.$count.')','',0,'pre'); 
	}
	
	
	/**
	 * Prepares the field value.
	 * Gathering the value for the field
     * 
     * Готовит значение поля.
	 * Сбор значения для поля
	 *---------Вызывается в компоненте Fields методом FieldsHelper::getFields()
	 *
	 * @param   string    $context  The context.
	 * @param   stdclass  $item     The item. Статья
	 * @param   stdclass  $field    The field.
	 *
	 * @return  string
	 *
	 * @since   3.7.0
	 */
    public function onCustomFieldsPrepareField($context, $item, $field){// Статья клиента и статьи в категории
		
//return '';
//$item->id, title, alias, introtext, fulltext, checked_out, checked_out_time, catid, created, created_by, created_by_alias, modified, modified_by, publish_up, publish_down, images, urls, attribs, metadata, metakey, metadesc, access, hits, featured, language, readmore, ordering, featured_up, featured_down, state, category_title, category_route, category_access, category_alias, category_language, published, parents_published, lft, author, author_email, modified_by_name, parent_title, parent_id, parent_route, parent_alias, parent_language, alternative_readmore, layout, params, displayDate, slug, event, text, jcfields				
		
//		if($field->type!='order')
//			return parent::onCustomFieldsPrepareField($context, $item, $field);
//		static $counter;
//		if(is_null($counter))
//			$counter = 0;
//		Factory::getApplication()->enqueueMessage('Counter Rendering field:'.$field->type.'  counter:'.++$counter );	
		
//toPrint($context);
//toPrint( $field->type,'PlgFieldsOrder->onCustomFieldsPrepareField()',0,'pre');
		if($field->type != 'order'){
			static::$ArticlesIdFromOtherField[$context][] = $item->id;
			
			return parent::onCustomFieldsPrepareField($context, $item, $field);
		}
		
		
//		if(in_array($context, ['com_content.article','com_content.categories','','','',]) == false)
//			return $context;
//		else
//toPrint(array_keys(get_object_vars($item)));
		
//		if(empty(JSession::checkToken()))
//			return parent::onCustomFieldsPrepareField($context, $item, $field);
		
//		if(isset(static::$FieldsId[$field->id]) == false){
//			static::$FieldsId[$field->id] = 0;
//		} 
//		if(isset(static::$FieldsId[$field->id]) && static::$FieldsId[$field->id] > 0) {// end(static::$FieldsId) ==  $field->id
////toPrint(static::$FieldsId,'Yes',0,'pre');
////echo "<pre>Yes:".print_r(static::$FieldsId,true)."</pre>";
//			return '';		
//		}  
//		static::$FieldsId[$field->id] += 1;
		
//toPrint(static::$FieldsId[$field->id],'No:'.$field->id,0,'pre');
		
		
//toPrint(static::$FieldsId,'No:'.$field->id,0,'pre');
		
//		if(isset(static::$FieldsId[$field->id]))
//			static::$FieldsId[$field->id] -= 1;
		
//toPrint(  ++static::$X,' name:'.$field->name.' type:'.$field->type.' class:'. get_class($field));
//echo "<pre>No:".print_r(static::$FieldsId,true)."</pre>";

					
		
		
		
		
//		$key = $context.'_'.$item->id.'_'.$field->id;
		
		if(isset(static::$FieldsContent[$context][$field->id][$item->id]) == false)
			static::$FieldsContent[$context][$field->id][$item->id] = $this->performer($context, $item, $field);
		
		
		
		
		if(isset(static::$FieldsContext[$context][$field->id][$item->id]) == false){
			static::$FieldsContext[$context][$field->id][$item->id] = $field;
		}
		
		
		return '';
		
		
//toPrint(array_keys(static::$FieldsContext[$field->id]),' artId:'.$item->id.' fieldId:'.$field->id);
		$articleIdLast = end(array_keys(static::$FieldsContext[$context][$field->id]));
		foreach (static::$FieldsContext[$context][$field->id] as $artId => $fld){
			//as $artId => &$field
//			if($articleIdLast != $artId)
				static::$FieldsContext[$context][$fld->id][$artId]->value= '';
			
//toPrint($item->title." $context <br> artId:".$item->id.' fieldId:'.$field->id." DELETEvalue:(\$articleIdLast $articleIdLast != \$artId $artId)".($articleIdLast != $artId?'True':'False').' Length:'. strlen(static::$FieldsContext[$context][$fld->id][$artId]->value));
		}
		 
		
//		if(in_array($context, ['com_content.article','com_content.categories','','','',]) == false)
//			return;
		if(in_array($context, ['Xcom_content.article','com_content.categories','','','',]) ){ //&& isset(static::$ArticlesIdFromOtherField[$context]) && end(static::$ArticlesIdFromOtherField[$context]) == $item->id
//			toPrint($item->title.'<br> artId:'.$item->id.' fieldId:'.$field->id." DELETEvalue:(\$articleIdLast $articleIdLast != \$artId $artId)".($articleIdLast != $artId?'True':'False').' Length:'. strlen(static::$FieldsContext[$fld->id][$artId]->value));
			return static::$FieldsContent[$context][$field->id][$item->id];			
		}
		else
			return '';
		
		
		
//		return $this->performer($context, $item, $field); //'com_content.article','com_content.categories'
	}
	
	/**
	 * Обрабатывает полученные данные из формы, потом отправляет на сохранение и отправляет на отправку по почте.
	 * @staticvar type $count
	 * @param string $context
	 * @param object $item
	 * @param object $field
	 * @return string
	 */
    public function performer($context, $item, $field){// Статья клиента
//		$field->paramField = 
//		return '';
		
//		static $count;
//		if(is_null($count))
//			$count = 0; 
//		$count += 1;
		
//toPrint ("order[$item->id][$field->id][url] Count:".$count,'order[$item->id][$field->id][url] $count:'.$count,0,'message');
		++static::$X;
//		\Joomla\String\StringHelper::compliant($str);
		
		
		$urlForm = '';
		
		$input = JFactory::getApplication()->input->post; // getInput()->post;
//		$inputFilter = $input->get($urlForm, $inputFilter, $context);

//		$dataInput = $input->getArray();//['order'][$item->id][$field->id]['url']
//		if(isset($dataInput['order'][$item->id][$field->id]['url']))
//			$urlForm = 
//toPrint ($dataInput,'$urlForm');
//toPrint ($field,'$field',0,true);
		
		
//		order[$item->id][$field->id][done]
		//Проверка: наличия ссылки и название материла!
//		echo   '<br>Вывод  из папки '.__FILE__;
		$inputOrder = $input->getRaw('order');
		$paramFormOrderAbout = [];
		
		if(isset($inputOrder[$item->id][$field->id]['url']) && $inputOrder[$item->id][$field->id]['url']
		&& isset($inputOrder[$item->id][$field->id]['title']) && $inputOrder[$item->id][$field->id]['title']
		&& isset($inputOrder[$item->id][$field->id]['done']) && $inputOrder[$item->id][$field->id]['done']){
			$paramFormOrderAbout['url']   = JFilterInput::getInstance([], [], 1, 1)->clean($inputOrder[$item->id][$field->id]['url'],   'STRING');
			$paramFormOrderAbout['title'] = JFilterInput::getInstance([], [], 1, 1)->clean($inputOrder[$item->id][$field->id]['title'], 'STRING');
			$paramFormOrderAbout['done']  = JFilterInput::getInstance([], [], 1, 1)->clean($inputOrder[$item->id][$field->id]['done'],  'STRING');
		}else{
			return parent::onCustomFieldsPrepareField($context, $item, $field);
		}
		

		if(in_array('', $paramFormOrderAbout))
			return parent::onCustomFieldsPrepareField($context, $item, $field);
		
//echo "<pre>".print_r($input->getRaw('order'),true)."</pre>";
//		if($input->getArray(['order'=>'']))
//			return FALSE;
		
//		return null;
		 
		//Вынимаем контактные поля из формы и фильтруем с фильтром STRING
		$arr = ['order'=>[$item->id=>[$field->id=>'string']]];// cmd string raw
		$dataFormOrder = $input->getArray($arr);
		$dataFormOrder = $dataFormOrder['order'][$item->id][$field->id] ?? [];
//toPrint ($arr,'$urlForm2',0,'pre',true);

		$subFields = $field->fieldparams['subFields']->idField;
		
		//$currentTitle	= JFilterInput::getInstance([], [], 1, 1)->clean($input->get('title','','STRING'), 'STRING');

//toPrint ($dataFormOrder,'$dataFormOrder',0);
//toPrint ($input->getArray(),'cost',0);
//		if($urlForm)
//toPrint ($urlForm,'$urlForm');
//toPrint ($field->params,'$urlForm');
//toPrint ($this->params,'$this->params');
//toPrint ($field->fieldparams,'$field->fieldparams'); //?
//toPrint ($field,'$field'); //? $field->state, 
//toPrint ($fieldsInput,'$fieldsInput',0); //?
		
		//Приведение объектов к масиву после дисериализации
		$field->fieldparams['list_fields']->type_field = (array)($field->fieldparams['list_fields']->type_field ?? '');
		$field->fieldparams['list_fields']->alias_field = (array)($field->fieldparams['list_fields']->alias_field ?? '');
		$field->fieldparams['list_fields']->title_field = (array)($field->fieldparams['list_fields']->title_field  ?? '');
		$field->fieldparams['list_fields']->require_field = (array)($field->fieldparams['list_fields']->require_field ?? ''); 
		
//		$notFilled = false;
//		
		//Проверка: Заполнения обязательных полей
		//Создание массива значений контактов введенных пользователем (ключь nameField)
		//Создание массива наименований полей контактов (ключь nameField)
		$valuesOrder = $paramFormOrderAbout; // Присвоение массиву с конатктными данными массива со ссылкой и названием материала
		$titles = ['url'=>JText::_('PLG_ORDER_PARAM_URL'), 'title'=>JText::_('PLG_ORDER_PARAM_TITLE')];
		$fieldsAliasNotFilled = [];
		foreach($field->fieldparams['list_fields']->type_field as $iRow => $type_field){//$require_field $alias_require
			
			$alias = $field->fieldparams['list_fields']->alias_field[(int)$iRow] ?: $iRow;
			
			$valuesOrder[$alias] = trim($dataFormOrder[$alias] ?? '');
			
			$titles[$alias] = trim($field->fieldparams['list_fields']->title_field[(int)$iRow] ?? '');
			
			$require = $field->fieldparams['list_fields']->require_field[(int)$iRow] ?? false;
			
			if($require && empty($valuesOrder[$alias])){
//				$notFilled = true;
				$fieldsAliasNotFilled[$alias] = $field->fieldparams['list_fields']->title_field[(int)$iRow] ?: '';
			}
		}//-----------
		
		if($field->fieldparams['check_gdpr'] && (empty($dataFormOrder['gdpr']) || $dataFormOrder['gdpr'] !='ok'))
			$fieldsAliasNotFilled['gdpr'] = JText::_('GDPR');
		
		$html = '';
		$dataFormCost = [];
 	
		if($context=='com_content.article'){
			$dataFormCost = $input->getArray(['cost'=>[$item->id=>'array']]);
//			$dataFormCost = $dataFormCost['cost'][$item->id] ?? [];	
			$dataFormCost = $dataFormCost['cost'] ?? [];
		}
		if($context=='com_content.categories'){
			
			$query = "SELECT id, 'array' FROM #__content   WHERE catid = $item->id;";
//			$itemsId = JFactory::getApplication()->getDbo()->setQuery($query)->loadAssocList('id', 'array');
			$itemsId = JFactory::getDbo()->setQuery($query)->loadAssocList('id', 'array');
			
//toPrint(['cost' => $itemsId], "$context  \$costList  fieldId:$field->id   ", 0);
			$dataFormCost = $input->getArray(['cost' => $itemsId]);
//			$dataFormCost = $dataFormCost['cost'][$item->id] ?? [];
			$dataFormCost = $dataFormCost['cost'] ?? [];
//toPrint($dataFormCost, "$context  \$costList  fieldId:$field->id   ", 0);
		}
		
		
		//Переменная контактов для Передачи значений пользователя в макет
		$field->valuesOrder = $valuesOrder;
//		$field->valuesCost = $dataFormCost;
		
		//Вывод печать ошибки: Не заполненых полей
		if($fieldsAliasNotFilled){
			$flds = implode(', ', $fieldsAliasNotFilled);
			if($field->fieldparams['messageNotFilledId'])
				$html .= JControllerLegacy::getInstance('Content')->getModel('Article')->getItem($field->fieldparams['messageNotFilled'])->introtext; //'introtext', 'fulltext'
			else 
				$html .= $field->fieldparams['messageNotFilled'];			
			$html = str_replace(['{fields}','{FIELDS}'], $flds, $html) . ' ';			
			return $html . parent::onCustomFieldsPrepareField($context, $item, $field) ;
		}//-----------
		
//toPrint($input->get('cost'), "$context  \$costList  fieldId:$field->id   ", 0);
//toPrint($dataFormCost, "$context  \$costList  fieldId:$field->id   ", 0);
		
		$cost_summ = 0;
//		$cost_select = [];
		$costList = [];
		
		$arrayListObjects = [];
		
		$verifyForm = true;
		
		foreach ($dataFormCost as $idArticle => $dataFormArticle){
			$_arrayListObjects = [];
			
			if(JVersion::MAJOR_VERSION == 3){
				$_arrayListObjects = JFactory::getApplication()->triggerEvent('onFieldCostComputeData',  [$context, $idArticle, $field->id, &$cost_summ, $dataFormArticle]);
			}else{
				$_arrayListObjects = JFactory::getApplication()->getDispatcher()->addListener('onFieldCostComputeData',  [$context, $idArticle, $field->id, &$cost_summ, $dataFormArticle]);
			}
			
//			$_arrayListObjects = JFactory::getApplication()->triggerEvent('onFieldCostComputeData', [$context, $idArticle, $field->id, &$cost_summ, $dataFormArticle]);//, &$costList
			
//toPrint($cost_summ);
			foreach ($_arrayListObjects as $__arrayListObjects){
				
				if($verifyForm)// Проверка Массива
					$verifyForm = is_array($__arrayListObjects);
								
				if($verifyForm)// Проверка Массива
					$verifyForm = (in_array(false, $__arrayListObjects)) == false;
				
				if($verifyForm == false){
					Factory::getApplication()->enqueueMessage("Error Requaire Form: cost, $context, $idArticle, $field->id,");
					continue;
				}
				
				$costList = array_merge($costList, $__arrayListObjects);
			}
			
					
		}
//		$costList = array_merge(...$arrayListObjects);
		
		
		
//toPrint($costList, "<h4>$context  \$costList  fieldId:$field->id  CostSumm: <b>$cost_summ</b></h3>", 0);
//		foreach ($arrayListObject as $_list){
//		}
		
//toPrint($costs,'$costs',0);
//toPrint($fieldValues,'$fieldValues',0);
		

		
		
//		$field->fieldparams;// Registry - Настройки поля
//		$this->params;		// Registry - Настройки поля, не все полезные параметры.
//		$field->params;		// Registry - ?Настройки материала их нет
//		$field->paramPlugin = $this->params;
////		$field->type ='';			// Отключает поле 
//		$field->fieldparams->get('saveCategory');		// Категория для сохранения заявок
//		$field->fieldparams->get('captcha');			// 
//		$field->fieldparams->get('messageDoneId');		// 
//		$field->fieldparams->get('messageDone');		// 
//		$field->fieldparams->get('messageNotFilledId');	// 
//		$field->fieldparams->get('messageNotFilled');	// 
//		$field->fieldparams->get('messageErrorId');		// 
//		$field->fieldparams->get('messageError');		// 
//		$field->fieldparams->get('check_gdpr');			// 
//		$field->fieldparams->get('text_gdpr');			// 
//		$field->fieldparams->get('buttonTitle');		// 
		
		
		//return parent::onCustomFieldsPrepareField($context, $item, $field);
		
		
		
//		if($costs){
//			$fieldIds = implode(',', array_column($costs, 'field_id', 'field_id'));
//			$query = "SELECT `field_id`, `value` /* ,`item_id` */
//				  FROM `#__fields_values` WHERE `item_id` = $item->id AND field_id IN ($fieldIds) ORDER BY  field_id; ";
//			$fieldValues = JFactory::getDbo()->setQuery($query)->loadObjectList();
////toPrint($query); 
//			foreach ($fieldValues as &$value){
//				$value->value = json_decode($value->value);
//				if(is_array($value->value)){
//					foreach ($value->value as $optionField){
//						foreach ($optionField->value as $table){
//							
//						}
//					}
//				}
//			}
//toPrint($fieldValues);
//		} 
		
		$sfxTitle = static::formatingTitle($valuesOrder, $this->params['sfxTitleOrder']);
		
//toPrint($sfxTitle);
		$articleText = '';
		
		$article = null;
		
		$item_id_order = 0;
		
		if($field->fieldparams->get('saveCategory')){
			$article = $this->createArticle($field->fieldparams->get('saveCategory'));
			$item_id_order = $article->id ?? 0;
			$valuesOrder['orderId'] = $article->id;
			$titles['orderId'] = JText::_('PLG_ORDER_PARAM_ORDER');
//toPrint($sfxTitle," $article->id ");
//toPrint(array_keys(get_class_vars($article))," $article->id ");
		}
		
		$articleText .= $this->renderCostsValues($costList, $cost_summ, $item_id_order);
		$articleText .= $this->renderOrderValues($valuesOrder, $titles);
		
		if($field->fieldparams->get('saveCategory') && $article && $article->id){
			$item_id_order = $this->saveArticle($article, $articleText, $sfxTitle);
		}
		
		if($field->fieldparams->get('sendMail'))
			$this->sendMail($articleText, ($item_id_order?:'') . $sfxTitle, $valuesOrder);
		

//toPrint($field->value,'field->value');
		
		
		if(JFactory::getConfig()->get('debug'))
			return parent::onCustomFieldsPrepareField($context, $item, $field) ;
		
//		$field->type = '';
//		$field->value = '123123123123123123123123123123123123123123123123123123123123123123123123123123';
//		$field->rawvalue = '123123123123123123123123123123123123123123123123123123123123123123123123123123';
//		$field->state = 0;
		
		
		return  ''; // $count;// parent::onCustomFieldsPrepareField($context, $item, $field);
		
//toPrint($this->params,'plg');
//toPrint($this->params->get('usergroup'),'plgUserGroup');
//toPrint($this->params->get('modifiedX'),'plgModifiedX');
		
//		
//		samsung SM-g260f 
//		android 8.1.0
//		$u = new \Joomla\CMS\User\UserFactory($db);
		
		$costs;
		
		
		if($field->fieldparams['messageDoneId'])
			$html .= JControllerLegacy::getInstance('Content')->getModel('Article')->getItem($field->fieldparams['messageDoneId'])->introtext;//'introtext', 'fulltext'
		else 
			$html .= $field->fieldparams['messageDone'];
		
		JFactory::getApplication()->enqueueMessage($html);
				
		if(empty(JFactory::getConfig()->get('debug')))
			$field->type = '';
		
		$html .= parent::onCustomFieldsPrepareField($context, $item, $field);
		
//		$field->type = ''; 
		$html .= 'Не фига!';
		
		return $html;
		
		$articleDoneId = $field->fieldparams['messageDone'] ?: $field->fieldparams['messageDone2'];
//		$article = JControllerLegacy::getInstance('Content')->getModel('Article')->getItem($articleDoneId);
//		echo $article->introtext;
		
		
//toPrint(array_keys((array)$field), ++static::$X.' name:'.$field->name.' type:'.$field->type.' class:'. get_class($field));
//toPrint(array_keys((array)$this),static::$X.' $item '. get_class($this));
//toPrint(array_keys((array)$item),static::$X.' $item '. get_class($item));
//toPrint($field->fieldparams,'$field->fieldparams '. get_class($field->fieldparams));// Поле
//toPrint($field->params,'$field->params '. get_class($field->params));		//	Материал	JRegistry
//toPrint($this->params,'$this->params '. get_class($this->params));			//	Плагин
//toPrint($field->value,'$field->value '. gettype ($field->value));			//	Значение
		return ' ===================================================== ';
		return parent::onCustomFieldsPrepareField($context, $item, $field);
//		$value = [];
		
		if(is_string($field->value))
			$field->value = json_decode($field->value);
//		if(is_object($field->value))
//			$value = (array)$field->value;
//toPrint($field->value,'$field->value '. gettype ($field->value));			//	Значение
		
		
//toPrint($context,'$context #onCustomFieldsPrepareField',0);
//$ignore = array('GLOBALS', '_FILES', '_COOKIE', '_POST', '_GET', '_SERVER', '_ENV', 'ignore');
//$vars = array_diff_key(get_defined_vars() + array_flip($ignore), array_flip($ignore));
//toPrint(array_keys($vars),'$this'); 
//toPrint(array_keys(get_object_vars($this->_subject)),'$this->_subject'); 
//toPrint($this->queries,'queries #onCustomFieldsPrepareField');


//toPrint(parent::onCustomFieldsPrepareField($context, $item, $field),'$this #onCustomFieldsPrepareField',0);
        return parent::onCustomFieldsPrepareField($context, $item, $field) ;
    }
	
	
//	public function onCustomFieldsBeforeDisplay($context, $item, &$field, $displayType, &$params){
//	}
//	public function onCustomFieldsContentPrepare($context, $item, &$fields){
//	}
	
	/**
	 * 
	 * On after field render
	 * Event allows plugins to modify the output of the prepared field 
	 * 
	 * После рендеринга поля
	 * Событие позволяет плагинам изменять вывод подготовленного поля. 
	 * 
	 *  Вызывается сколько угодно раз (больше чем количество полей) (окого 2х раз для каждого поля) !!! 
	 *  Подправят баг в Гитхаб, вызывается 1раз при рендере и 1 раз просто так.
	 * 
	 * @param type $context
	 * @param type $item
	 * @param type $field
	 * @param type $value
	 * 
	 * @return void
	 */
	public function onCustomFieldsAfterPrepareField($context, $item, $field, &$value) { // Клиент: Статья и в статьях Категории.
		//Все артикли занулить
		//
		
		if($field->type != 'order')
			return  ;
		
//		if(empty(JSession::checkToken()))
//			return parent::onCustomFieldsPrepareField($context, $item, $field);
		
//		if(in_array($context, ['com_content.article','com_content.categories','','','',]) == false)
//			return;
		
		
//		if(isset(static::$FieldsContext[$field->id][$item->id]) == false){
//			static::$FieldsContext[$field->id][$item->id] = $field;
//		}
//		
//		foreach (static::$FieldsContext as $fieldId => &$fieldDataArticles){
//			$artDataLastValue = '';
//			$artFieldLast = null;
//			
//			foreach ($fieldDataArticles as $artId => &$field){
//				$artDataLastValue = &$field->value;
//				$artFieldLast = &$field;
//				$field->value = '';
//			}
//			$artFieldLast->value = $artDataLastValue;
//		} 
//		$value = static::$FieldsContext[$field->id][$item->id]->value;
		
		
//toPrint($context,'onContentBeforeDisplay():$context');
//toPrint($context,'onContentBeforeDisplay():$context');
//		$FieldLastValue = '';
//		$FieldLast = null;
//		
//		foreach (static::$FieldsContext as $artId => &$artData){
//			foreach ($artData as $fieldId => &$field){
//				$FieldLastValue = &$field->value;
//				$field->value = '';
//				$FieldLast = &$field;
//			}
//		} 
//		$FieldLast->value = $FieldLastValue; 
//toPrint(static::$FieldsContext,'onCustomFieldsAfterPrepareField():$context:'.$context,0,'message');
		
		
//toPrint('PlgFieldsOrder->onCustomFieldsAfterPrepareField()   '.  ($field->type));			//	Значение gettype strlen($field->value) strlen($value),
	}
	
	public function getVar($name,$default = null) {
		return $this->{$name} ?? $default;
	}
	public function setVar($name,$value) {
		$this->{$name} = $value;
		return $this;
	}
	
	/**
	 * Example after save content method
	 * Article is passed by reference, but after the save, so no changes will be saved.
	 * Method is called right after the content is saved
	 *
	 * @param   string   $context  The context of the content passed to the plugin (added in 1.6)
	 * @param   object   $article  A JTableContent object
	 * @param   boolean  $isNew    If the content is just about to be created
	 *
	 * @return  void
	 *
	 * @since   1.6
	 */
	public function onContentAfterSave($context, $article, $isNew): void // Редактор Article*, 
	{
//toPrint( 'Cost->onContentAfterSave()','',0,'pre'); 
//toPrint($context,'Cost->onContentAfterSave()$context ',0,'pre'); 
//toPrint($isNew,'Cost->onContentAfterSave()$isNew ',0,'pre'); 
//toPrint(array_keys(get_object_vars($article)),'Cost->onContentAfterSave()$article type:'. get_class($article).' ',0,'message'); 
	}
	
	/**
	 * 
	 * @param array $costsData  строковый массив значений полей, с ключами имен полей
	 * @param array $fields строковый Массив локализованных наименований, с ключами имён полей
	 */
	public static function renderOrderValues($costsData = [], $fields = []){
		$html = '<br>';
		$html .= '<table cellpadding="10" border="1">';
			$html .= '<tr border="1">';
				$html .= '<th>'.JText::_('PLG_ORDER_PARAM_FIELD').'</th>';
				$html .= '<th>'.JText::_('PLG_ORDER_PARAM_VALUE').'</th>';
			$html .= "</tr>";	
		
		foreach ($costsData as $fieldName => $value){
			$name = isset($fields[$fieldName]) ? $fields[$fieldName] : $fieldName;
			
			if(substr($value, 0, 4) == 'http')
				$value = "<a href='$value' target='_blank'>$value</a>";
			
            $html .= "<tr>";
            $html .= "<td>$name</td>";
			$html .= "<td>$value</td>";
			$html .= "</tr>";
		}
		$html .= '</table>';
		
		return $html;
	}
	/**
	 * 
	 * @param array $costsData 
	 */
	public static function renderCostsValues($costsData = [], $summ = 0, $orderId = 0 ){
		$html = '<br>';
		$html .= '<table cellpadding="10" border="1">';
			$html .= '<tr border="1">';
				$html .= '<th>'.JText::_('PLG_ORDER_PARAM_TITLE').'</th>'; 
				$html .= '<th>'.JText::_('PLG_ORDER_PARAM_QUANTITY').'</th>'; 
				$html .= '<th>'.JText::_('PLG_ORDER_PARAM_PRICE').'</th>'; 
			$html .= "</tr>";
					
		
		foreach ($costsData as $fieldName => $cost){
			
			$value = $cost->selectValue;

			if(substr($value, 0, 4) == 'http')
				$value = "<a href='$value' target='_blank'>$value</a>";
			
			$option = $cost->option ? '∕'.$cost->option : ''; //  ∕║
			
            $html .= "<tr>";
			
			if($cost->select_param == 'title'){
				$html .= "<td colspan='3'>$cost->title</td>";
			}else{
				$html .= "<td>$cost->title $option</td>";
				$html .= "<td>$value</td>";
				$html .= "<td>$cost->cost ".($cost->currency??'')."</td>";
			}
			$html .= "</tr>";
		}
		$html .= '</table>';
		
			
			
			$html .= "<hr>";
//			$html .= "<br>";
			if($orderId){
				$html .= JText::_('PLG_ORDER_PARAM_ORDER').': '.$orderId;
				$html .= "<br>"; 
			}
			
			$dt = JFactory::getDate()->setTimezone(JFactory::getUser()->getTimezone())->toSql(true);
			$html .= JText::_('JLIB_HTML_BEHAVIOR_TIME').': '.$dt;
			$html .= "<br>"; 
			
			$html .= '<b>'.JText::_('JLIB_RULES_CALCULATED_SETTING').': '.$summ .'</b>';
//			$html .= "<br>";
			$html .= "<hr>";
		
		return $html;
	}
	
	/**
	 * 
	 * @param string $message
	 * @param array $mails
	 */
	public function sendMail($html = '', $title = '',$fieldsData = []){
		
//toPrint(empty($this->params['sendMailSystem']) && empty($this->params['sendMailUser']) && empty($this->params['sendMailText']) && empty($this->params['sendMailGroup']),'MailTrue!');
//toPrint(empty($html) , 'empty($html)',0);
		
		
toPrint($this->params , '$this->params',0);//$this->params['sendMailGroup'] $this->params['sendMailSystem']
//toPrint(implode(',', (array)$this->params->get('sendMailGroup')) , '$this->params->get(sendMailGroup)',0);//$this->params['sendMailGroup'] $this->params['sendMailSystem']
		
		if(empty($html) || empty($this->params['sendMailSystem']) && empty($this->params['sendMailUser']) && empty($this->params['sendMailText'])
				&& empty($this->params['sendMailGroup']))
			return;
		//sendMailUser   sendMailText    sendMailGroup
		

		$admins = [];
		$query = [];
		
		if($this->params['sendMailGroup'])
			$query[] = "
SELECT DISTINCT  u.id, u.email,   u.name,   u.sendEmail  
FROM `#__usergroups` g, `#__usergroups` gRange 
	,`#__user_usergroup_map` m
	,`#__users` u
WHERE g.id IN (". implode(',', (array)$this->params->get('sendMailGroup')).") AND g.lft <= gRange.lft AND g.rgt >= gRange.rgt AND
	m.group_id = gRange.id AND u.id = m.user_id ";
		
		if($this->params['sendMailUser'])
			$query[] = "
SELECT u1.id, u1.email, u1.name,  u1.sendEmail
FROM `#__users` u1
WHERE u1.id IN (".$this->params['sendMailUser'].") ";
		
//toPrint($query , '$query',0,'message');return;
		if($query)
			$admins += JFactory::getDbo()->setQuery(implode(' UNION ', $query).'; ')->loadObjectList('email'); // [id, email, name, sendEmail] 
		
		
		if($this->params['sendMailText']){
			$mails = [];
			$sendMailText = str_replace (['|',"\n"],';', $this->params['sendMailText']); // ,','
			$sendMailText = explode(';', $sendMailText);
			foreach ($sendMailText as $mail){
				$mail = str_replace([' '],':', trim($mail));
				$info = explode(':', $mail, 2);
				$name = $info[1] ?? '';
				$mail = $info[0] ?? '';
				if($mail)
					$mails[$mail] = (object)[
						'id'=>0,
						'email'=>$mail,
						'name'=> isset($admins[$mail]->name) && $admins[$mail]->name && empty($name) ? $admins[$mail]->name : $name,
						'sendEmail'=>1
						];
			}
			$admins = $mails + $admins;
		}
		
		// Почта Админа
		$sitename	= JFactory::getConfig()->get('sitename');
		$mailfrom	= JFactory::getConfig()->get('mailfrom');
		$fromname	= JFactory::getConfig()->get('fromname');
		$replyto	= JFactory::getConfig()->get('replyto');
		$replytoname= JFactory::getConfig()->get('replytoname');
		
		// Почта Юзера
		$userMails = [];
		$userNames = []; 
		foreach (['Имя','имя','Name','name','FirstName','Firstname','firstname'] as $name){//,'Username','username'
			if(isset($fieldsData[$name])){
				$userNames[] = $fieldsData[$name];
			}
		}
		foreach (['E-mail','e-mail','email','Email','mail','Mail'] as $mail){
			if(isset($fieldsData[$mail])){
				$userMails[] = $fieldsData[$mail];
				$key  = array_key_last($userMails);
				$userNames[$key] ?? reset($userNames);
			}
		}
		$userMails = array_unique($userMails);
		
        $mailerUser = JFactory::getMailer();
        $mailerAdmin = JFactory::getMailer();
		
		//Указываем что письмо будет в формате HTML
		$mailerUser->IsHTML( true );
		$mailerAdmin->IsHTML( true );
		
		//Указываем отправителя письма
		$mailerUser->setSender([$mailfrom, $fromname]); 
		$mailerAdmin->setSender([$mailfrom, $fromname]);
		
        //добавляем получателя 
        $mailerUser->addRecipient($userMails);
        $mailerAdmin->addRecipient(array_keys($admins), array_column($admins, 'name'));
		
		$userMail = reset($userMails);
		$userName = reset($userNames);
		$adminsKeys = array_keys($admins);
		$adminMail = reset($adminsKeys);
		
		//добавляем адрес для ответа
		if($adminMail)
			$mailerUser->addReplyTo($adminMail, $admins[$adminMail]->name);
		if($userMail)
			$mailerAdmin->addReplyTo($userMail, $userName);
		
//        //добавляем получателя копии
//		if($param->sendtoemailcc)
//			$mailerUser->addCc( $param->sendtoemailcc );
//        //добавляем получателя копии
//		if($param->sendtoemailbcc)
//			$mailer->addBcc( $param->sendtoemailbcc );
		
		if(in_array(JFactory::getConfig()->get('error_reporting'), ['maximum','development']) ){//'default','none',
			$mailerUser->SMTPDebug = 4;
			$mailerAdmin->SMTPDebug = 4;
		}
		
		//добавляем вложение
		//$mailer->addAttachment( '' );
//toPrint($title , '$title',0);
//return '';
		//Добавляем Тему письма
        $mailerUser->setSubject($title);
        $mailerAdmin->setSubject($title);
		
		//Добавляем текст письма
		$mailerUser->setBody($html);
		$mailerAdmin->setBody($html);
		
//toPrint($mailerUser,'$mailerUser',0);
//toPrint($mailerAdmin,'$mailerAdmin',0);
		
		$response = 0;
		
        //Отправляем письмо   
		if($userMail)
			$response += $mailerUser->send();
		if($adminMail)
			$response += $mailerAdmin->send();
		
		return $response;
//toPrint($mailerAdmin->ErrorInfo,'$mailerUser',0); 
//toPrint($userMail,'$userMail',0); 
//toPrint($adminMail,'$adminMail',0); 
	}
	
	
	/**
	 * 
	 * @param int $categoryId
	 * @return Joomla\CMS\Table\Content
	 */
	public function createArticle($categoryId = 0) {
		
		if(empty($categoryId))
			return null;
		
		$contentTable = new Joomla\CMS\Table\Content(JFactory::getDbo());
		
		$data = [];
		$data['catid']		= $categoryId;
		$data['alias']		= 'order_' . time();
		$data['state']		= 1;// 1-Published, 0-Unpublished, 2-Archive, -2-Trash
		$data['id']			= 0;
		$data['title']		= JText::_('PLG_ORDER_PARAM_ORDER');
		$data['introtext']		= '';
		$data['fulltext']		= ''; 
		$data['language']	= '*';
		$data['access']		= 1;
		$data['created_by_alias'] = '';
		$data['version']	= 1;
		$data['ordering']	= 1;
		$data['featured']	= 0;
		$data['note']		= '';
		
		$contentTable->bind($data);
		$contentTable->save($data);
		
		
		if(JVersion::MAJOR_VERSION == 3){
			return $contentTable;
		}
		
//		$query = "
//INSERT INTO #__workflow_associations  (item_id, stage_id, extension)
//SELECT $contentTable->id, ws.id, w.extension
//FROM   #__workflow_stages ws, #__workflows w
//WHERE ws.workflow_id = w.id AND NOT EXISTS (SELECT * FROM #__workflow_associations WHERE item_id = $contentTable->id)
//ORDER BY ws.id LIMIT 1 ; "; 
		$workflowstageDefault = $this->params->get('workflowstage',1);//workflowstage
		
		$query = "
INSERT INTO #__workflow_associations (item_id, stage_id, extension)
SELECT $contentTable->id, ws.id, w.extension
FROM   #__workflow_stages ws, #__workflows w
WHERE ws.id = {$workflowstageDefault} AND ws.workflow_id = w.id AND NOT EXISTS (SELECT * FROM #__workflow_associations WHERE item_id = $contentTable->id)
 ; "; 
		

//toPrint($query,'Insert WorkFlow',0,'message');
		JFactory::getDbo()->setQuery($query)->execute();
		
		
//toPrint($this->params,'Order->params',0,'message');
//toPrint($contentTable->getError(),'OK',0, str_starts_with($this->alias, 'order'));
//toPrint($contentTable->getError(),'OK');
//		$content = $contentTable->load();
		
		
//toPrint($contentTable->introtext, (string)$contentTable->id);
		
		return $contentTable;
	}
	
	/**
	 * 
	 * @param Joomla\CMS\Table\Content $articleTable
	 * @param string $text
	 * @param string $titleSuffix
	 * @return int
	 */
	public function saveArticle($articleTable, $text = '', $titleSuffix = ''){
		
		$articleTable->title = JText::sprintf('PLG_ORDER_PARAM_ORDER_F',$articleTable->id, $titleSuffix);
//				JText::_('PLG_ORDER_PARAM_ORDER')." [#$articleTable->id] ".$titleSuffix;
		$articleTable->alias = "order_$articleTable->id";
//		$data['articletext'] = $text;
//		$articleTable->articletext = $text;
		$articleTable->introtext = $text;
		$articleTable->store();
		
		return $articleTable->id;
		
//		$id = JFactory::getApplication()->getInput()->get('id',0);
//		$task = JFactory::getApplication()->getInput()->get('task','');
//		
//		JFactory::getApplication()->getInput()->set('id',0);
//		JFactory::getApplication()->getInput()->set('task','save2new');
		
//		$state = new JRegistry(['article.id'=>0,'content.id'=>0]);
//		JModelLegacy::addIncludePath(JPATH_BASE. "/administrator/components/com_content/models", 'ContentModel');
//		$result = JModelLegacy::getInstance('Article', 'ContentModel',['ignore_request' => true,'state'=>$state])->save($data);
		
		
//		JFactory::getApplication()->getInput()->set('id',$id);
//		JFactory::getApplication()->getInput()->set('task',$task);
	}
	
	public static function formatingTitle($fields = [], $format = ' {phone} {name} {mail}'){
		$format = $format ??  ' {phone} {name} {mail}';
		foreach ($fields as $fieldName => $field){
			if(is_scalar($field)){
				$format = str_replace("{{$fieldName}}", $field, $format);
			}
			if(is_object($field) && isset($field->value)){
				$format = str_replace("{{$fieldName}}", $field->value, $format);
			}
			if(is_array($field) && isset($field['value'])){
				$format = str_replace("{{$fieldName}}", $field['value'], $format);
			}
		}
		
		$result = '';
		$strs = explode('{', $format);
		foreach ($strs as $substr){
			$pos = strpos($substr, '}');
			$str = substr($substr, $pos + 1);
//			$fieldName = substr($substr, 0 , $pos);
			$result .= $str;
		}
		
		return $format;
	}
	
	/**
	 * Проверяет наличие ключей в массиве
	 * @param array $keys
	 * @param array $arr
	 * @return bool
	 */
	static function array_keys_exists(array $keys, array $arr) {
		return !array_diff_key(array_flip($keys), $arr);
	}
	
	
	public static $list_fields = [
		['title_field'=>'PLG_ORDER_USERFIELDS_TITLE_1','hold_field'=>'PLG_ORDER_USERFIELDS_HOLD_1','type_field'=>'text','alias_field'=>'PLG_ORDER_USERFIELDS_ALIAS_1','require_field'=>1,'display_field'=>1,],
		['title_field'=>'PLG_ORDER_USERFIELDS_TITLE_2','hold_field'=>'PLG_ORDER_USERFIELDS_HOLD_2','type_field'=>'text','alias_field'=>'PLG_ORDER_USERFIELDS_ALIAS_2','require_field'=>1,'display_field'=>1,],
		['title_field'=>'PLG_ORDER_USERFIELDS_TITLE_3','hold_field'=>'PLG_ORDER_USERFIELDS_HOLD_3','type_field'=>'text','alias_field'=>'PLG_ORDER_USERFIELDS_ALIAS_3','require_field'=>1,'display_field'=>1,],
	];


}
