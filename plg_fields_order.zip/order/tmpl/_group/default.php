<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Fields.Sql
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;


//Поле выводимое в клиенте материала -------- Клиент !!!
//----------------------------------------------------------------------------------------
use Joomla\CMS\Factory as JFactory;
use Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use Joomla\CMS\Layout\FileLayout as JLayoutFile;
use Joomla\CMS\Language\Text as JText;
//use Joomla\CMS\Form\Form as JForm;




//Поле выводимое в клиенте материала
echo '<br>Вывод  из папки TMPL Opera_82.0.4227.43_Setup_x64.exe';


if(empty($item->params))
    return;

if(empty($field->value) )
    return;

//toPrint($field->value,'$field->value'); 
//toPrint($fieldParams);//list_fields

//return;


//toPrint(get_class($this));
$fieldParams['list_fields'];		// Список Параметров
$fieldParams['list_currencies'];	// Список Валют
$fieldParams['list_units'];			// Список едениц учета
//$fieldParams['list_fields']['name_param'][$i]; //Название параметра
$short_cur_default = $fieldParams['list_currencies']->short_cur[($fieldParams['list_currencies']->default_cur)]; //Название параметра

$html = "<output id='cost' data-currency='$short_cur_default' class='h4'>0 $short_cur_default</output>";

//$html .= '<dl>';

foreach ($field->value as $i => $table){

//	$html .= "<dt>".$fieldParams['list_fields']['name_param'][$i]."</dt>";
	
	
	$layout = $fieldParams['list_fields']['layout_param'][$i] == -1 ? $table->layout : $fieldParams['list_fields']['layout_param'][$i];
	
	
//toPrint($fieldParams['list_fields']['layout_param'][$i],'$fieldParams[list_fields][layout_param][$i]'); 
//toPrint($table->layout,'$table->layout'); 
//toPrint($layout,'$layout'); 
	
	if($layout){
		$file = JPATH_PLUGINS . "/fields/order/tmpl/$layout.php";
		$path = JPATH_PLUGINS . "/fields/order/tmpl/";
//		$html .= "<dd class='form-check'>";
		$html .= JLayoutHelper::render($layout, ['table'=>$table,'fieldParams'=>$fieldParams,'item'=>$item,'field'=>$field,'i'=>$i], $path);
//		$html .= "</dd>";
	}
	else
	{
		$default_check = count($table->option) ? '' : ' checked ';
		foreach (array_keys($table->option) as $key){ // light  info   secondary
$html .= <<<OPT
	<dd class='form-check'>
			<input type='checkbox' name='cost[$item->id][$field->id][$i][$key]' autocomplete='off'  class='btn-check' $default_check id='cost_{$field->id}_{$i}_{$key}'>
			<label class='btn btn-outline btn-outline-secondary' for='cost_{$field->id}_{$i}_{$key}'><span><b>{$table->cost[$key]} $short_cur_default</b> {$table->name[$key]}</span></label>
	</dd>
OPT;
		}

	}
}
//$html .= '</dl>';

echo $html;
return ;

$fieldParams;//параметры поля и плагина
//toPrint($this,'modules.php');
//toPrint(array_keys((array)$this),'$this.keys');
//toPrint(($this->params),'$this->params',0);
$context;// тип блога, тип статьи. Пример: com_content.article
$item;// объект Статьи в блоге
$field; // объект добавляемого поля к статье в блоге
$field_modules_type = $fieldParams->get('method', 'pos');
$field_multiple = $fieldParams->get('multiple', TRUE);
$field_value = $fieldParams->get('query', 0);
$tasks = $fieldParams->get('task', []);

$display = $field->params->get('display'); // Место где должен отображатся поле. ПослеЗаголовка, ПослеТекса, ПередТекстом.
$context = $field->context; //com_content.article 

$show_text = $item->params->get('show_text'); // Место как должно отображатся текст описания
//,hide,or,intro,full,all
$show_intro = $item->params->get('show_intro'); // Место как должно отображатся текст описания
//,use_article,0,1

$ignore = array('GLOBALS', '_FILES', '_COOKIE', '_POST', '_GET', '_SERVER', '_ENV', 'ignore');
$vars = array_diff_key(get_defined_vars() + array_flip($ignore), array_flip($ignore));
//toPrint(array_keys($vars),'$this'); 
//toPrint($this->path,'$path'); 
//toPrint(array_keys(get_object_vars($this->_subject)),'$this->_subject'); 

//$values = explode(',', $field_value);

//toPrint($field_value,'$field_value'); 
//toPrint($context,'$context'); //com_content.article 
//toPrint($field,'$field'); 






//else {    
//$query = "
//SELECT  CONCAT(id ,': ',title,' :/',module,'/',position,'') title,
//     id  /*id, title, position, module, client_id ,*/
//FROM #__modules 
//WHERE id IN ($where) ; " ;
//}

$mod_type = $field_modules_type;

//if(count($value)==1 && empty($value[0]))
//    return '';

//toPrint($value,'$value',0);  
//toPrint($fieldParams,'$fieldParams'); 
//toPrint($context,'$context'); 
//toPrint(array_keys((array)$item),'$item'.$item->title); 
//toPrint($field,'$field'); 
 //toPrint($fieldParams,'$fieldParams'); 


$view = JFactory::getApplication()->input->getCmd('view');

//toPrint($view,'$view',0);
//toPrint($tasks,'$tasks',0);
//toPrint(in_array(-1, $tasks),'inArray -1',0);
//toPrint(!in_array('', $tasks) && !in_array($view, $tasks),'inArray \'\'',0);
//toPrint(!in_array($view, $tasks),'inArray '.$view,0);

if($tasks && (in_array(-1, $tasks) || !in_array('', $tasks) && !in_array($view, $tasks))){
//    echo "Disable";
//    toPrint("Disable!");
    return;
}
//toPrint("Enable!");
//echo "Enable";
 

$ids        = []; 
$condition = '';
$db        = JFactory::getDbo(); 

foreach ((array)$field->value as $v)
{
    if (empty($v))
    {
        continue;
    } 
    $ids[] = $db->q($v);
}
$where = implode(',', $ids); 

$query = $fieldParams->get('query', '');



//toPrint($field->value,'$field->value',0);
//toPrint($ids,'$ids1');
//toPrint($value,'$value');
//toPrint($value,'$value');
//return '123';

 
$tag = JFactory::getLanguage()->getTag();

if($field_modules_type == 'pos'){    
$query = "
SELECT id, title, position, module, client_id, published, showtitle, params, ordering, language, content  
     /*CONCAT(id ,': ',title,' :/',module,'/',position,'') title, id  */
FROM #__modules 
WHERE position IN ($where) AND position != '' AND published = 1  AND language IN ('$tag','*')
ORDER BY position, ordering, id ; " ; 
} 
elseif($field_modules_type == 'ids') {    
$query = "
SELECT id, title, position, module, client_id, published, showtitle, params, ordering,  language, content 
     /*CONCAT(id ,': ',title,' :/',module,'/',position,'') title, id  */
FROM #__modules 
WHERE id IN ($where)  AND published = 1  AND language IN ('$tag','*')
ORDER BY position, ordering, id ; " ; 
}

//toPrint($field_modules_type,'$field_modules_type',0,true, true);
//toPrint($where,'$where',0,true, true);
//toPrint($query,'$query',0,true, true);
//return;

// Run the query with a having condition because it supports aliases
$db->setQuery($query);
$items = $db->loadObjectlist('id');// id, title, position, module, client_id, published, showtitle, params.
//    $items = $db->loadAssocList('id', 'id'); 


//$ix = [];
//foreach ($items as $i => $item){
//    $ix[$i] = [$item->ordering,$item->title,$item->module];
//}
//159, 162, 166, 174, 158, 157        166, 158, 157, 159, 162,           174
//  5    1    6   11    9   10          2    6    7    8   11   
//$ids = array_keys($items) ;
//toPrint($ids,'$ids2');
//foreach ($items as &$item)
//    $item->params = '';
//toPrint($items,'$items',0); 
//toPrint($ix,'$items',0); 
//toPrint($items[155],'$items',0);  
//toPrint($items,'$items',0,true, true);
//return;
 
$texts = array();


$modules = [];

//if(!toPrint()){
//    return;
//}

//$menuitem = JFactory::getApplication()->getMenu()->getActive();
//$doc = JFactory::getDocument();
$view = JFactory::getApplication()->input->getCmd('view');
//$router2 = JFactory::getApplication()->getRouter()->getVars();
 
// $item->params->get('category_layout');   [category_layout] => _:blog   [show_text]
// introtext   fulltext   text   jcfields
// 
//  task
//toPrint($field,'$field');
//toPrint($router1,'$router1',0);
//toPrint($router2,'$router2',0);
//toPrint($menuitem,'$menuitem');
//toPrint($doc,'$doc');
//toPrint($fieldParams,'$fieldParams');
//toPrint(array_keys((array)$field) ,'$field');
//toPrint(array_keys((array)$item) ,'$item',0);
//toPrint($item,'$item');
//toPrint(array_keys((array)$this) ,'$this');
//toPrint(array_keys((array)$this) ,'$this');
//toPrint(array_keys((array)$this) ,'$this');
//toPrint($this->type ,'$thisType');
//toPrint(JFactory::getApplication() ,'JFactory::getApplication()');
//toPrint($this ,'$this');

//return;

foreach ($items as $mod_id => $module)
{
//    toPrint($mod_id,'$mod_id');
//    toPrint($module,'$module '.$mod_id);
//    if (in_array($mod_id, (array)$field->value))
//    { 
            //$multi_items[$key]->module = $module->module;
            //
            //if(!isset($module->module))            {echo "<pre>$multi_module_id: ".print_r($module,true). "</pre>";continue;}
            
    $file = JPATH_SITE."/modules/$module->module/$module->module.php"; 
        //    echo $file."<br>";//149,142,146
			//echo "<pre> ** ".print_r($multi_items,true)."++</pre>"; 
            //$b = $params->get('base');
                 
//toPrint($module,'$mod_id');    continue;
        if(file_exists($file)){
            
//toPrint($file,'$file: '.$mod_id);
                //$multi_items[$key]->params = unserialize  ($module->params);
//                $module->params = json_decode ($module->params);
                //echo "<pre> **".print_r( $module,true). "++</pre>"; 
                //var_dump($module->params);
                //echo "<br>".$file."<br>". $module->params."<br> ";
                $module->params = $params = new Joomla\Registry\Registry($module->params);
                //$params->setProperties($module->params);
				
                //$module->params = $params;
				$module->parentId = 0;
//				$module->style = $module->params->get('style','');
//				$module->moduleclass_sfx = $module->params->get('moduleclass_sfx','');
//				$module->module_tag = $module->params->get('module_tag','');
//				$module->header_tag = $module->params->get('header_tag','');
//				$module->header_class = $module->params->get('header_class',''); 
				
//                $items[$mod_id]->params= $module->params;
//                $items[$mod_id]->parentId= $module->parentId;
//                $items[$mod_id]->style= $module->style;
//                $items[$mod_id]->moduleclass_sfx= $module->moduleclass_sfx;
//                $items[$mod_id]->module_tag= $module->module_tag;
//                $items[$mod_id]->header_tag= $module->header_tag; 
//                $items[$mod_id]->header_class= $module->header_class;
				
				//if ($multi_module_id == 144 || $multi_module_id == 145)echo "<pre> **".print_r( $module,true). "++</pre>"; 
				
		JFactory::getLanguage()->load($module->module);
        
        
                $content = ''; 
                ob_start(); 
                require $file;
                $content = ob_get_clean().$content;
                
                if(empty($module->published) || empty($content)){
                    unset($items[$mod_id]);
                    continue;;
                }
        
//toPrint($module,'$module');
//                ob_start();
				//echo $file."<br>" ;//149,142,146
                $module_tag = (empty($module->style))?"div":$module->module_tag;
                
                echo "<$module_tag class=\" field_module $module->module $module->moduleclass_sfx id_$module->id \">";
                
                if($module->showtitle){
                    echo "<$module->header_tag class=\"$module->header_class\" >$module->title</$module->header_tag>";
                }
                
                
                echo $content;
                    
                
                echo "</$module_tag>";
//toPrint($module,'$mod_id');    continue;
//                $items[$multi_module_id]->content = ob_get_clean();
				//$multi_items[$multi_module_id]->id = $multi_module_id; 
        }
//    }
}





//echo htmlentities(implode(', ', $modules));
//echo "LaLa !!!";
