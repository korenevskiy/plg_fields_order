<?php
/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   (C) 2016 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
use Joomla\CMS\Factory as JFactory;
use Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use Joomla\CMS\Layout\FileLayout as JLayoutFile;
use Joomla\CMS\Language\Text as JText;

//extract($displayData);

/**
 * Layout variables
 * -----------------
 * 
 * @var   boolean  $item			Материал
 * @var   array    $field         Options available for this field.
 * @var   array    $fieldParams       Options available for this field.
 * @var   string   $table			Таблица опций
 * @var   array    $i				index таблицы (table) опций в массиве $field->value
 * @var   string   $currency		Валюта
 * @var   array    $currencies		Валюты
 * @var   array    $options			Опции
 */

// Initialize some field attributes.
//$class    = !empty($class) ? ' class="' . $class . '"' : '';
//$disabled = $disabled ? ' disabled' : '';
//$onchange = $onchange ? ' onchange="' . $onchange . '"' : '';


 
$item			= $displayData['item'];	// Материал
$field			= $displayData['field'];	// 
$fieldParams	= $displayData['fieldParams'];//
$table			= $displayData['table'];	//Таблица опций
$i				= $displayData['i'];		//index таблицы (table) опций в массиве $field->value
$default_check	= count($table->option) ? '' : ' checked ';
$short_cur_default = $fieldParams['list_currencies']->short_cur[($fieldParams['list_currencies']->default_cur)]; //Название параметра
$options		= explode('|', $fieldParams['list_fields']['option_param'][$i]??''); //$options[]

	$fieldParams['list_fields'];		// Список Параметров
	$fieldParams['list_currencies'];	// Список Валют
	$fieldParams['list_units'];			// Список едениц учета

$currency	 = PlgFieldsCost::$currency;
$currencies	 = PlgFieldsCost::$currencies;

//toPrint($currency->short_cur,'$currency->short_cur'); 
//toPrint($fieldParams,'$fieldParams'); 
//echo "<hr>";
//echo JText::sprintf('PLG_COST_PARAM_PRICE',$currency->short_cur);//$currency->short_cur
//echo "<hr>"; 
//echo "<hr>";

echo "<table class='tbl table caption-top'>";

echo "<caption>".$fieldParams['list_fields']['name_param'][$i]."</caption>"; 

echo "<tr><th>";
echo JText::_('');
echo "</th><th>";
echo JText::_('PLG_COST_PARAM_TITLE');
echo "</th><th>";
echo JText::_('PLG_COST_PARAM_OPTIONS');
echo "</th><th>";
echo JText::sprintf('PLG_COST_PARAM_PRICE_F',$currency->short_cur);//$currency->short_cur
echo "</th></tr>";
if(true)
foreach (array_keys($table->option) as $key){ // light  info   secondary

	echo "<tr class='checkboxes '>";
	// class='form-check'
echo <<<OPT
	<td class='checkbox '><label class='form-check-label form-control-plaintext' ><input type='checkbox' name='cost[$item->id][$field->id][$i][$key]' autocomplete='off'  class='_btn-check form-check-input' $default_check id='cost_{$field->id}_{$i}_{$key}'></label></td>
	<td><label class='form-check-label form-control-plaintext' for='cost_{$field->id}_{$i}_{$key}'><span>{$table->name[$key]}</span></label></td>
	<td><label class='form-check-label form-control-plaintext' for='cost_{$field->id}_{$i}_{$key}'><span>{$options[$table->option[$key]]}</span></label></td>
	<td><label class='form-check-label form-control-plaintext' for='cost_{$field->id}_{$i}_{$key}'><b>{$table->cost[$key]} $short_cur_default</b></label></td>
OPT;
	echo "</tr>";
}


echo "</table>";

?>

 