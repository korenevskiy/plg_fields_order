<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  Fields.Sql
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;


//Поле выводимое в клиенте материала -------- Клиент !!!
//----------------------------------------------------------------------------------------	КЛИЕНТ !!!
use Joomla\CMS\Factory as JFactory;
use Joomla\CMS\Layout\LayoutHelper as JLayoutHelper;
use Joomla\CMS\Layout\FileLayout as JLayoutFile;
use Joomla\CMS\Language\Text as JText;
//use Joomla\CMS\Form\Form as JForm;
use \Joomla\CMS\Uri\Uri  as JUri;
use \Joomla\CMS\Session\Session as JSession;



////////Поле выводимое в клиенте материала
//echo '<br>Вывод  из папки '.__FILE__;


if(empty($item->params))
    return;

//if(empty($field->value) )
//    return;

//Поле выводимое в клиенте материала
//echo '<br>Вывод  из папки '.__FILE__;


//toPrint($field,'$field->value'); 
//toPrint($fieldParams);//list_fields





//return;


//toPrint(get_class($this));
//$fieldParams['list_fields'];		// Список Полей
//$fieldParams['check_gdpr'];			// Галка ПД
//$fieldParams['text_gdpr'];			// Текст ПД
//$fieldParams['buttonTitle'];		// Текст кнопки
//$field->valuesOrder;				// список значений полей введенных пользователем




//$fieldParams['buttonTitle']['name_param'][$i]; //Название параметра

$html = '';
$html .= "<form name='order{$item->id}'  action='#form{$field->id}_{$item->id}' id='form{$field->id}_{$item->id}' method='post'>";
$html .= '<dl>';
//$html .= '<ul>';

foreach ($fieldParams['list_fields']['display_field'] as $i => $onoff){
	if(empty($onoff))
		continue;

//	$html .= "<dt>".$fieldParams['list_fields']['name_param'][$i]."</dt>";
//	$selectValue = JFilterInput::getInstance([], [], 1, 1)->clean($dataFormCost ['cost'][$cost->content_id] [$cost->field_id] [$cost->list_id], 'ARRAY');
	
	$name		= $fieldParams['list_fields']['alias_field'][$i]?:$i;
	$placeholder= $fieldParams['list_fields']['hold_field'][$i]?:'';
	$label		= $fieldParams['list_fields']['title_field'][$i]?:'';
	$type		= $fieldParams['list_fields']['type_field'][$i]?:'text';
	$require	= isset($fieldParams['list_fields']['require_field'][$i]) && $fieldParams['list_fields']['require_field'][$i] ?' *':''; 
	$valueOrder	= isset($field->valuesOrder[$name]) ? $field->valuesOrder[$name] : '';
//	$valueCost	= isset($field->valuesCost[$name]) ? $field->valuesCost[$name] : '';
	
	
	$valueOrder = JFilterInput::getInstance([], [], 1, 1)->clean($valueOrder, 'string');

//toPrint($fieldParams['list_fields']['layout_param'][$i],'$fieldParams[list_fields][layout_param][$i]'); 
//toPrint($table->layout,'$table->layout');  
$html .= <<<OPT
	<dd> 
		<div class="form-group">
			<label class=' ' for='form_{$field->id}_{$name}'> $label $require</label>
			<input type='$type' name='order[$item->id][$field->id][$name]' autocomplete='off' placeholder="$placeholder" value="{$valueOrder}" class='form-control' id='form_{$field->id}_{$name}'>
		</div>
	</dd>
OPT;
}

if($fieldParams['check_gdpr'])
$html .= <<<OPT
	<dd>
		<div class="form-check">
			<input type='checkbox' name='order[$item->id][$field->id][gdpr]' value='ok' autocomplete='off'  class='form-check-input position-static' id='form_{$field->id}_gdpr' required='required'>
			<label class=' form-check-label' for='form_{$field->id}_gdpr'> $fieldParams[text_gdpr]</label>
		</div>
	</dd>
OPT;
			
$html .= <<<OPT
	<dd>
		<input type='submit' name='order[$item->id][$field->id][done]' autocomplete='off'  class='btn  btn-secondary'   id='form_{$field->id}_gdpr' value='$fieldParams[buttonTitle]'>
	</dd>
OPT;
//class='btn btn-primary  btn-outline btn-outline-secondary'

//$html .= '</ul>';
$html .= '</dl>';
$html .= "<input type='hidden' name='order[$item->id][$field->id][url]' id='form_{$field->id}_url' value='".htmlspecialchars(JUri::current())."'>";
$html .= "<input type='hidden' name='order[$item->id][$field->id][title]' id='form_{$field->id}_title' value='". htmlspecialchars($item->title)."'>";
$html .= \JHTML::_('form.token');
//$html .= "<input type='hidden' name='order[$item->id][$field->id][title]' id='form_{$field->id}_title' value='". htmlspecialchars($item->title)."'>";
$html .= '</form>';

echo $html;
//JSession::checkToken()
//toPrint(JFactory::$application->getInput()->server,'POST');  
return ;

$fieldParams;//параметры поля и плагина
//toPrint($this,'modules.php');
//toPrint(array_keys((array)$this),'$this.keys');
//toPrint(($this->params),'$this->params',0);
$context;// тип блога, тип статьи. Пример: com_content.article
$item;// объект Статьи в блоге
$field; // объект добавляемого поля к статье в блоге
$field_modules_type = $fieldParams->get('method', 'pos');
$field_multiple = $fieldParams->get('multiple', TRUE);
$field_value = $fieldParams->get('query', 0);
$tasks = $fieldParams->get('task', []);

$display = $field->params->get('display'); // Место где должен отображатся поле. ПослеЗаголовка, ПослеТекса, ПередТекстом.
$context = $field->context; //com_content.article 

$show_text = $item->params->get('show_text'); // Место как должно отображатся текст описания
//,hide,or,intro,full,all
$show_intro = $item->params->get('show_intro'); // Место как должно отображатся текст описания
//,use_article,0,1
 
//toPrint($this->path,'$path'); 
//toPrint(array_keys(get_object_vars($this->_subject)),'$this->_subject'); 

//$values = explode(',', $field_value);

//toPrint($field_value,'$field_value'); 
//toPrint($context,'$context'); //com_content.article 
//toPrint($field,'$field'); 




 